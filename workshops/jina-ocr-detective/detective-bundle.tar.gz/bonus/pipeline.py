#!/root/app-venv/bin/python
"""The pipeline behind the game: PDF -> 200 dpi pages -> auto-orient -> jina-ocr-v1 -> markdown -> chunks -> Elasticsearch.

    ./pipeline.py                    # reads ./sample.pdf, writes the index my-pipeline-docs
    ./pipeline.py --pdf my.pdf --query "total amount"

Based on Ty Bekiares' es_pdf_import (https://github.com/ty-elastic/es_pdf_import, MIT licence): pymupdf renders each
page, jina-ocr-v1 on the Elastic Inference Service turns it into markdown, and Elasticsearch embeds the text with a
semantic_text field (Jina v5 text small). That is the whole idea. This version fixes six things we hit while building
the game. Each fix is marked in the code as "FIX n":

  FIX 1  dpi: the original renders at pymupdf's default 72 dpi. We render at 200 (small print needs the pixels).
  FIX 2  retry: the original's Retry only covers GET/HEAD/OPTIONS, so the POST that indexes a page was never retried
         (a throttled 429 just dropped the page). Every call here is a POST or PUT, so both must retry.
  FIX 3  UTF-8: we call the streaming OCR route with plain requests. It sends server-sent events, and requests decodes
         text/event-stream as Latin-1 unless you say otherwise: "Zürich" comes back as "ZÃ¼rich". Every stream also
         starts with a byte-order mark.
  FIX 4  auto-orient: an upside-down page makes OCR hallucinate fluent, wrong text. Fix the rotation BEFORE reading.
  FIX 5  header chunking: one document per page buries the answer; we split the markdown at its headings and keep
         HTML tables whole.
  FIX 6  stale versions: the original deletes "old versions" with a term query on `version.keyword`, a field that does
         not exist on a keyword mapping, so the must_not matches everything and the delete wipes the whole index.
         We delete only older versions of THIS document, after the new pages are safely indexed.

Needs ES_URL and ES_API_KEY (already set in this sandbox's shell). Tesseract is optional (FIX 4 skips itself without it).
"""
import argparse
import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import pymupdf
import requests
from PIL import Image, ImageOps
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

OCR_ENDPOINT = ".jina-ocr-v1-chat_completion"           # EIS chat_completion endpoint, one image per request
TEXT_EMBEDDING = ".jina-embeddings-v5-text-small"       # Jina v5 text small, used by the semantic_text field
DPI = 200                                               # FIX 1 (Ty's original: 72)
MAX_CHUNK_CHARS = 1500
HERE = Path(__file__).resolve().parent


# ------------------------------------------------------------------------------------------------- connection
def load_env():
    """ES_URL / ES_API_KEY from the environment, or from the sandbox's shell env file."""
    shell_env = Path("/root/.detective.shell.env")
    if (not os.environ.get("ES_URL")) and shell_env.is_file():
        for line in shell_env.read_text().splitlines():
            m = re.match(r"\s*(?:export\s+)?(ES_URL|ES_API_KEY|KIBANA_URL)=['\"]?(.*?)['\"]?\s*$", line)
            if m:
                os.environ.setdefault(m.group(1), m.group(2))
    if not os.environ.get("ES_URL") or not os.environ.get("ES_API_KEY"):
        sys.exit("ES_URL and ES_API_KEY must be set (they are in this sandbox's Terminal).")
    return os.environ["ES_URL"].rstrip("/"), os.environ["ES_API_KEY"], os.environ.get("KIBANA_URL", "").rstrip("/")


def make_session(api_key):
    s = requests.Session()
    s.headers.update({"Authorization": f"ApiKey {api_key}", "Content-Type": "application/json"})
    # FIX 2: Ty's original only retried GET/HEAD/OPTIONS, so the POST that indexes a page was never retried.
    # Our OCR call (POST) and our index call (PUT) must retry too, or a throttled 429 / a 503 silently drops a page.
    # Our doc ids are deterministic, so retrying an index request is safe.
    retry = Retry(total=5, backoff_factor=1, status_forcelist=[408, 429, 500, 502, 503, 504],
                  allowed_methods=frozenset({"GET", "HEAD", "OPTIONS", "POST", "PUT"}), respect_retry_after_header=True)
    s.mount("https://", HTTPAdapter(max_retries=retry))
    s.mount("http://", HTTPAdapter(max_retries=retry))
    return s


# ------------------------------------------------------------------------------------------------- index
def init_index(s, es, index, clean):
    mapping = {"mappings": {"properties": {
        "title": {"type": "keyword"},                    # the PDF's file name
        "version": {"type": "keyword"},
        "page": {"type": "integer"},
        "chunk": {"type": "integer"},
        "heading": {"type": "text"},                     # the markdown heading this chunk sits under
        "body_md": {"type": "text", "index": False},     # the OCR markdown exactly as read (for display)
        "body": {"type": "semantic_text", "inference_id": TEXT_EMBEDDING},   # plain text, embedded by Jina v5
        "ocr_model": {"type": "keyword"},
        "ocr_secs": {"type": "float"},
        "rotated_deg": {"type": "integer"},
    }}}
    if clean:
        print("delete index:", s.delete(f"{es}/{index}").status_code)
    r = s.put(f"{es}/{index}", json=mapping)
    ok = r.status_code in (200, 201) or "resource_already_exists" in r.text
    print("index:", index, "ready" if ok else f"FAILED {r.status_code} {r.text[:300]}")
    if not ok:
        sys.exit(1)


# ------------------------------------------------------------------------------------------------- pages
def render_pages(path):
    """Yield one PIL image per page. PDFs are rasterized at 200 dpi; jina-ocr-v1 takes images, never PDFs."""
    if path.suffix.lower() in (".jpg", ".jpeg", ".png"):
        yield Image.open(path)
        return
    doc = pymupdf.open(path)
    for page in doc:
        pix = page.get_pixmap(dpi=DPI, alpha=False)      # FIX 1: Ty's original called get_pixmap() = 72 dpi
        yield Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def detect_rotation(img):
    """Tesseract OSD: (degrees clockwise to make the page upright, confidence), or None when unsure / not installed."""
    exe = shutil.which("tesseract")
    if not exe:
        return None
    small = img.convert("L")
    small.thumbnail((2000, 2000))
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "osd.png"
        small.save(p)
        try:
            r = subprocess.run([exe, str(p), "-", "--psm", "0"], capture_output=True, text=True, timeout=30)
        except subprocess.TimeoutExpired:
            return None
    out = r.stdout + r.stderr
    rot, conf = re.search(r"Rotate:\s*(\d+)", out), re.search(r"Orientation confidence:\s*([\d.]+)", out)
    return (int(rot.group(1)) % 360, float(conf.group(1))) if rot and conf else None


def orient(img, min_confidence=1.5):
    """FIX 4: honour the phone's EXIF rotation, then let Tesseract OSD fix a page that is upside down or sideways.
    We only rotate when OSD is confident; otherwise the page is left alone. Returns (image, degrees_rotated)."""
    img = ImageOps.exif_transpose(img).convert("RGB")
    found = detect_rotation(img)
    if not found or found[0] == 0 or found[1] < min_confidence:
        return img, 0
    deg = found[0]
    return img.rotate(-deg, expand=True, fillcolor=(255, 255, 255)), deg   # PIL turns counter-clockwise


# ------------------------------------------------------------------------------------------------- OCR
def ocr_page(s, es, img):
    """One page image -> markdown. Streaming endpoint (server-sent events), one image per request."""
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "JPEG", quality=85)
    data_uri = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    body = {"messages": [{"role": "user", "content": [{"type": "image_url", "image_url": {"url": data_uri}}]}]}
    url = f"{es}/_inference/chat_completion/{OCR_ENDPOINT}/_stream"
    t0, last = time.time(), None
    for attempt in range(1, 4):                          # the adapter retries HTTP errors; this covers a stream that dies midway
        try:
            r = s.post(url, json=body, stream=True, timeout=(10, 90))
            r.raise_for_status()
            r.encoding = "utf-8"                         # FIX 3: requests assumes Latin-1 for text/event-stream
            pieces = []
            for line in r.iter_lines(decode_unicode=True):
                line = (line or "").lstrip("﻿")     # FIX 3: every stream starts with a byte-order mark
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    break
                event = json.loads(payload)
                if "error" in event:
                    raise RuntimeError(str(event["error"])[:200])
                for choice in event.get("choices", []):
                    piece = (choice.get("delta") or {}).get("content")
                    if piece:
                        pieces.append(piece)
            return "".join(pieces), round(time.time() - t0, 2)
        except (requests.RequestException, RuntimeError, ValueError) as exc:
            last = exc
            print(f"   OCR attempt {attempt} failed ({str(exc)[:100]}); retrying")
            time.sleep(2 * attempt)
    raise SystemExit(f"OCR failed after 3 attempts: {last}")


# ------------------------------------------------------------------------------------------------- markdown
TABLE = re.compile(r"(?is)<table.*?</table>")


def to_plain(md):
    """Tables come back as HTML. Turn them into `| a | b |` rows and drop other tags, for BM25 and embeddings."""
    def table(m):
        rows = re.findall(r"(?is)<tr.*?</tr>", m.group(0))
        return "\n".join("| " + " | ".join(re.sub(r"(?s)<.*?>", "", c).strip()
                                            for c in re.findall(r"(?is)<t[hd][^>]*>(.*?)</t[hd]>", row)) + " |"
                         for row in rows)
    return re.sub(r"[ \t]+\n", "\n", re.sub(r"(?s)<[^>]+>", "", TABLE.sub(table, md))).strip()


def chunk_markdown(md):
    """FIX 5: split at markdown headings (and at paragraph breaks once a chunk is long). A table is never cut in half."""
    tables = TABLE.findall(md)
    guarded = TABLE.sub(lambda m: f"\x00T{tables.index(m.group(0))}\x00", md) if tables else md
    chunks, heading, current = [], "", []

    def flush():
        text = "\n".join(current).strip()
        if text:
            chunks.append({"heading": heading, "text": text})
        current.clear()

    for line in guarded.splitlines():
        if re.match(r"#{1,6}\s", line):
            flush()
            heading = line.lstrip("# ").strip()
        elif not line.strip() and sum(len(x) for x in current) > MAX_CHUNK_CHARS:
            flush()
        current.append(line)
    flush()
    return [{"heading": c["heading"], "text": re.sub(r"\x00T(\d+)\x00", lambda m: tables[int(m.group(1))], c["text"])}
            for c in chunks]


# ------------------------------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description="PDF -> jina-ocr-v1 -> markdown -> Elasticsearch")
    ap.add_argument("--pdf", default=str(HERE / "sample.pdf"))
    ap.add_argument("--index", default=os.environ.get("PIPELINE_INDEX", "my-pipeline-docs"))
    ap.add_argument("--version", default="v1")
    ap.add_argument("--clean", action="store_true", help="delete and recreate the index first")
    ap.add_argument("--query", default="total amount", help="a semantic search to run when indexing is done")
    args = ap.parse_args()
    path = Path(args.pdf)
    if not path.is_file():
        sys.exit(f"{path} not found")

    es, key, kibana = load_env()
    s = make_session(key)
    init_index(s, es, args.index, args.clean)

    indexed, secs = 0, []
    for n, img in enumerate(render_pages(path), 1):
        img, rotated = orient(img)
        md, took = ocr_page(s, es, img)
        secs.append(took)
        chunks = chunk_markdown(md)
        for i, c in enumerate(chunks):
            doc_id = hashlib.sha256(f"{path.stem}|{args.version}|{n}|{i}".encode()).hexdigest()   # deterministic: re-runs overwrite
            doc = {"title": path.stem, "version": args.version, "page": n, "chunk": i, "heading": c["heading"],
                   "body_md": c["text"], "body": to_plain(c["text"]), "ocr_model": "jina-ocr-v1",
                   "ocr_secs": took, "rotated_deg": rotated}
            r = s.put(f"{es}/{args.index}/_doc/{doc_id}", json=doc)        # semantic_text is embedded here, server-side
            if r.status_code >= 300:
                sys.exit(f"index failed: {r.status_code} {r.text[:300]}")
            indexed += 1
        print(f"page {n}: {img.width}x{img.height} px at {DPI} dpi, rotated {rotated} deg, "
              f"read in {took}s, {len(chunks)} chunk(s)")

    # FIX 6: only now remove OLDER versions of this same document (Ty's original ran an unscoped delete first)
    r = s.post(f"{es}/{args.index}/_delete_by_query", params={"conflicts": "proceed", "refresh": "true"},
               json={"query": {"bool": {"filter": [{"term": {"title": path.stem}}],
                                        "must_not": [{"term": {"version": args.version}}]}}})
    print("stale versions deleted:", r.json().get("deleted", 0) if r.ok else f"skipped ({r.status_code})")
    s.post(f"{es}/{args.index}/_refresh")
    count = s.get(f"{es}/{args.index}/_count").json().get("count")
    print(f"\n{indexed} chunk(s) written, {count} in {args.index}. OCR {sum(secs):.1f}s total, "
          f"{(sum(secs) / max(len(secs), 1)):.1f}s per page.")

    # Try it: a semantic `match` on the semantic_text field (the query text is embedded for you)
    hits = s.post(f"{es}/{args.index}/_search", json={"size": 3, "_source": ["title", "page", "heading"],
                                                     "query": {"match": {"body": args.query}}}).json()
    print(f"\nTop hits for {args.query!r}:")
    for h in hits.get("hits", {}).get("hits", []):
        src = h["_source"]
        print(f"  page {src['page']}  {src.get('heading') or '(no heading)'}  score {h['_score']:.3f}")

    # Kibana data view, so the index shows up in Discover (best effort)
    if kibana:
        s.post(f"{kibana}/api/data_views/data_view", headers={"kbn-xsrf": "true"},
               json={"data_view": {"name": args.index, "title": args.index}})
    print("\nNext: Kibana tab -> Discover -> ES|QL:\n  FROM %s METADATA _score | WHERE MATCH(body, \"%s\") | SORT _score DESC | LIMIT 5"
          % (args.index, args.query))


if __name__ == "__main__":
    main()

# ------------------------------------------------------------------------------------------------- a note on images
# Verified on this project during our Step 0 probes (2026-10-16): a new `semantic` field type accepts an IMAGE in
# object form as the field value, and a query DSL `match` query works on it, so a page image can be searched without
# OCR. ES|QL cannot read it yet (`unsupported type [semantic]`). That is why the game's Photo Lab keeps its image
# vectors in a plain dense_vector (precomputed with jina-embeddings-v5-omni-small), and why this pipeline reads the
# page once with OCR: markdown gives you exact IDs, highlights, citations and ES|QL math. Use both.
