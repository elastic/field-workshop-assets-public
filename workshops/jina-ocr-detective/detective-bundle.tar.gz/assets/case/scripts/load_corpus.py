#!/usr/bin/env python3
"""Load the precomputed corpus into Elasticsearch. This is what the Instruqt setup script runs.

  load_corpus.py --prefix "" --corpus assets/case/out

Creates the indices (corpus indices recreated clean; evidence-mine and case-events created if missing), bulks the three
NDJSON files (semantic_text is embedded by Elasticsearch at index time), refreshes, asserts the counts and prints
timings. Exit code 0 only if every count matches.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

TRACK_ROOT = Path(__file__).resolve().parents[3]
if (TRACK_ROOT / "detective_core").is_dir():
    sys.path.insert(0, str(TRACK_ROOT))

from detective_core.config import Settings  # noqa: E402
from detective_core.es import ES  # noqa: E402
from detective_core.index import CORPUS_INDICES, create_indices, index_name, load_ndjson  # noqa: E402

FILES = {"evidence-rookie": "rookie.ndjson", "evidence-photolab": "photolab.ndjson", "evidence-detective": "detective.ndjson"}


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def load(es: ES, prefix: str, corpus: Path, recreate: bool = True, workers: int = 4) -> dict:
    """Importable entry point (validate_case.py uses it). Returns timings and counts; raises on a count mismatch."""
    t_all = time.time()
    pre = corpus / "precomputed"
    expected = {}
    for base, fname in FILES.items():
        path = pre / fname
        if not path.exists():
            raise SystemExit(f"missing {path} (run build_corpus.py first)")
        expected[base] = sum(1 for ln in path.read_text(encoding="utf-8").splitlines() if ln.strip()) // 2

    t0 = time.time()
    created = create_indices(es, prefix, CORPUS_INDICES, recreate=recreate)
    created.update(create_indices(es, prefix, ["evidence-mine", "case-events"], recreate=False))
    t_create = time.time() - t0
    log(f"indices: {created} ({t_create:.1f}s)")

    def one(item):
        base, fname = item
        return base, load_ndjson(es, pre / fname, prefix, workers=workers, log=log)

    with ThreadPoolExecutor(len(FILES)) as ex:
        loaded = dict(ex.map(one, FILES.items()))

    t0 = time.time()
    es.post(",".join(index_name(prefix, b) for b in CORPUS_INDICES) + "/_refresh")
    t_refresh = time.time() - t0

    counts, bad = {}, []
    for base in CORPUS_INDICES:
        n = es.get(f"{index_name(prefix, base)}/_count")["count"]
        counts[base] = n
        if n != expected[base]:
            bad.append(f"{index_name(prefix, base)}: {n} docs, expected {expected[base]}")
    result = {"created": created, "expected": expected, "counts": counts,
              "timings_secs": {"create_indices": round(t_create, 2), **{b: loaded[b]["secs"] for b in loaded},
                               "refresh": round(t_refresh, 2), "total": round(time.time() - t_all, 2)}}
    if bad:
        raise SystemExit("COUNT MISMATCH: " + "; ".join(bad))
    return result


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--prefix", default=None, help="index prefix (default: INDEX_PREFIX from the environment/.env)")
    ap.add_argument("--corpus", default="assets/case/out", help="dir containing precomputed/")
    ap.add_argument("--keep", action="store_true", help="do not recreate existing corpus indices")
    ap.add_argument("--workers", type=int, default=4, help="parallel _bulk batches per file")
    ap.add_argument("--dotenv", default=None)
    args = ap.parse_args()
    settings = Settings.from_env(args.dotenv)
    prefix = settings.index_prefix if args.prefix is None else args.prefix
    es = ES.from_settings(settings, pool_size=32)
    res = load(es, prefix, Path(args.corpus).resolve(), recreate=not args.keep, workers=args.workers)
    log(f"OK counts {res['counts']} (expected {res['expected']})")
    print(json.dumps(res["timings_secs"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
