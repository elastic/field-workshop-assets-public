"""jina-embeddings-v5-omni-small via EIS: image and text land in the same 1024-d space (Photo Lab)."""
from __future__ import annotations

import base64
import io
from pathlib import Path

from PIL import Image

from .es import ES
from .retry import backoff_sleep, is_retryable

OMNI_INFERENCE_ID = ".jina-embeddings-v5-omni-small"
OMNI_DIMS = 1024


def _post(es: ES, body: dict, timeout: float, retries: int) -> list[float]:
    attempt = 0
    while True:
        attempt += 1
        try:
            r = es.post(f"_inference/embedding/{OMNI_INFERENCE_ID}", json=body, timeout=timeout, retries=0)
            e = r["embeddings"][0]
            vec = e["embedding"] if isinstance(e, dict) else e
            if len(vec) != OMNI_DIMS:
                raise ValueError(f"expected {OMNI_DIMS} dims, got {len(vec)}")
            return vec
        except Exception as exc:  # noqa: BLE001
            if attempt > retries or not is_retryable(exc):
                raise
            backoff_sleep(attempt, base=0.8)


def _to_bytes(img) -> tuple[bytes, str]:
    if isinstance(img, (bytes, bytearray)):
        mime = "image/png" if bytes(img[:4]) == b"\x89PNG" else "image/jpeg"
        return bytes(img), mime
    if isinstance(img, (str, Path)):
        b = Path(img).read_bytes()
        return b, "image/png" if b[:4] == b"\x89PNG" else "image/jpeg"
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "JPEG", quality=85)
    return buf.getvalue(), "image/jpeg"


def omni_image(img, es: ES | None = None, mime: str | None = None, timeout: float = 60, retries: int = 2) -> list[float]:
    """Image (bytes | path | PIL.Image) -> 1024-d vector. Retries 429/5xx/timeouts."""
    es = es or ES.from_settings()
    data, detected = _to_bytes(img)
    uri = f"data:{mime or detected};base64," + base64.b64encode(data).decode("ascii")
    body = {"input": [{"content": {"type": "image", "format": "base64", "value": uri}}]}
    return _post(es, body, timeout, retries)


def omni_text(text: str, es: ES | None = None, timeout: float = 30, retries: int = 2) -> list[float]:
    """Text query -> 1024-d vector in the same space as the page images."""
    es = es or ES.from_settings()
    return _post(es, {"input": [text]}, timeout, retries)
