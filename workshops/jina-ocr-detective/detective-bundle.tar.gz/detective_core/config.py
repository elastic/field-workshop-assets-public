"""Settings loaded from the environment and an optional .env file (no python-dotenv needed on the VM)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_LLM_PREFERENCE = "google-gemini-3.0-flash,google-gemini-3.5-flash,anthropic-claude-4.5-haiku"
TRACK_ROOT = Path(__file__).resolve().parent.parent


def parse_dotenv(path: Path) -> dict[str, str]:
    """Minimal KEY=VALUE parser: comments, blank lines, optional `export`, optional quotes."""
    out: dict[str, str] = {}
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[len("export "):]
        key, _, val = line.partition("=")
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        out[key.strip()] = val
    return out


def _split_list(s: str) -> list[str]:
    return [x.strip() for x in s.split(",") if x.strip()]


@dataclass
class Settings:
    es_url: str
    es_api_key: str = field(repr=False, default="")
    index_prefix: str = ""
    llm_preference: list[str] = field(default_factory=lambda: _split_list(DEFAULT_LLM_PREFERENCE))
    kibana_url: str | None = None
    corpus_dir: str | None = None
    # EIS endpoints (verified in Step 0). Overridable only for tests.
    ocr_inference_id: str = ".jina-ocr-v1-chat_completion"
    omni_inference_id: str = ".jina-embeddings-v5-omni-small"
    text_embedding_inference_id: str = ".jina-embeddings-v5-text-small"

    @classmethod
    def from_env(cls, dotenv_path: str | os.PathLike | None = None, environ: dict | None = None) -> "Settings":
        """Environment variables win over the .env file.

        .env lookup when dotenv_path is None: $DOTENV_PATH, ./.env, then <track root>/.env.
        """
        env: dict[str, str] = {}
        candidates = []
        if dotenv_path:
            candidates.append(Path(dotenv_path))
        else:
            if os.environ.get("DOTENV_PATH"):
                candidates.append(Path(os.environ["DOTENV_PATH"]))
            candidates += [Path.cwd() / ".env", TRACK_ROOT / ".env"]
        for c in candidates:
            if c.is_file():
                env.update(parse_dotenv(c))
                break
        env.update(os.environ if environ is None else environ)
        es_url = env.get("ES_URL", "").rstrip("/")
        if not es_url:
            raise RuntimeError("ES_URL is not set (environment or .env)")
        return cls(
            es_url=es_url,
            es_api_key=env.get("ES_API_KEY", ""),
            index_prefix=env.get("INDEX_PREFIX", ""),
            llm_preference=_split_list(env.get("LLM_PREFERENCE") or DEFAULT_LLM_PREFERENCE),
            kibana_url=env.get("KIBANA_URL") or None,
            corpus_dir=env.get("CORPUS_DIR") or None,
        )
