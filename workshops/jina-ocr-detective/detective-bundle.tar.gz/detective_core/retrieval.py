"""The three partners' retrieval, in one place so the backend (`/api/ask`) and `validate_case.py` run identical queries.

  Rookie    semantic query on `rookie_text` (what pymupdf get_text() saw), top 4; excerpt text = `rookie_raw`.
  Photo Lab omni embedding of the question -> knn on `image_vector`, k=3; no LLM, no text.
  Detective rrf( lexical: match on `ocr_text` + terms on `entities` x3 , semantic on `ocr_semantic` ), top 5,
            highlight on `ocr_text`; excerpt text = `ocr_text` (OCR markdown with tables turned into pipe rows).

All functions take the *unprefixed or prefixed* index through `prefix` + the base name (`evidence-*`).
"""
from __future__ import annotations

import html
import re
from dataclasses import dataclass, field

from .embed import omni_text
from .es import ES
from .extract import entities
from .index import index_name
from .llm import LLM
from .prompts import PARTNER_SYSTEM_PROMPT, build_user_prompt, format_excerpt

ROOKIE_SIZE = 4
PHOTOLAB_K = 3
DETECTIVE_SIZE = 5
DETECTIVE_RANK_WINDOW = 20
ENTITY_BOOST = 3

_EXCLUDE = ["image_vector", "ocr_semantic", "rookie_text"]

# Lexical branch hygiene. `ocr_text` keeps stop words (the analyzer is fixed by the contract), so a raw question such as
# "In which direction did the white van leave the loading dock?" matches every long page on "the", "in", "did" and drags
# the right page out of the fused top 5. Fix at query time: drop English function words, and require most of the rest
# ("2<75%": all terms when there are 1-2, else 75%). The semantic branch is untouched.
LEXICAL_STOPWORDS = frozenset("""a an the of in on at to for from by with and or is are was were be been being which what
who whom whose where when how why did do does done has have had that this these those it its as into after before
about than then there their they he she his her you your i we our not no can could would should will shall may might
say says said so if""".split())
LEXICAL_MIN_SHOULD_MATCH = "2<75%"


def lexical_terms(question: str) -> str:
    """The question minus English function words (falls back to the whole question if nothing is left)."""
    toks = re.findall(r"[^\W_]+(?:[-'][^\W_]+)*", question)
    keep = [t for t in toks if t.lower() not in LEXICAL_STOPWORDS]
    return " ".join(keep) or question


@dataclass
class Hit:
    doc_id: str
    exhibit: str
    page: int
    score: float
    text: str = ""                       # what the LLM sees (rookie_raw / ocr_text); "" for Photo Lab
    snippet_html: str = ""               # highlighted fragment(s), HTML-safe
    source: dict = field(default_factory=dict, repr=False)
    title: str = ""                      # exhibit title; part of every excerpt header
    image_path: str = ""                 # Photo Lab: "pages/<doc>-p<n>.jpg" or "figures/<doc>-p<n>-f<k>.jpg" (relative to CORPUS_DIR)
    kind: str = ""                       # Photo Lab: "page" | "figure"
    figure_n: int | None = None          # Photo Lab figures: 1-based figure number on the page

    def to_dict(self) -> dict:
        return {"doc_id": self.doc_id, "exhibit": self.exhibit, "page": self.page, "score": self.score,
                "text": self.text, "snippet_html": self.snippet_html, "title": self.title,
                "image_path": self.image_path, "kind": self.kind, "figure_n": self.figure_n}


# ------------------------------------------------------------------------------------------------ request bodies
def rookie_body(question: str, size: int = ROOKIE_SIZE) -> dict:
    return {"size": size, "_source": {"excludes": _EXCLUDE},
            "query": {"semantic": {"field": "rookie_text", "query": question}}}


def photolab_body(vector: list[float], k: int = PHOTOLAB_K, num_candidates: int = 50) -> dict:
    return {"size": k, "_source": {"excludes": _EXCLUDE},
            "knn": {"field": "image_vector", "query_vector": vector, "k": k, "num_candidates": num_candidates}}


def detective_body(question: str, size: int = DETECTIVE_SIZE, rank_window_size: int = DETECTIVE_RANK_WINDOW) -> dict:
    ents = entities(question, ignore_case=True)
    lexical = {"bool": {"should": [
        {"match": {"ocr_text": {"query": lexical_terms(question), "minimum_should_match": LEXICAL_MIN_SHOULD_MATCH}}},
        {"terms": {"entities": ents, "boost": ENTITY_BOOST}},
    ]}}
    return {
        "size": size, "_source": {"excludes": _EXCLUDE},
        "retriever": {"rrf": {
            "retrievers": [
                {"standard": {"query": lexical}},
                {"standard": {"query": {"semantic": {"field": "ocr_semantic", "query": question}}}},
            ],
            "rank_window_size": rank_window_size, "rank_constant": 60}},
        "highlight": {"encoder": "html", "pre_tags": ["<mark>"], "post_tags": ["</mark>"],
                      "fields": {"ocr_text": {"number_of_fragments": 2, "fragment_size": 220}}},
    }


# ------------------------------------------------------------------------------------------------ searches
def _hits(resp: dict, text_field: str | None) -> list[Hit]:
    out = []
    for h in resp.get("hits", {}).get("hits", []):
        src = h.get("_source", {})
        text = (src.get(text_field) or "") if text_field else ""
        frags = (h.get("highlight") or {}).get("ocr_text") or []
        snippet = " … ".join(frags) if frags else (html.escape(text[:220]) if text else "")
        out.append(Hit(doc_id=src.get("doc_id", ""), exhibit=src.get("exhibit", ""), page=int(src.get("page") or 1),
                       score=float(h.get("_score") or 0.0), text=text, snippet_html=snippet, source=src,
                       title=src.get("title") or "", image_path=src.get("image_path") or "", kind=src.get("kind") or "",
                       figure_n=src.get("figure_n")))
    return out


def search_rookie(es: ES, prefix: str, question: str, size: int = ROOKIE_SIZE) -> list[Hit]:
    r = es.post(f"{index_name(prefix, 'evidence-rookie')}/_search", json=rookie_body(question, size))
    return _hits(r, "rookie_raw")


def search_photolab(es: ES, prefix: str, question: str | None = None, vector: list[float] | None = None,
                    k: int = PHOTOLAB_K) -> list[Hit]:
    """Pass `question` (embedded live with omni-small) or a ready `vector` (image->image 'find similar')."""
    if vector is None:
        vector = omni_text(question, es=es)
    r = es.post(f"{index_name(prefix, 'evidence-photolab')}/_search", json=photolab_body(vector, k))
    return _hits(r, None)


def search_detective(es: ES, prefix: str, question: str, size: int = DETECTIVE_SIZE, scope: str = "case") -> list[Hit]:
    base = "evidence-mine" if scope == "mine" else "evidence-detective"
    r = es.post(f"{index_name(prefix, base)}/_search", json=detective_body(question, size))
    return _hits(r, "ocr_text")


# ------------------------------------------------------------------------------------------------ answering
def excerpts(hits: list[Hit]) -> list[str]:
    """`[EX-07 p1 \u00b7 <title>] <text>` blocks (same header for both partners); hits with no text are skipped."""
    return [format_excerpt(h.exhibit, h.page, h.text, h.title) for h in hits if h.text and h.text.strip()]


def partner_answer(llm: LLM, question: str, hits: list[Hit], timeout: float = 30) -> str:
    """Rookie and Detective both call this: same LLM, same system prompt, same excerpt format."""
    return llm.chat(PARTNER_SYSTEM_PROMPT, build_user_prompt(question, excerpts(hits)), timeout=timeout)
