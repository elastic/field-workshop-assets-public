"""Shared retry/backoff helper for EIS calls (429, 5xx, timeouts, dropped connections)."""
from __future__ import annotations

import random
import time

import requests

from .es import ESError
from .sse import SSEError

RETRYABLE_STATUS = {408, 429, 500, 502, 503, 504}


def is_retryable(exc: BaseException) -> bool:
    if isinstance(exc, ESError):
        return exc.status in RETRYABLE_STATUS
    return isinstance(exc, (requests.Timeout, requests.ConnectionError, requests.exceptions.ChunkedEncodingError,
                            TimeoutError, SSEError))


def backoff_sleep(attempt: int, base: float = 1.0, cap: float = 10.0) -> None:
    """attempt starts at 1. Exponential with jitter."""
    time.sleep(min(cap, base * 2 ** (attempt - 1)) * (0.75 + 0.5 * random.random()))
