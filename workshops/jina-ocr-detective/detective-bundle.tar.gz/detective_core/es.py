"""Thin requests-based Elasticsearch client (ApiKey auth). Works on Serverless and on the Instruqt VM."""
from __future__ import annotations

import json as _json
import time
from typing import Any

import requests
from requests.adapters import HTTPAdapter

RETRY_STATUS = {429, 502, 503, 504}


class ESError(RuntimeError):
    def __init__(self, status: int, body: Any, method: str = "", path: str = ""):
        self.status, self.body, self.method, self.path = status, body, method, path
        super().__init__(f"{method} {path} -> HTTP {status}: {str(body)[:500]}")

    @property
    def reason(self) -> str:
        """Best-effort short reason from an ES error body."""
        try:
            return self.body["error"]["reason"]
        except Exception:
            return str(self.body)[:300]


class ES:
    def __init__(self, url: str, api_key: str = "", timeout: float = 60, retries: int = 2, pool_size: int = 32):
        self.url = url.rstrip("/")
        self.timeout = timeout
        self.retries = retries
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=pool_size, pool_maxsize=pool_size)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)
        self.session.headers["Content-Type"] = "application/json"
        if api_key:
            self.session.headers["Authorization"] = f"ApiKey {api_key}"

    @classmethod
    def from_settings(cls, settings=None, **kw) -> "ES":
        from .config import Settings

        s = settings or Settings.from_env()
        return cls(s.es_url, s.es_api_key, **kw)

    def _url(self, path: str) -> str:
        return f"{self.url}/{path.lstrip('/')}"

    def request(self, method: str, path: str, json: Any = None, params: dict | None = None,
                timeout: float | None = None, retries: int | None = None, data: bytes | None = None,
                headers: dict | None = None) -> dict:
        """Returns the parsed JSON body; raises ESError on non-2xx (after retrying 429/5xx and connection errors)."""
        retries = self.retries if retries is None else retries
        attempt = 0
        while True:
            try:
                r = self.session.request(method, self._url(path), json=json, data=data, params=params,
                                         headers=headers, timeout=timeout or self.timeout)
            except (requests.ConnectionError, requests.exceptions.ChunkedEncodingError):
                if attempt >= retries:
                    raise
                attempt += 1
                time.sleep(min(8, 0.75 * 2 ** attempt))
                continue
            if r.status_code in RETRY_STATUS and attempt < retries:
                attempt += 1
                time.sleep(min(8, 0.75 * 2 ** attempt))
                continue
            if r.status_code >= 400:
                try:
                    body = r.json()
                except ValueError:
                    body = r.text
                raise ESError(r.status_code, body, method, path)
            if not r.content:
                return {}
            try:
                return r.json()
            except ValueError:
                return {"_raw": r.text}

    def get(self, path, json=None, **kw): return self.request("GET", path, json=json, **kw)
    def post(self, path, json=None, **kw): return self.request("POST", path, json=json, **kw)
    def put(self, path, json=None, **kw): return self.request("PUT", path, json=json, **kw)
    def delete(self, path, json=None, **kw): return self.request("DELETE", path, json=json, **kw)

    def exists(self, path: str) -> bool:
        r = self.session.head(self._url(path), timeout=self.timeout)
        return r.status_code == 200

    def stream_post(self, path: str, json: Any, timeout: float = 60) -> requests.Response:
        """POST that returns the live streaming Response (status 200 guaranteed; ESError otherwise).

        The caller must consume or close it. Use detective_core.sse to read it.
        """
        r = self.session.post(self._url(path), json=json, stream=True, timeout=timeout)
        if r.status_code != 200:
            r.encoding = "utf-8"
            raw = r.text.lstrip("\ufeff")
            try:
                body = r.json()
            except ValueError:
                body = raw
            r.close()
            raise ESError(r.status_code, body, "POST", path)
        return r

    def bulk(self, ndjson_bytes: bytes | str, refresh: bool | str = False, raise_on_error: bool = False,
             timeout: float = 300) -> dict:
        """POST /_bulk. Returns the response; with raise_on_error, raises ESError listing the first failures."""
        if isinstance(ndjson_bytes, str):
            ndjson_bytes = ndjson_bytes.encode("utf-8")
        if not ndjson_bytes.endswith(b"\n"):
            ndjson_bytes += b"\n"
        params = {"refresh": str(refresh).lower()} if refresh else None
        resp = self.request("POST", "_bulk", data=ndjson_bytes, params=params, timeout=timeout,
                            headers={"Content-Type": "application/x-ndjson"})
        if raise_on_error and resp.get("errors"):
            bad = [i for item in resp.get("items", []) for i in item.values() if i.get("error")]
            raise ESError(500, {"bulk_errors": len(bad), "first": bad[:3]}, "POST", "_bulk")
        return resp

    def esql(self, query: str, params: list | None = None, timeout: float = 60) -> dict:
        """Run an ES|QL query; returns {"columns": [...], "values": [...]}."""
        body: dict = {"query": query}
        if params:
            body["params"] = params
        r = self.request("POST", "_query", json=body, timeout=timeout)
        return {"columns": r.get("columns", []), "values": r.get("values", [])}


def dumps_ndjson(rows: list[dict]) -> bytes:
    return ("\n".join(_json.dumps(r, ensure_ascii=False) for r in rows) + "\n").encode("utf-8")
