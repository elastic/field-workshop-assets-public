"""Prompts shared by every pipeline. One partner prompt for BOTH the Rookie and the Detective (plan 2.6a rule 2).

The prompt is deliberately neutral: no persona, no instruction that makes either partner bluff or abstain more.
Any difference in answers must come from the excerpts (the extraction), not from the prompt.
"""
from __future__ import annotations

PARTNER_SYSTEM_PROMPT = (
    "You answer a question using only the document excerpts provided in the user message. "
    "Each excerpt starts with a header like [EX-07 p1 \u00b7 Hotel bill]: exhibit, page and document title. "
    "Cite every fact you use with the exhibit and page of the excerpt it came from, written exactly like [EX-07 p1]. "
    "If the excerpts do not contain the answer, say that the excerpts do not contain it. "
    "Answer in English, in at most 3 sentences."
)

# "Translate to English" in the page viewer (app/backend/translate.py). Not a partner prompt. The source text is the
# Detective's OCR markdown of one page, never the image and never the Rookie's text layer.
TRANSLATE_SYSTEM_PROMPT = (
    "You translate OCR text from a document into English for an investigator.\n"
    "- Translate everything.\n"
    "- Keep the Markdown and any HTML table structure.\n"
    "- Keep numbers, dates, times, amounts, codes, IDs and personal names exactly as written.\n"
    "- For a place name, write the original followed by the English name in parentheses the first time it appears, "
    "if they differ.\n"
    "- Do not add, explain, summarize, infer, or correct anything. If a part is garbled or unreadable, leave it as it is.\n"
    "- If the text is already English, return it unchanged.\n"
    "- Output only the translation."
)

NO_EXCERPTS = "(no excerpts were retrieved)"


def excerpt_tag(exhibit: str, page: int, title: str | None = None) -> str:
    """The excerpt header: `[EX-07 p1 \u00b7 Hotel bill]` (just `[EX-07 p1]` when there is no title)."""
    return f"[{exhibit} p{page} \u00b7 {title.strip()}]" if title and title.strip() else f"[{exhibit} p{page}]"


def format_excerpt(exhibit: str, page: int, text: str, title: str | None = None) -> str:
    """One block per hit: `[EX-07 p1 \u00b7 <title>] <text>`. Identical for the Rookie and the Detective."""
    return f"{excerpt_tag(exhibit, page, title)} {text.strip()}"


def build_user_prompt(question: str, excerpts: list[str]) -> str:
    """The user message for both partners: excerpt blocks, then the question."""
    body = "\n\n".join(excerpts) if excerpts else NO_EXCERPTS
    return f"Excerpts:\n\n{body}\n\nQuestion: {question.strip()}"


# Build-time receipt field extraction. Not a partner prompt: only used by extract.receipt_fields.
RECEIPT_SYSTEM_PROMPT = (
    "You extract fields from the text of one payment document (receipt, invoice, ticket or rental agreement). "
    "The text may contain OCR errors, HTML tables or noise. Reply with a single JSON object and nothing else, with "
    "exactly these keys: "
    '"amount_eur" (the final total amount charged or paid, as a JSON number with a dot as decimal separator, in euros; '
    "null if no total is clearly stated in the text; never add up line items yourself), "
    '"merchant" (the business name, null if absent), '
    '"city" (the city of the business, null if absent), '
    '"date" (the issue or check-out date as YYYY-MM-DD, null if absent). '
    "Never guess: use null when the text does not state the value. Do not add commentary."
)
