"""Server-sent-event reader for the EIS `_stream` routes.

Gotchas found in Step 0: `requests` decodes SSE as Latin-1 unless forced (mojibake: "DÃCLARATION"),
and each line may start with a BOM. We read raw bytes and decode UTF-8 ourselves.
"""
from __future__ import annotations

import json
import time
from typing import Iterator

BOM = "﻿"


class SSEError(RuntimeError):
    """An `error` event arrived inside an otherwise-200 stream."""


def _lines(resp) -> Iterator[str]:
    try:
        resp.encoding = "utf-8"
    except Exception:  # fake responses in tests
        pass
    for raw in resp.iter_lines():  # bytes (or str from a fake); no decode_unicode on purpose
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", errors="replace")
        yield raw.lstrip(BOM)


def iter_sse_events(resp, deadline: float | None = None) -> Iterator[dict]:
    """Yield parsed JSON objects from `data:` lines; stop at `[DONE]`.

    deadline: absolute time.time() value; raises TimeoutError once exceeded (requests' timeout is per read,
    not total, and a trickling stream never trips it).
    """
    try:
        for line in _lines(resp):
            if deadline is not None and time.time() > deadline:
                raise TimeoutError("SSE stream exceeded its deadline")
            line = line.strip()
            if not line or not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                return
            try:
                ev = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if isinstance(ev, dict) and "error" in ev and "choices" not in ev:
                raise SSEError(str(ev["error"])[:400])
            yield ev
    finally:
        close = getattr(resp, "close", None)
        if close:
            close()


def iter_sse_text(resp, deadline: float | None = None) -> Iterator[str]:
    """Yield the text pieces (`choices[].delta.content`) of a chat_completion stream."""
    for ev in iter_sse_events(resp, deadline):
        for choice in ev.get("choices", []) or []:
            piece = (choice.get("delta") or {}).get("content")
            if piece:
                yield piece
