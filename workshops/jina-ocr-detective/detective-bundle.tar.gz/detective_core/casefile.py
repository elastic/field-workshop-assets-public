"""Helpers for reading case.yaml (CONTRACT section 2). Shared by build_corpus.py and validate_case.py."""
from __future__ import annotations

from pathlib import Path

import yaml

from .normalize import norm, parse_amount


# Ingest routing (2026-10-16 decision): jina-ocr-v1 parses DOCUMENTS. Camera photos (case.yaml `type: photo`) are never
# sent to it: on EIS the model ignores text instructions, so a photo comes back as a free-form description that can
# invent details, and that is an undocumented side effect, not a capability. Photos go only to the image index
# (Photo Lab). The Detective keeps a record per page (empty `ocr_md`, `ocr_skipped: "photo"`, no searchable text) so the
# page viewer and the locker keep working. Player uploads are documents by premise and are always OCR'd (app/backend/upload.py).
SKIP_OCR_DOC_TYPES = frozenset({"photo"})


def ocr_skip_reason(doc: dict) -> str | None:
    """The `ocr_skipped` marker for a case doc ("photo"), or None when the doc is read by OCR as usual."""
    t = doc.get("type")
    return t if t in SKIP_OCR_DOC_TYPES else None


def load_case(path: str | Path) -> dict:
    case = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    for key in ("docs", "clues", "route"):
        case.setdefault(key, [])
    case.setdefault("photo_only", [])
    return case


def docs_by_id(case: dict) -> dict[str, dict]:
    return {d["id"]: d for d in case["docs"]}


def doc_text_of_truth(doc: dict) -> float | None:
    """The true euro amount of a receipt: ground_truth.amount_eur | total_eur, else content.total."""
    gt = doc.get("ground_truth") or {}
    for k in ("amount_eur", "total_eur", "total"):
        if gt.get(k) is not None:
            return parse_amount(gt[k])
    return parse_amount((doc.get("content") or {}).get("total"))


def clue_answers(clue: dict) -> list[str]:
    return [str(a) for a in [clue.get("answer"), *(clue.get("answer_aliases") or [])] if a not in (None, "")]


def as_list(v) -> list:
    return [] if v is None else (v if isinstance(v, (list, tuple)) else [v])


def suspects_matching_warrant(case: dict) -> list[str]:
    """Suspect ids whose traits satisfy every trait in warrant.traits (must be exactly the thief)."""
    want = (case.get("warrant") or {}).get("traits") or {}
    out = []
    for s in case.get("suspects", []):
        t = s.get("traits") or {}
        ok = True
        for key, wv in want.items():
            have = {norm(x) for x in as_list(t.get(key))}
            if not {norm(x) for x in as_list(wv)} <= have:
                ok = False
        if ok:
            out.append(s["id"])
    return out
