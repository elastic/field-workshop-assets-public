"""jina-ocr-v1 over EIS (one image per call, SSE, UTF-8) plus page orientation fixing.

Step 0 facts: PDFs are rejected, text instructions are ignored, tables come back as HTML <table>, and an upside-down
page can hallucinate (a 180 degree handwritten postcard scored 0/4). So every page goes through `orient()` first.

The model parses DOCUMENTS. A pure photo makes it return a free-form description that can invent details; that is an
undocumented side effect, not a capability, so the corpus build never sends case photos here (casefile.SKIP_OCR_DOC_TYPES).
"""
from __future__ import annotations

import base64
import io
import os
import re
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

from PIL import Image, ImageOps

from .es import ES
from .retry import backoff_sleep, is_retryable
from .sse import iter_sse_events

OCR_MODEL_NAME = "jina-ocr-v1"
OCR_INFERENCE_ID = ".jina-ocr-v1-chat_completion"

# Tesseract OSD "Orientation confidence": clean printed pages score 6+, handwriting-font cards ~1.2-2.1 (and were
# detected correctly at every rotation), while the wrong calls seen on text-poor props sat at 0.26-0.53.
DEFAULT_OSD_MIN_CONFIDENCE = float(os.environ.get("OSD_MIN_CONFIDENCE", "1.5"))


class OcrError(RuntimeError):
    pass


@dataclass
class OcrResult:
    text: str
    secs: float
    usage: dict | None = None
    model: str = OCR_MODEL_NAME
    attempts: int = 1
    meta: dict = field(default_factory=dict)


def _data_uri(img_bytes: bytes, mime: str) -> str:
    return f"data:{mime};base64," + base64.b64encode(img_bytes).decode("ascii")


def ocr_image(img_bytes: bytes, mime: str = "image/jpeg", es: ES | None = None, timeout: float = 60,
              retries: int = 1, endpoint: str | None = None) -> OcrResult:
    """OCR one image. `secs` is the total wall time including retries (what the user actually waited).

    Retries (exponential backoff) on 429, 5xx, timeouts and mid-stream errors; raises OcrError afterwards.
    `timeout` is a total per-attempt budget, not a per-read one.
    """
    if es is None:
        es = ES.from_settings()
    path = f"_inference/chat_completion/{endpoint or OCR_INFERENCE_ID}/_stream"
    body = {"messages": [{"role": "user", "content": [
        {"type": "image_url", "image_url": {"url": _data_uri(img_bytes, mime)}}]}]}
    t0 = time.time()
    attempt = 0
    last: BaseException | None = None
    while attempt <= retries:
        attempt += 1
        try:
            deadline = time.time() + timeout
            resp = es.stream_post(path, body, timeout=timeout)
            pieces: list[str] = []
            usage = None
            model = None
            for ev in iter_sse_events(resp, deadline):
                if ev.get("usage"):
                    usage = ev["usage"]
                model = ev.get("model") or model
                for ch in ev.get("choices", []) or []:
                    piece = (ch.get("delta") or {}).get("content")
                    if piece:
                        pieces.append(piece)
            return OcrResult(text="".join(pieces), secs=round(time.time() - t0, 2), usage=usage,
                             model=OCR_MODEL_NAME if not model else _clean_model(model), attempts=attempt)
        except Exception as exc:  # noqa: BLE001
            last = exc
            if attempt > retries or not is_retryable(exc):
                break
            backoff_sleep(attempt)
    raise OcrError(f"OCR failed after {attempt} attempt(s): {last}") from last


def _clean_model(model: str) -> str:
    return OCR_MODEL_NAME if "jina-ocr" in model else model


def image_to_bytes(img: Image.Image, fmt: str = "JPEG", quality: int = 85) -> tuple[bytes, str]:
    buf = io.BytesIO()
    img = img.convert("RGB") if fmt == "JPEG" else img
    img.save(buf, fmt, quality=quality) if fmt == "JPEG" else img.save(buf, fmt)
    return buf.getvalue(), "image/jpeg" if fmt == "JPEG" else "image/png"


# ---------------------------------------------------------------------------------------------- orientation
_ROTATE_RE = re.compile(r"^Rotate:\s*(\d+)", re.M)
_CONF_RE = re.compile(r"^Orientation confidence:\s*([0-9.]+)", re.M)


def parse_osd(stdout: str) -> tuple[int, float] | None:
    """Parse `tesseract <img> - --psm 0` output into (clockwise degrees to rotate, confidence)."""
    m, c = _ROTATE_RE.search(stdout), _CONF_RE.search(stdout)
    if not m or not c:
        return None
    return int(m.group(1)) % 360, float(c.group(1))


def detect_rotation(img: Image.Image, timeout: float = 30) -> tuple[int, float] | None:
    """Tesseract OSD. Returns (degrees clockwise needed to make the page upright, confidence) or None when unsure."""
    exe = shutil.which("tesseract")
    if not exe:
        return None
    g = ImageOps.exif_transpose(img).convert("L")
    if max(g.size) > 2000:  # OSD does not need full resolution
        g.thumbnail((2000, 2000))
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "osd.png"
        g.save(p)
        try:
            r = subprocess.run([exe, str(p), "-", "--psm", "0"], capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return None
    return parse_osd(r.stdout + "\n" + r.stderr)


def orient_with_info(img: Image.Image, min_confidence: float = DEFAULT_OSD_MIN_CONFIDENCE) -> tuple[Image.Image, dict]:
    """Like orient(), also returning what happened: {"exif": bool, "osd_deg": int|None, "osd_conf": float|None, "rotated_deg": int}."""
    exif_changed = img.getexif().get(0x0112, 1) not in (0, 1)
    img = ImageOps.exif_transpose(img)
    info = {"exif": bool(exif_changed), "osd_deg": None, "osd_conf": None, "rotated_deg": 0}
    det = detect_rotation(img)
    if not det:
        return img, info
    deg, conf = det
    info["osd_deg"], info["osd_conf"] = deg, conf
    if deg == 0 or conf < min_confidence:
        return img, info
    info["rotated_deg"] = deg
    # OSD "Rotate: N" = degrees clockwise to correct; PIL rotates counter-clockwise.
    return img.rotate(-deg, expand=True, fillcolor=(255, 255, 255) if img.mode == "RGB" else 255), info


def orient(img: Image.Image, min_confidence: float = DEFAULT_OSD_MIN_CONFIDENCE) -> Image.Image:
    """EXIF transpose, then Tesseract OSD. Rotates only when OSD is confident; otherwise a no-op."""
    return orient_with_info(img, min_confidence)[0]
