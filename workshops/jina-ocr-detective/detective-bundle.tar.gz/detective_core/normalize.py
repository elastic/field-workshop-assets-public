"""Answer normalization shared by game.json hashing, the validator and the backend.

norm(x) = NFKD, strip accents, casefold, drop every non-alphanumeric character.
"""
from __future__ import annotations

import hashlib
import re
import unicodedata


def norm(x) -> str:
    s = unicodedata.normalize("NFKD", str(x))
    s = "".join(ch for ch in s if not unicodedata.combining(ch)).casefold()
    return "".join(ch for ch in s if ch.isalnum())


def tokens(x) -> list[str]:
    """Accent-stripped, casefolded alphanumeric words."""
    s = unicodedata.normalize("NFKD", str(x))
    s = "".join(ch for ch in s if not unicodedata.combining(ch)).casefold()
    return re.findall(r"[^\W_]+", s)


def answer_hash(salt: str, x) -> str:
    """sha256(salt + norm(x)) as hex, the format used by game.json."""
    return hashlib.sha256((salt + norm(x)).encode("utf-8")).hexdigest()


def evidence_key(trait: str, value, doc_id: str) -> str:
    """What gets hashed for one warrant proof: 'languages|it|r2-postcard' (game.json warrant.evidence_hashes)."""
    return f"{trait}|{value}|{doc_id}"


def dossier_key(suspect_id: str, trait: str, value, rank: int = 0) -> str:
    """What gets hashed for one dossier trait of one suspect (game.json warrant.dossier_hashes). `rank` is the value's position
    in the dossier's own list (languages are listed in an order), so the backend can read the list back in that order."""
    return f"dossier|{suspect_id}|{trait}|{rank}|{value}"


def amount_str(value) -> str:
    """Canonical amount string that gets hashed for the Ledger: '%.2f' % value."""
    return "%.2f" % float(value)


def contains(text: str, needle: str) -> bool:
    """Is `needle` in `text`, ignoring case, diacritics and punctuation, aligned to word boundaries?

    The needle's tokens may be written joined or split in the text ("NJ 40421" ~ "NJ40421", "Köln Hbf" ~ "koln-hbf"),
    but a match never straddles part of a word, so "Rome" does not hit "from Em Krützche" and "12" does not hit "1234".
    """
    nt = tokens(needle)
    if not nt:
        return False
    ns = "".join(nt)
    tt = tokens(text)
    for i in range(len(tt)):
        acc = ""
        for j in range(i, len(tt)):
            acc += tt[j]
            if acc == ns:
                return True
            if len(acc) >= len(ns) or not ns.startswith(acc):
                break
    return False


def contains_any(text: str, needles) -> bool:
    return any(contains(text, n) for n in needles if str(n).strip())


def contains_word(text: str, word: str) -> bool:
    """Whole-word match (accent- and case-insensitive); used for 'caption must not contain red'."""
    w = tokens(word)
    t = tokens(text)
    return bool(w) and any(t[i:i + len(w)] == w for i in range(len(t) - len(w) + 1))


_NUM_RE = re.compile(r"[-+]?\d[\d.,\s  ']*")


def parse_amount(s) -> float | None:
    """Parse '476,50', '1.640,90', '1,640.90', '4 200,00', 'EUR 612' into a float; None when not a number."""
    if isinstance(s, (int, float)) and not isinstance(s, bool):
        return float(s)
    if s is None:
        return None
    m = _NUM_RE.search(str(s))
    if not m:
        return None
    t = re.sub(r"[\s  ']", "", m.group(0)).rstrip(".,")
    if not t:
        return None
    sign = -1.0 if t.startswith("-") else 1.0
    t = t.lstrip("+-")
    if "." in t and "," in t:
        dec = "." if t.rfind(".") > t.rfind(",") else ","
        t = t.replace("," if dec == "." else ".", "").replace(dec, ".")
    elif "," in t or "." in t:
        sep = "," if "," in t else "."
        parts = t.split(sep)
        if len(parts) > 2 or (len(parts[-1]) == 3 and len(parts[0]) <= 3 and parts[0] not in ("0", "")):
            t = t.replace(sep, "")          # thousands separator(s)
        else:
            t = t.replace(sep, ".")         # decimal separator
    try:
        return sign * float(t)
    except ValueError:
        return None


AMOUNT_TOKEN_RE = re.compile(r"\d{1,3}(?:[.,\s\u00a0\u202f]\d{3})+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?")
_AMOUNT_ANSWER_RE = re.compile(r"\s*(?:EUR|€)?\s*\d[\d.,\s\u00a0\u202f]*\s*(?:EUR|€)?\s*", re.I)


def is_amount_answer(answer) -> bool:
    """True for a plain money amount ('612,00', 'EUR 4.200.000'): those are compared numerically, not as text,
    because norm() drops punctuation and would equate '4.200.000' with the misread '42.000,00'."""
    return bool(_AMOUNT_ANSWER_RE.fullmatch(str(answer))) and parse_amount(answer) is not None


def amount_in_text(amount: float, text: str) -> bool:
    """True if some number written in `text` parses to `amount`."""
    for tok in AMOUNT_TOKEN_RE.findall(text or ""):
        v = parse_amount(tok)
        if v is not None and abs(v - amount) < 0.005:
            return True
    return False


def answer_present(text: str, answers) -> bool:
    """Is any accepted answer (or alias) present in `text`? Amounts numerically, everything else via contains()."""
    for a in answers:
        a = str(a)
        if not a.strip():
            continue
        if is_amount_answer(a):
            if amount_in_text(parse_amount(a), text):
                return True
        elif contains(text, a):
            return True
    return False


_REFUSAL_RE = re.compile(
    r"(?:do|does|did|can|could)\s*(?:not|n['\u2019]t)\s+(?:contain|include|mention|provide|specify|state|say|show|"
    r"describe|find|determine)|(?:contains?|includes?|mentions?|provides?)\s+no\b|\bno\s+(?:information|mention|record|"
    r"evidence)\b|\bnot\s+(?:enough|sufficient)\b|\bunable\s+to\b|\bcannot\b", re.I)


def is_refusal(answer: str) -> bool:
    """True when the answer's first sentence says the excerpts do not contain the answer (the shared prompt asks the
    model to say so). Such an answer may still *quote* the wanted string while refusing, so it must not count as right."""
    first = re.split(r"(?<=[.!?])\s+|\n", (answer or "").strip(), maxsplit=1)[0]
    return bool(_REFUSAL_RE.search(first))
