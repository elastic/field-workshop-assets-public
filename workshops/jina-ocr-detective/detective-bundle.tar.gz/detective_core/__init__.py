"""detective_core: shared Python library for the Document Detective workshop.

Used by the corpus build, the validator, the FastAPI backend and the bonus pipeline.
Nothing event-specific lives here (the engine reads only case.yaml).
"""

__version__ = "0.1.0"
