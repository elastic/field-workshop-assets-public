"""PDF handling: what the Rookie sees (the text layer) and the page rasters players and the Detective see."""
from __future__ import annotations

import io

import pymupdf
from PIL import Image


def rasterize_pdf(pdf_bytes: bytes, dpi: int = 200) -> list[Image.Image]:
    """One RGB PIL image per page, rendered with pymupdf (200 dpi is what jina-ocr-v1 was validated at)."""
    out = []
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as doc:
        for page in doc:
            pix = page.get_pixmap(dpi=dpi)
            out.append(Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB"))
    return out


def rookie_text(pdf_bytes: bytes) -> list[str]:
    """The Rookie's view: `page.get_text()` in default order, exactly as the naive pipeline does. May be ""."""
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as doc:
        return [page.get_text() for page in doc]


def page_count(pdf_bytes: bytes) -> int:
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as doc:
        return doc.page_count


def extract_figures(pdf_bytes: bytes, doc_id: str, out_dir, min_px: int = 120) -> list[tuple[int, int, "Path"]]:
    """Embedded raster images of a (born-digital) PDF, saved as JPEG to out_dir/{doc_id}-p{page}-f{k}.jpg.

    Text extraction (`get_text`) never sees these pictures, so the Photo Lab pipeline indexes them separately.
    Only images at least `min_px` on BOTH sides count (logos and rules are smaller). An image reused on a page is
    returned once. Returns [(page_no, figure_no, path)], page_no and figure_no starting at 1.
    """
    from pathlib import Path

    out_dir = Path(out_dir)
    found: list[tuple[int, int, Path]] = []
    with pymupdf.open(stream=pdf_bytes, filetype="pdf") as doc:
        for pno, page in enumerate(doc, 1):
            seen: set[int] = set()
            k = 0
            for info in page.get_images(full=True):
                xref = info[0]
                if xref in seen:
                    continue
                seen.add(xref)
                ex = doc.extract_image(xref)
                if not ex or ex["width"] < min_px or ex["height"] < min_px:
                    continue
                k += 1
                path = out_dir / f"{doc_id}-p{pno}-f{k}.jpg"
                out_dir.mkdir(parents=True, exist_ok=True)
                if ex.get("ext") in ("jpeg", "jpg"):
                    path.write_bytes(ex["image"])
                else:
                    Image.open(io.BytesIO(ex["image"])).convert("RGB").save(path, "JPEG", quality=90)
                found.append((pno, k, path))
    return found
