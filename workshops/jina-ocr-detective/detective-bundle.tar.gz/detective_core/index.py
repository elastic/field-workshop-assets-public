"""Index creation from detective_core/mappings/*.json and NDJSON loading with a prefix."""
from __future__ import annotations

import json
import time
from pathlib import Path

from .es import ES, ESError

MAPPINGS_DIR = Path(__file__).parent / "mappings"
CORPUS_INDICES = ["evidence-rookie", "evidence-photolab", "evidence-detective"]
ALL_INDICES = CORPUS_INDICES + ["evidence-mine", "case-events"]


def index_name(prefix: str, base: str) -> str:
    return f"{prefix or ''}{base}"


def load_mapping(base: str) -> dict:
    return json.loads((MAPPINGS_DIR / f"{base}.json").read_text(encoding="utf-8"))


def create_indices(es: ES, prefix: str, names: list[str] | None = None, recreate: bool = False) -> dict[str, str]:
    """Create each index from its mapping file (in parallel). Existing indices are kept unless recreate=True.

    Returns {base_name: "created" | "recreated" | "exists"}.
    """
    from concurrent.futures import ThreadPoolExecutor

    def one(base: str) -> tuple[str, str]:
        idx = index_name(prefix, base)
        body = load_mapping(base)
        existed = es.exists(idx)
        if existed and not recreate:
            return base, "exists"
        if existed:
            es.delete(idx)
        try:
            es.put(idx, body)
        except ESError as exc:
            if exc.status == 400 and "resource_already_exists" in str(exc.body):
                return base, "exists"
            raise
        return base, "recreated" if existed else "created"

    bases = list(names or ALL_INDICES)
    with ThreadPoolExecutor(len(bases)) as ex:
        return dict(ex.map(one, bases))


def delete_indices(es: ES, prefix: str, names: list[str] | None = None) -> list[str]:
    gone = []
    for base in names or ALL_INDICES:
        idx = index_name(prefix, base)
        if es.exists(idx):
            es.delete(idx)
            gone.append(idx)
    return gone


def read_ndjson_pairs(path: str | Path) -> list[tuple[dict, dict]]:
    """Parse a _bulk file into [(action_line, source_doc)]."""
    lines = [ln for ln in Path(path).read_text(encoding="utf-8").splitlines() if ln.strip()]
    if len(lines) % 2:
        raise ValueError(f"{path}: odd number of lines (expected action/source pairs)")
    return [(json.loads(lines[i]), json.loads(lines[i + 1])) for i in range(0, len(lines), 2)]


def load_ndjson(es: ES, path: str | Path, prefix: str, batch_docs: int = 25, max_retries: int = 4,
                workers: int = 4, log=None) -> dict:
    """Bulk a precomputed NDJSON file, rewriting each action's `_index` with the prefix.

    Batches of `batch_docs` run in parallel (semantic_text embeds at index time, so batches are kept small).
    429/503 items are retried with backoff; any other failure raises. Returns {"docs", "batches", "secs"}.
    """
    from concurrent.futures import ThreadPoolExecutor

    t0 = time.time()
    pairs = read_ndjson_pairs(path)
    for action, _ in pairs:
        (op, meta), = action.items()
        meta["_index"] = index_name(prefix, meta["_index"])

    def send(batch: list[tuple[dict, dict]]) -> int:
        todo = batch
        for attempt in range(max_retries + 1):
            payload = "".join(json.dumps(a, ensure_ascii=False) + "\n" + json.dumps(s, ensure_ascii=False) + "\n"
                              for a, s in todo).encode("utf-8")
            resp = es.bulk(payload)
            if not resp.get("errors"):
                return len(batch)
            retry, fatal = [], []
            for pair, item in zip(todo, resp["items"]):
                st = next(iter(item.values()))
                if st.get("error"):
                    (retry if st.get("status") in (429, 503, 504) else fatal).append((pair, st))
            if fatal:
                raise ESError(500, {"bulk_errors": [f[1] for f in fatal[:3]]}, "POST", "_bulk")
            todo = [p for p, _ in retry]
            if attempt == max_retries:
                raise ESError(429, {"bulk_errors": "retries exhausted", "left": len(todo)}, "POST", "_bulk")
            time.sleep(1.5 * 2 ** attempt)
        return len(batch)

    batches = [pairs[i:i + batch_docs] for i in range(0, len(pairs), batch_docs)]
    with ThreadPoolExecutor(max(1, workers)) as ex:
        sent = sum(ex.map(send, batches))
    out = {"docs": sent, "batches": len(batches), "secs": round(time.time() - t0, 2)}
    if log:
        log(f"loaded {sent} docs from {Path(path).name} in {out['secs']}s")
    return out
