"""sha256-keyed JSON disk cache for the corpus build (OCR, omni vectors, LLM extraction): the tuning loop reruns often."""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path


def sha256_hex(*parts: bytes | str) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update(p if isinstance(p, bytes) else p.encode("utf-8"))
        h.update(b"\x00")
    return h.hexdigest()


class DiskCache:
    def __init__(self, root: str | Path, namespace: str):
        self.dir = Path(root) / namespace
        self.dir.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        return self.dir / f"{key}.json"

    def get(self, key: str):
        p = self._path(key)
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except ValueError:
            return None

    def put(self, key: str, value) -> None:
        fd, tmp = tempfile.mkstemp(dir=self.dir, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f, ensure_ascii=False)
        os.replace(tmp, self._path(key))


class CachedLLM:
    """Wraps an LLM so every distinct (model, system, user, extra) call is made once and replayed from disk."""

    def __init__(self, llm, cache: DiskCache):
        self.llm, self.cache = llm, cache
        self.inference_id, self.model_id = llm.inference_id, llm.model_id
        self.hits = self.misses = 0

    def chat(self, system: str, user: str, timeout: float = 30, retries: int = 1, extra: dict | None = None) -> str:
        key = sha256_hex(self.model_id, system, user, json.dumps(extra or {}, sort_keys=True))
        got = self.cache.get(key)
        if got is not None:
            self.hits += 1
            return got["text"]
        self.misses += 1
        text = self.llm.chat(system, user, timeout=timeout, retries=retries, extra=extra)
        self.cache.put(key, {"model": self.model_id, "text": text})
        return text
