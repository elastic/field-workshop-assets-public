"""Chat LLM via the EIS chat_completion `_stream` route, resolved by model_id (never a hard-coded inference id)."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from .es import ES
from .retry import backoff_sleep, is_retryable
from .sse import iter_sse_text


@dataclass
class LLM:
    inference_id: str
    model_id: str
    es: ES = field(repr=False, compare=False, default=None)

    @classmethod
    def resolve(cls, es: ES, preference: list[str] | str | None = None) -> "LLM":
        """Pick the first preference whose `service_settings.model_id` matches a chat_completion endpoint."""
        from .config import DEFAULT_LLM_PREFERENCE, _split_list

        if preference is None:
            preference = DEFAULT_LLM_PREFERENCE
        if isinstance(preference, str):
            preference = _split_list(preference)
        endpoints = es.get("_inference/_all").get("endpoints", [])
        by_model: dict[str, list[str]] = {}
        for e in endpoints:
            if e.get("task_type") != "chat_completion":
                continue
            mid = (e.get("service_settings") or {}).get("model_id")
            if mid:
                by_model.setdefault(mid.lower(), []).append(e["inference_id"])
        for want in preference:
            ids = by_model.get(want.lower())
            if ids:
                # prefer the Elastic-managed (dot-prefixed) endpoint when several share a model id
                ids.sort(key=lambda i: (not i.startswith("."), i))
                return cls(ids[0], want, es)
        raise RuntimeError(f"none of {preference} is available as a chat_completion model_id; "
                           f"have: {sorted(by_model)[:40]}")

    def chat(self, system: str, user: str, timeout: float = 30, retries: int = 1, extra: dict | None = None) -> str:
        """One system+user exchange; collects the stream into a string. Retries 429/5xx/timeouts `retries` times."""
        body = {"messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
        if extra:
            body.update(extra)
        path = f"_inference/chat_completion/{self.inference_id}/_stream"
        attempt = 0
        while True:
            attempt += 1
            try:
                deadline = time.time() + timeout
                resp = self.es.stream_post(path, body, timeout=timeout)
                return "".join(iter_sse_text(resp, deadline)).strip()
            except Exception as exc:  # noqa: BLE001
                if attempt > retries or not is_retryable(exc):
                    raise
                backoff_sleep(attempt, base=0.8)
