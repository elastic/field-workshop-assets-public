"""Text post-processing: OCR markdown -> plain text for BM25/semantic, entity IDs, and LLM receipt fields."""
from __future__ import annotations

import html
import json
import logging
import re
from datetime import date
from html.parser import HTMLParser

from .es import ESError
from .normalize import amount_in_text, parse_amount
from .prompts import RECEIPT_SYSTEM_PROMPT

log = logging.getLogger(__name__)

# ------------------------------------------------------------------------------------------------ ocr_plain
_TABLE_RE = re.compile(r"<table\b.*?</table>", re.I | re.S)
_BR_RE = re.compile(r"<br\s*/?>", re.I)
_TAG_RE = re.compile(r"</?[A-Za-z][^<>]*>|<!--.*?-->", re.S)

class _TableParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._cell: list[str] | None = None

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self._flush_row()
            self._row = []
        elif tag in ("td", "th"):
            self._flush_cell()
            if self._row is None:
                self._row = []
            self._cell = []
        elif tag == "br" and self._cell is not None:
            self._cell.append(" ")

    def handle_endtag(self, tag):
        if tag in ("td", "th"):
            self._flush_cell()
        elif tag == "tr":
            self._flush_row()

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)

    def _flush_cell(self):
        if self._cell is not None and self._row is not None:
            self._row.append(re.sub(r"\s+", " ", "".join(self._cell)).strip())
        self._cell = None

    def _flush_row(self):
        self._flush_cell()
        if self._row is not None and any(c for c in self._row):
            self.rows.append(self._row)
        self._row = None

    def close(self):
        super().close()
        self._flush_row()

def _table_to_pipes(table_html: str) -> str:
    p = _TableParser()
    p.feed(table_html)
    p.close()
    return "\n".join("| " + " | ".join(r) + " |" for r in p.rows)

def ocr_plain(md: str) -> str:
    """OCR markdown -> plain text: HTML <table> becomes `| a | b |` rows, every other tag is stripped."""
    if not md:
        return ""
    s = _TABLE_RE.sub(lambda m: "\n" + _table_to_pipes(m.group(0)) + "\n", md)
    s = _BR_RE.sub("\n", s)
    s = _TAG_RE.sub("", s)
    s = html.unescape(s)
    s = "\n".join(line.rstrip() for line in s.splitlines())
    return re.sub(r"\n{3,}", "\n\n", s).strip()

# ------------------------------------------------------------------------------------------------ entities
_TRAIN_PFX = r"(?:ICE|IC|EC|NJ|RE|RJX|RJ|TGV|THA|EN|IR)"
_TRAIN_RE = re.compile(rf"(?<![A-Za-z0-9-])({_TRAIN_PFX})\s?(\d{{1,5}})(?![A-Za-z0-9])")
_FLIGHT_RE = re.compile(r"(?<![A-Za-z0-9-])([A-Z]{2})\s?(\d{3,4})(?![A-Za-z0-9])")
_PLATE_RES = [
    re.compile(r"(?<![A-Za-z0-9-])[A-Z]{2}-\d{3}-[A-Z]{2}(?![A-Za-z0-9-])"),                 # FR  AB-123-CD
    re.compile(r"(?<![A-Za-z0-9-])\d{1,2}-[A-Z]{2,3}-\d{1,3}(?![A-Za-z0-9-])"),               # NL/BE 12-ABC-3, 1-ABC-234
    re.compile(r"(?<![A-Za-z0-9-])[A-ZÄÖÜ]{1,3}-[A-Z]{1,2}\s\d{1,4}[EH]?(?![A-Za-z0-9-])"),   # DE  K-AB 1234
    re.compile(r"(?<![A-Za-z0-9-])[A-Z]{2}\d{2}\s?[A-Z]{3}(?![A-Za-z0-9-])"),                 # UK  AB12 CDE
]
_ID_RES = [
    re.compile(r"(?<![A-Za-z0-9-])[A-Z]{2,5}(?:-[A-Z0-9]{2,8}){2,4}(?![A-Za-z0-9-])"),        # MRS-55-01923-FR
    re.compile(r"(?<![0-9-])\d{4}-\d{2}-\d{3,6}(?![0-9-])"),                                   # 2026-10-3381 (not a date)
    re.compile(r"(?<![A-Za-z0-9])(?=[A-Z0-9]{10,20}(?![A-Za-z0-9]))(?=[A-Z0-9]*\d)(?=[0-9]*[A-Z])[A-Z0-9]{10,20}"),
]
_LABELED_ID_RE = re.compile(
    r"\b(?:nr|no|n°|nº|nummer|number|rechnung|factuur|facture|invoice|colis|parcel|colli|booking|ref|reference)"
    r"\.?\s*[:#]?\s*([A-Z0-9][A-Z0-9/-]{3,24})", re.I)

def entities(text: str, ignore_case: bool = False) -> list[str]:
    """Exact-match identifiers: train numbers, flights, plates, parcel and invoice ids.

    Each ID is emitted in a spaced and a compact form ("IC 2047", "IC2047") so questions and pages meet either way.
    Pass ignore_case=True for user questions (lowercase "ic 2047").
    """
    if not text:
        return []
    src = text.upper() if ignore_case else text
    out: set[str] = set()
    for m in _TRAIN_RE.finditer(src):
        out.update((f"{m.group(1)} {m.group(2)}", f"{m.group(1)}{m.group(2)}"))
    for m in _FLIGHT_RE.finditer(src):
        pfx, num = m.group(1), m.group(2)
        if len(num) == 4 and num[:2] in ("19", "20"):   # looks like a year ("EU 2026"), not a flight
            continue
        out.update((f"{pfx} {num}", f"{pfx}{num}"))
    for rx in _PLATE_RES + _ID_RES:
        for m in rx.finditer(src):
            v = re.sub(r"\s+", " ", m.group(0)).strip()
            out.add(v)
            out.add(re.sub(r"[^A-Z0-9]", "", v))
    for m in _LABELED_ID_RE.finditer(src):
        v = m.group(1).strip("-/")
        if any(c.isdigit() for c in v):
            out.add(v)
            out.add(re.sub(r"[^A-Z0-9]", "", v))
    return sorted(out)

# ------------------------------------------------------------------------------------------------ receipts
_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.I)

def _parse_json_object(raw: str) -> dict | None:
    s = _FENCE_RE.sub("", (raw or "").strip()).strip()
    for cand in (s, s[s.find("{"): s.rfind("}") + 1] if "{" in s and "}" in s else ""):
        if not cand:
            continue
        try:
            obj = json.loads(cand)
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(obj, dict):
            return obj
    return None

def _clean_str(v, maxlen: int = 120) -> str | None:
    if not isinstance(v, str):
        return None
    v = re.sub(r"\s+", " ", v).strip()
    return v[:maxlen] if v else None

def receipt_fields(text: str, llm, timeout: float = 60, require_in_text: bool = True) -> dict | None:
    """LLM JSON extraction of {"amount_eur","merchant","city","date"} from one page's text.

    Strict: returns None when the model's reply is not a JSON object (or the text is empty). Individual fields that
    fail validation become None. With require_in_text, an amount that is not written anywhere in `text` is dropped
    (the extractor may not invent a number).
    """
    if not text or not text.strip():
        return None
    try:
        raw = llm.chat(RECEIPT_SYSTEM_PROMPT, text[:12000], timeout=timeout, retries=2, extra={"temperature": 0})
    except ESError as exc:
        if exc.status != 400:
            raise
        raw = llm.chat(RECEIPT_SYSTEM_PROMPT, text[:12000], timeout=timeout, retries=2)  # model rejects temperature
    obj = _parse_json_object(raw)
    if obj is None:
        log.warning("receipt_fields: unparseable LLM reply: %r", raw[:200])
        return None
    amount = obj.get("amount_eur")
    amount = None if isinstance(amount, bool) else parse_amount(amount)
    if amount is not None and (amount < 0 or amount > 1e9):
        amount = None
    if amount is not None and require_in_text and not amount_in_text(amount, text):
        log.warning("receipt_fields: amount %s not present in the text; dropped", amount)
        amount = None
    d = _clean_str(obj.get("date"), 10)
    try:
        d = date.fromisoformat(d).isoformat() if d else None
    except ValueError:
        d = None
    return {"amount_eur": amount, "merchant": _clean_str(obj.get("merchant")), "city": _clean_str(obj.get("city")),
            "date": d}
