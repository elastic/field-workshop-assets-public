"""POST /api/ask and POST /api/similar: the three partners answer the same question side by side.

* Rookie     semantic query on rookie_text (top 4) -> LLM
* Photo Lab  omni embedding of the question -> kNN on image_vector (k=3), no LLM
* Detective  rrf(match ocr_text + entities, semantic ocr_semantic) (top 5) -> LLM, with citations

Rookie and Detective use the same LLM, the same PARTNER_SYSTEM_PROMPT and the same excerpt format.
All branches run concurrently; whatever is ready at the deadline is returned, the rest gets a partner-level `error`.
"""
from __future__ import annotations

import logging
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait
from dataclasses import dataclass, field

from detective_core.llm import LLM
from detective_core.prompts import PARTNER_SYSTEM_PROMPT, TRANSLATE_SYSTEM_PROMPT, build_user_prompt
from detective_core.retrieval import Hit

import retrieval
from game import ApiError

log = logging.getLogger("detective.ask")

FIGURE_PATH_RE = re.compile(r"figures/[\w.\-]+\.(?:jpg|jpeg|png)")
LLM_TIMEOUT = 14.0
MAX_QUESTION_CHARS = 500
POOL = ThreadPoolExecutor(max_workers=24, thread_name_prefix="ask")


class MockLLM:
    """MOCK_LLM=1: deterministic canned answers (tests and the frontend lane). Cites the first excerpt it was given
    (header `[EX-07 p1]` or `[EX-07 p1 \u00b7 title]`)."""
    inference_id = "mock"
    model_id = "mock-llm"
    is_mock = True

    def chat(self, system: str, user: str, timeout: float = 30, retries: int = 1, extra=None) -> str:
        if system == TRANSLATE_SYSTEM_PROMPT:       # "Translate to English" in MOCK mode: clearly marked, not a translation
            return f"(mock translation, not a real one)\n\n{user}"
        m = re.search(r"\[([A-Za-z]{1,6}-\d{1,4}) p(\d+)[^\]]*\]", user)
        if not m:
            return "The excerpts do not contain the answer."
        return f"(mock answer) The first excerpt is the closest match [{m.group(1)} p{m.group(2)}]."


class LLMHolder:
    def __init__(self, es, preference: list[str], mock: bool = False):
        self.es, self.preference, self.mock = es, preference, mock
        self._llm = MockLLM() if mock else None
        self._lock = threading.Lock()

    @property
    def model_id(self) -> str | None:
        return self._llm.model_id if self._llm else None

    def get(self):
        if self._llm is not None:
            return self._llm
        with self._lock:
            if self._llm is None:
                self._llm = LLM.resolve(self.es, self.preference)
                log.info("LLM resolved: %s (%s)", self._llm.model_id, self._llm.inference_id)
            return self._llm


@dataclass
class Partial:
    hits: list[Hit] = field(default_factory=list)
    answer: str | None = None
    error: str | None = None
    model: str | None = None
    ms: int = 0
    done: bool = False
    started: float = field(default_factory=time.monotonic)


def _err(exc: BaseException) -> str:
    s = str(exc).lower()
    if "timed out" in s or "timeout" in s or isinstance(exc, TimeoutError):
        return "Timed out waiting for the model."
    return "Could not reach the model right now."


class AskService:
    def __init__(self, cfg, es, engine, llm: LLMHolder):
        self.cfg, self.es, self.engine, self.llm = cfg, es, engine, llm

    # ------------------------------------------------------------------ branches
    def _canned_hits(self, rounds: list[int] | None, k: int) -> list[Hit]:
        """Only used when there is no Elasticsearch (MOCK mode for the frontend lane)."""
        g = self.engine.game
        ids = [d for d, m in g.docs.items() if rounds is None or m.get("round", 0) in rounds][:k]
        return [Hit(d, g.docs[d].get("exhibit", d), 1, 0.5, text=f"(mock excerpt) {g.docs[d].get('title', d)}")
                for d in ids]

    def _answer(self, question: str, hits: list[Hit]) -> str:
        llm = self.llm.get()
        user = build_user_prompt(question, retrieval.excerpts(hits))
        return llm.chat(PARTNER_SYSTEM_PROMPT, user, timeout=LLM_TIMEOUT, retries=1)

    def _run_partner(self, p: Partial, search, question: str) -> None:
        try:
            p.hits = search()
            p.model = self.llm.model_id
            p.answer = self._answer(question, p.hits)
            p.model = self.llm.model_id
        except Exception as exc:  # noqa: BLE001
            log.warning("partner branch failed: %s", exc)
            p.error = _err(exc)
        finally:
            p.ms = int((time.monotonic() - p.started) * 1000)
            p.done = True

    def _run_photolab(self, p: Partial, question: str, rounds: list[int] | None) -> None:
        try:
            if self.es is None:
                p.hits = self._canned_hits(rounds, 3)
            else:
                p.hits = retrieval.search_photolab(self.es, self.cfg.prefix, question, rounds)
        except Exception as exc:  # noqa: BLE001
            log.warning("photolab branch failed: %s", exc)
            p.error = "Photo Lab could not search right now."
        finally:
            p.ms = int((time.monotonic() - p.started) * 1000)
            p.done = True

    # ------------------------------------------------------------------ public
    def ask(self, question: str, scope: str = "case") -> dict:
        question = (question or "").strip()
        if not question:
            raise ApiError(400, "empty_question", "Ask something.")
        if len(question) > MAX_QUESTION_CHARS:
            raise ApiError(400, "question_too_long", "Keep the question under 500 characters.")
        if scope not in ("case", "mine"):
            raise ApiError(400, "bad_scope", "scope must be 'case' or 'mine'.")
        t0 = time.monotonic()
        rounds = self.engine.unlocked_round_numbers() if scope == "case" else None
        rookie, photo, det = Partial(), Partial(), Partial()

        def det_search():
            if self.es is None:
                return self._canned_hits(rounds, 5)
            return retrieval.search_detective(self.es, self.cfg.prefix, question, rounds, scope)

        def rookie_search():
            if self.es is None:
                return self._canned_hits(rounds, 4)
            return retrieval.search_rookie(self.es, self.cfg.prefix, question, rounds)

        futs = [POOL.submit(self._run_partner, det, det_search, question)]
        if scope == "case":
            futs += [POOL.submit(self._run_partner, rookie, rookie_search, question),
                     POOL.submit(self._run_photolab, photo, question, rounds)]
        done, pending = wait(futs, timeout=self.cfg.ask_deadline)
        now = int((time.monotonic() - t0) * 1000)
        timed_out = "Timed out waiting for the model."

        def finish(p: Partial) -> int:
            if not p.done:
                p.error = p.error or timed_out
                p.ms = now
            return p.ms

        out: dict = {"question": question, "scope": scope}
        # Detective
        finish(det)
        cited = retrieval.cited_hits(det.answer or "", det.hits)
        shown = [(h, True) for h in cited] or [(h, False) for h in det.hits[:3]]
        out["detective"] = {
            "answer": det.answer or "",
            "citations": [{"doc_id": h.doc_id, "exhibit": h.exhibit, "page": h.page,
                           "snippet_html": retrieval.safe_snippet_html(h), "cited": c} for h, c in shown],
            "model": det.model or self.llm.model_id, "ms": det.ms,
        }
        if det.error:
            out["detective"]["error"] = det.error
        # Rookie
        if scope == "case":
            finish(rookie)
            out["rookie"] = {
                "answer": rookie.answer or "",
                "sources": [{"doc_id": h.doc_id, "exhibit": h.exhibit, "page": h.page,
                             "snippet": retrieval.plain_snippet(h.text, 300)} for h in rookie.hits],
                "model": rookie.model or self.llm.model_id, "ms": rookie.ms,
            }
            if rookie.error:
                out["rookie"]["error"] = rookie.error
            finish(photo)
            out["photolab"] = {"results": [self._photo_result(h) for h in photo.hits], "ms": photo.ms}
            if photo.error:
                out["photolab"]["error"] = photo.error
        else:  # My evidence: only the Detective has an index of the player's pages
            out["rookie"] = {"answer": "", "sources": [], "model": None, "ms": 0, "unavailable": True}
            out["photolab"] = {"results": [], "ms": 0, "unavailable": True}
        POOL.submit(self._record, scope)
        return out

    def _record(self, scope: str) -> None:
        try:
            self.engine.record_ask(scope)
        except Exception as exc:  # noqa: BLE001
            log.warning("could not record ask event: %s", exc)

    @staticmethod
    def _photo_result(h: Hit) -> dict:
        """One Photo Lab hit. A page hit points at /thumbs/<doc>-p<n>.jpg. A *figure* hit (an image found inside a PDF page,
        e.g. a dossier portrait; `kind: "figure"` in the index) points at its own file under /figures/ and carries
        `figure_n`, so the desk can say "figure in EX-02 p1"."""
        src = h.source or {}
        kind = h.kind or src.get("kind") or "page"
        out = {"doc_id": h.doc_id, "exhibit": h.exhibit, "page": h.page, "kind": "page",
               "thumb_url": f"/thumbs/{h.doc_id}-p{h.page}.jpg", "score": round(h.score, 3)}
        if kind == "figure":
            path = str(h.image_path or src.get("image_path") or "")
            if FIGURE_PATH_RE.fullmatch(path):               # only ever a plain file name under figures/
                out.update(kind="figure", figure_n=int(h.figure_n or src.get("figure_n") or 1), thumb_url="/" + path)
        return out

    def similar(self, doc_id: str, page: int) -> dict:
        st = self.engine.state()
        if doc_id not in self.engine.visible_doc_ids(st):
            raise ApiError(404, "no_such_doc", "That page is not in your locker.")
        rounds = self.engine.unlocked_round_numbers(st)
        if self.es is None:
            return {"results": [self._photo_result(h) for h in self._canned_hits(rounds, 4)
                                if h.doc_id != doc_id][:3]}
        vec = retrieval.page_vector(self.es, self.cfg.prefix, doc_id, page)
        if not vec:
            raise ApiError(404, "no_vector", "Photo Lab has no image for that page.")
        hits = retrieval.knn_photolab(self.es, self.cfg.prefix, vec, rounds, exclude=(doc_id, page))
        return {"results": [self._photo_result(h) for h in hits]}
