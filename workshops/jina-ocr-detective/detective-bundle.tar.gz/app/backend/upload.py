"""Bring your worst PDF: upload -> rasterize -> orient -> OCR (2 at a time) -> index into evidence-mine, page by page.

* pdf/jpg/png, <= 10 pages, <= 20 MB. A page over MAX_PAGE_PIXELS_AT_200DPI (an image over MAX_IMAGE_PIXELS) is refused as `page_too_big`.
* PDFs are rasterized at 200 dpi (detective_core.render); images get EXIF transpose; every page goes through orient().
* At most 2 concurrent OCR calls per job; 60 s timeout, 1 retry (the page shows a "retrying" note in between).
* Each page is indexed into evidence-mine as soon as it is read; the measured seconds are real wall-clock seconds.
* `rookie_raw` is what pymupdf get_text() returned for that page (exactly, may be empty).
* Job state is mirrored to a small JSON file per job so the locker survives an app restart.
"""
from __future__ import annotations

import io
import json
import logging
import re
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import pymupdf
from PIL import Image, ImageOps

from detective_core.extract import entities, ocr_plain
from detective_core.index import index_name
from detective_core.ocr import OcrError, image_to_bytes, ocr_image, orient
from detective_core.render import rasterize_pdf, rookie_text
from detective_core.retry import is_retryable

from game import ApiError

log = logging.getLogger("detective.upload")

MAX_PAGES = 10
MAX_BYTES = 20 * 1024 * 1024
OCR_CONCURRENCY = 2
OCR_TIMEOUT = 60.0
MAX_ACTIVE_JOBS = 3
MAX_IMAGE_PIXELS = 60_000_000
MAX_PAGE_PIXELS_AT_200DPI = 60_000_000      # ~1,500 sq in: about 16 letter pages of area, so a long scrolling capture trips it
# The player-facing text for code `page_too_big`. A one-page "scrolling capture" (a screen recording stitched into one tall
# page) is the usual cause, and every page is shrunk to fit 2400 px before OCR anyway, so small text on it would be lost.
PDF_PAGE_TOO_BIG = ("That page is too big to read as one image (a long scrolling capture?). "
                    f"Split it into normal-size pages, up to {MAX_PAGES}.")
IMAGE_TOO_BIG = "That image is too big to read as one page (a long scrolling capture?). Crop or split it first."
MINE_ROUND = 99
_OCR_GATE = threading.BoundedSemaphore(6)       # across all jobs in this sandbox


def sniff(data: bytes) -> str | None:
    if data[:5] == b"%PDF-":
        return "pdf"
    if data[:3] == b"\xff\xd8\xff":
        return "jpg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    return None


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


@dataclass
class PageState:
    n: int
    status: str = "queued"                 # queued | reading | done | error
    ocr_secs: float | None = None
    ocr_md: str = ""
    rookie_raw: str = ""
    ocr_model: str | None = None
    ocr_at: str | None = None
    error: str | None = None
    note: str | None = None
    image_url: str = ""
    thumb_url: str = ""
    ready: bool = True            # the page JPEG is on disk; new pages start False so the API never points at a 404


@dataclass
class Job:
    job_id: str
    doc_id: str
    exhibit: str
    filename: str
    kind: str
    pdf_kind: str
    has_text_layer: bool
    pages: list[PageState]
    created: str = field(default_factory=_now_iso)
    admin: bool = False
    error: str | None = None
    lock: threading.Lock = field(default_factory=threading.Lock, repr=False, compare=False)

    @property
    def status(self) -> str:
        if self.error and not any(p.status == "done" for p in self.pages):
            return "error"
        if any(p.status in ("queued", "reading") for p in self.pages):
            return "running"
        return "done" if any(p.status == "done" for p in self.pages) else "error"

    def page_dict(self, p: PageState) -> dict:
        d = {"n": p.n, "status": p.status, "ocr_secs": p.ocr_secs, "image_url": p.image_url if p.ready else "",
             "ocr_md": p.ocr_md, "rookie_raw": p.rookie_raw}
        if p.thumb_url and p.ready:
            d["thumb_url"] = p.thumb_url
        if p.error:
            d["error"] = p.error
        if p.note:
            d["note"] = p.note
        return d

    def to_dict(self) -> dict:
        with self.lock:
            out = {"job_id": self.job_id, "status": self.status, "doc_id": self.doc_id, "exhibit": self.exhibit,
                   "filename": self.filename, "pdf_kind": self.pdf_kind, "has_text_layer": self.has_text_layer,
                   "pages": [self.page_dict(p) for p in self.pages]}
            if self.error:
                out["error"] = self.error
            return out

    def doc_summary(self) -> dict:
        p1 = next((p for p in self.pages if p.ready), self.pages[0])        # never a thumbnail that is not on disk yet
        return {"doc_id": self.doc_id, "exhibit": self.exhibit, "title": self.filename, "doc_type": "upload",
                "round": MINE_ROUND, "lang": "", "pages": len(self.pages), "thumb_url": p1.thumb_url or p1.image_url,
                "pdf_kind": self.pdf_kind}


def _safe_name(name: str) -> str:
    name = Path((name or "upload").replace("\\", "/")).name
    name = re.sub(r"[^\w .,()\[\]+\-]", "_", name)[:80].strip() or "upload"
    return name


class UploadManager:
    def __init__(self, cfg, es, engine):
        self.cfg, self.es, self.engine = cfg, es, engine
        self.dir = Path(cfg.upload_dir)
        self.jobs: dict[str, Job] = {}
        self._lock = threading.Lock()
        self.dir.mkdir(parents=True, exist_ok=True)
        self._load_disk()

    # ------------------------------------------------------------------ persistence
    def _meta_path(self, job_id: str) -> Path:
        return self.dir / f"{job_id}.json"

    def _save(self, job: Job) -> None:
        try:
            with job.lock:
                d = {"job_id": job.job_id, "doc_id": job.doc_id, "exhibit": job.exhibit, "filename": job.filename,
                     "kind": job.kind, "pdf_kind": job.pdf_kind, "has_text_layer": job.has_text_layer,
                     "created": job.created, "admin": job.admin, "error": job.error,
                     "pages": [asdict(pg) for pg in job.pages]}
            tmp = self._meta_path(job.job_id).with_suffix(".tmp")
            tmp.write_text(json.dumps(d), encoding="utf-8")
            tmp.replace(self._meta_path(job.job_id))
        except Exception as exc:  # noqa: BLE001
            log.warning("could not save upload meta: %s", exc)

    def _load_disk(self) -> None:
        for p in sorted(self.dir.glob("*.json")):
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                pages = [PageState(**pg) for pg in d.pop("pages")]
                job = Job(pages=pages, **d)
                for pg in job.pages:
                    if pg.status in ("queued", "reading"):
                        pg.status, pg.error = "error", "Interrupted by a restart."
                self.jobs[job.job_id] = job
            except Exception as exc:  # noqa: BLE001
                log.warning("skipping unreadable upload meta %s: %s", p.name, exc)

    # ------------------------------------------------------------------ public API
    def get(self, job_id: str) -> Job:
        job = self.jobs.get(job_id)
        if not job:
            raise ApiError(404, "no_such_job", "Unknown upload.")
        return job

    def list_docs(self) -> list[dict]:
        docs = [j.doc_summary() for j in sorted(self.jobs.values(), key=lambda j: j.created)
                if any(p.status == "done" for p in j.pages)]
        return docs

    def page(self, doc_id: str, n: int) -> tuple[Job, PageState] | None:
        for j in self.jobs.values():
            if j.doc_id == doc_id:
                for p in j.pages:
                    if p.n == n and p.status == "done":
                        return j, p
        return None

    def submit(self, filename: str, data: bytes, admin: bool = False) -> Job:
        if len(data) > MAX_BYTES:
            raise ApiError(413, "too_large", "That file is over 20 MB.")
        if not data:
            raise ApiError(422, "empty_file", "That file is empty.")
        kind = sniff(data)
        if not kind:
            raise ApiError(422, "unsupported_type", "Upload a PDF, JPG or PNG.")
        with self._lock:
            if sum(1 for j in self.jobs.values() if j.status == "running") >= MAX_ACTIVE_JOBS:
                raise ApiError(429, "busy", "Still reading your other uploads. Give it a moment.")
        raw_pages: list[str] = []
        if kind == "pdf":
            try:
                with pymupdf.open(stream=data, filetype="pdf") as doc:
                    if doc.needs_pass or doc.is_encrypted:
                        raise ApiError(422, "encrypted", "That PDF is password protected.")
                    n_pages = doc.page_count
                    if n_pages < 1:
                        raise ApiError(422, "empty_file", "That PDF has no pages.")
                    if n_pages > MAX_PAGES:
                        raise ApiError(422, "too_many_pages", f"Up to {MAX_PAGES} pages, please.", max_pages=MAX_PAGES)
                    for pg in doc:
                        px = pg.rect.width * pg.rect.height * (200 / 72) ** 2
                        if px > MAX_PAGE_PIXELS_AT_200DPI:
                            raise ApiError(422, "page_too_big", PDF_PAGE_TOO_BIG)
                raw_pages = rookie_text(data)
            except ApiError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.info("unreadable pdf: %s", exc)
                raise ApiError(422, "unreadable", "Could not open that PDF.") from exc
        else:
            try:
                im = Image.open(io.BytesIO(data))
                if im.width * im.height > MAX_IMAGE_PIXELS:
                    raise ApiError(422, "page_too_big", IMAGE_TOO_BIG)
                im.verify()
            except ApiError:
                raise
            except Exception as exc:  # noqa: BLE001
                raise ApiError(422, "unreadable", "Could not open that image.") from exc
            n_pages, raw_pages = 1, [""]
        has_text = any(t.strip() for t in raw_pages)
        job_id = uuid.uuid4().hex[:10]
        with self._lock:
            idx = len(self.jobs) + 1
            doc_id = f"mine-{job_id}"
            pages = [PageState(n=i + 1, rookie_raw=raw_pages[i] if i < len(raw_pages) else "",
                               image_url=f"/uploads/{doc_id}-p{i + 1}.jpg", thumb_url=f"/uploads/{doc_id}-t{i + 1}.jpg",
                               ready=False)
                     for i in range(n_pages)]
            job = Job(job_id=job_id, doc_id=doc_id, exhibit=f"UP-{idx:02d}", filename=_safe_name(filename), kind=kind,
                      pdf_kind="born_digital" if has_text else "image_only", has_text_layer=has_text, pages=pages,
                      admin=admin)
            self.jobs[job_id] = job
        self._save(job)
        threading.Thread(target=self._run, args=(job, data), name=f"upload-{job_id}", daemon=True).start()
        return job

    def sample_path(self) -> Path:
        return Path(self.cfg.corpus_dir) / "sample-worst.pdf"

    def submit_sample(self, admin: bool = True) -> Job:
        """The shipped 'worst PDF'. admin=True (Instruqt solve): ingested for the check, no points. admin=False: the
        player picked "Try our worst PDF" in the desk, so it scores like their own upload."""
        p = self.sample_path()
        if not p.is_file():
            raise ApiError(404, "no_sample", "The sample PDF is not in the corpus.")
        return self.submit("sample-worst.pdf", p.read_bytes(), admin=admin)

    def wait(self, job: Job, timeout: float) -> bool:
        end = time.time() + timeout
        while time.time() < end:
            if job.status != "running":
                return True
            time.sleep(0.25)
        return job.status != "running"

    # ------------------------------------------------------------------ pipeline
    def _run(self, job: Job, data: bytes) -> None:
        try:
            if job.kind == "pdf":
                images = rasterize_pdf(data, dpi=200)
            else:
                images = [Image.open(io.BytesIO(data))]
        except Exception as exc:  # noqa: BLE001
            log.warning("job %s: rasterize failed: %s", job.job_id, exc)
            with job.lock:
                job.error = "Could not read that file."
                for p in job.pages:
                    p.status, p.error = "error", "Could not read that file."
            self._save(job)
            return
        with ThreadPoolExecutor(OCR_CONCURRENCY, thread_name_prefix=f"ocr-{job.job_id}") as ex:
            futs = [ex.submit(self._page, job, p, images[p.n - 1]) for p in job.pages if p.n <= len(images)]
            for f in futs:
                try:
                    f.result()
                except Exception as exc:  # noqa: BLE001
                    log.warning("job %s page crashed: %s", job.job_id, exc)

    def _set(self, job: Job, p: PageState, **kw) -> None:
        with job.lock:
            for k, v in kw.items():
                setattr(p, k, v)
        self._save(job)

    def _page(self, job: Job, p: PageState, img: Image.Image) -> None:
        self._set(job, p, status="reading")
        try:
            try:
                img = orient(img)
            except Exception as exc:  # noqa: BLE001
                log.info("orient skipped: %s", exc)
                img = ImageOps.exif_transpose(img)
            img = img.convert("RGB")
            img.thumbnail((2400, 2400))
            jpeg, mime = image_to_bytes(img, "JPEG", 85)
            (self.dir / f"{job.doc_id}-p{p.n}.jpg").write_bytes(jpeg)
            th = img.copy()
            th.thumbnail((320, 320 * 4))
            th.save(self.dir / f"{job.doc_id}-t{p.n}.jpg", "JPEG", quality=80)
            self._set(job, p, ready=True)

            t0 = time.time()
            res_text, res_model = self._ocr(job, p, jpeg, mime)
            secs = round(time.time() - t0, 2)

            plain = ocr_plain(res_text)
            ocr_at = _now_iso()
            self._index_page(job, p, res_text, plain, res_model, secs, ocr_at)
            self._set(job, p, status="done", ocr_secs=secs, ocr_md=res_text, ocr_model=res_model, ocr_at=ocr_at,
                      note=None)
            if not job.admin:
                try:
                    self.engine.record_upload_page(job.job_id, secs, award=True, ok=True)
                except Exception as exc:  # noqa: BLE001
                    log.warning("could not record upload event: %s", exc)
        except Exception as exc:  # noqa: BLE001
            log.warning("job %s page %d failed: %s", job.job_id, p.n, exc)
            self._set(job, p, status="error", error="The Detective could not read this page.", note=None)

    def _ocr(self, job: Job, p: PageState, jpeg: bytes, mime: str) -> tuple[str, str]:
        if self.es is None:       # frontend-lane mock mode: no Elasticsearch, no OCR
            time.sleep(0.2)
            return f"(mock OCR) page {p.n} of {job.filename}", "jina-ocr-v1"
        with _OCR_GATE:
            try:
                r = ocr_image(jpeg, mime, es=self.es, timeout=OCR_TIMEOUT, retries=0)
            except OcrError as exc:
                if exc.__cause__ is not None and not is_retryable(exc.__cause__):
                    raise
                self._set(job, p, note="The Detective needs a coffee. Retrying.")
                r = ocr_image(jpeg, mime, es=self.es, timeout=OCR_TIMEOUT, retries=0)
        return r.text, r.model

    def _index_page(self, job: Job, p: PageState, md: str, plain: str, model: str, secs: float, ocr_at: str) -> None:
        if self.es is None:
            return
        doc = {"doc_id": job.doc_id, "exhibit": job.exhibit, "page": p.n, "round": MINE_ROUND, "doc_type": "upload",
               "title": f"{job.filename} p{p.n}", "lang": "", "ocr_md": md, "ocr_text": plain,
               "entities": entities(plain), "ocr_model": model, "ocr_secs": secs, "ocr_at": ocr_at,
               "image_path": p.image_url, "rookie_raw": p.rookie_raw}
        if plain.strip():                       # semantic_text rejects empty content
            doc["ocr_semantic"] = plain
        self.es.put(f"{index_name(self.cfg.prefix, 'evidence-mine')}/_doc/{job.doc_id}-p{p.n}", json=doc,
                    params={"refresh": "true"}, timeout=60, retries=1)
