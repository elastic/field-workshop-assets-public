"""Game rules. Everything comes from the compiled game.json (CONTRACT 3a); nothing event-specific lives here.

* GameData wraps game.json: answer hashing (detective_core.normalize), scoring, round/doc lookups.
* derive(events, game) rebuilds the player's State from the case-events list (pure, unit-tested).
* Engine applies actions: it reads the derived state, decides, and appends events (under one lock).
"""
from __future__ import annotations

import json
import logging
import random
import re
import threading
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

from detective_core.normalize import amount_str, answer_hash, dossier_key, evidence_key

from events import EventStore, StoreUnavailable, iso, parse_ts, utcnow

log = logging.getLogger("detective.game")

STEPS = ("round1", "round2", "round3", "warrant", "upload", "ledger")
# Gating (GATE_BY_CHALLENGE=1): each part of the game opens with its Instruqt challenge. The stage is the challenge the player
# has reached; its 1-based index IS the challenge number. round1..round3 open Rounds 1..3, warrant opens the warrant,
# upload opens "Bring your worst PDF", bonus opens the Ledger. Raised by POST /api/admin/stage, never lowered.
STAGES = ("round1", "round2", "round3", "warrant", "upload", "bonus")
STAGE_IDX = {name: i + 1 for i, name in enumerate(STAGES)}
TRAIT_KEYS = ("languages", "hobby", "tell")        # the three warrant traits, in the order the UI shows them

# Plan 2.4 defaults. game.json.scoring may override any key (several aliases are accepted, see _SCORING_ALIASES).
DEFAULT_SCORING = {
    "round_correct": 1000,
    "time_bonus_max": 600,            # bonus = max(0, time_bonus_max - seconds_in_round)
    "wrong_city_penalty": 150,
    "hint_costs": [50, 150, 300],
    "ledger_correct": 500,
    "ledger_correct_with_hint": 250,   # plan 2.7: +500, or +250 if a Ledger hint was used
    "ledger_cooldown_secs": 60,
    "warrant_correct": 2000,
    "warrant_wrong_penalty": 500,
    "warrant_max_attempts": 3,
    "upload_first_page": 250,
}
_SCORING_ALIASES = {
    "round_correct": ("round_correct", "correct_city", "city_correct"),
    "time_bonus_max": ("time_bonus_max", "time_bonus", "time_bonus_cap"),
    "wrong_city_penalty": ("wrong_city_penalty", "wrong_city", "wrong_filing", "wrong_filing_penalty"),
    "hint_costs": ("hint_costs", "hints"),
    "ledger_correct": ("ledger_correct", "ledger"),
    "ledger_correct_with_hint": ("ledger_correct_with_hint", "ledger_hint", "ledger_with_hint"),
    "ledger_cooldown_secs": ("ledger_cooldown_secs", "ledger_retry_seconds", "ledger_cooldown", "ledger_attempt_secs"),
    "warrant_correct": ("warrant_correct", "warrant"),
    "warrant_wrong_penalty": ("warrant_wrong_penalty", "warrant_wrong"),
    "warrant_max_attempts": ("warrant_max_attempts", "warrant_attempts", "warrant_max"),
    "upload_first_page": ("upload_first_page", "worst_pdf_first_page", "worst_pdf", "upload"),
}


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str = "", **extra):
        self.status, self.code, self.message, self.extra = status, code, message or code, extra
        super().__init__(f"{status} {code}: {message}")


# ====================================================================================================== game.json
class GameData:
    def __init__(self, data: dict):
        self.raw = data
        self.salt: str = data.get("salt", "")
        self.rounds: list[dict] = sorted(data.get("rounds", []), key=lambda r: r["round"])
        self.n_rounds = len(self.rounds)
        self.docs: dict[str, dict] = data.get("docs", {})
        self.always_visible: list[str] = list(data.get("always_visible_doc_ids", []))
        self.suspects: list[dict] = data.get("suspects", [])
        self.warrant: dict = data.get("warrant", {})
        self.ledger: dict = data.get("ledger", {})
        self.handles: dict = data.get("handles", {})
        self.scoring = self._scoring(data.get("scoring") or {})
        self.built_at = data.get("built_at")
        # Warrant proof (option B). Public bundle: only salted hashes ("trait|value|doc_id", and per-suspect dossier traits).
        self._evidence_hashes: set[str] = set(self.warrant.get("evidence_hashes") or [])
        self._dossier_hashes: dict[str, set[str]] = {sid: set(hs) for sid, hs in (self.warrant.get("dossier_hashes") or {}).items()}

    def _scoring(self, raw: dict) -> dict:
        out = dict(DEFAULT_SCORING)
        for key, aliases in _SCORING_ALIASES.items():
            for a in aliases:
                if a in raw and raw[a] is not None:
                    v = raw[a]
                    try:
                        if key == "hint_costs":
                            if isinstance(v, dict):
                                v = [v[k] for k in sorted(v)]
                            out[key] = [abs(int(x)) for x in v]
                        else:
                            out[key] = abs(int(v))
                    except (TypeError, ValueError):
                        continue
                    break
        return out

    # -------------------------------------------------------------- hashing
    def h(self, x) -> str:
        return answer_hash(self.salt, x)

    def round(self, n: int) -> dict:
        for r in self.rounds:
            if r["round"] == n:
                return r
        raise ApiError(404, "no_such_round", f"There is no round {n}.")

    def check_city(self, n: int, city: str) -> str:
        """'correct' | 'decoy' (the Rookie's wrong city) | 'wrong'."""
        r = self.round(n)
        hh = self.h(city)
        if hh in r.get("answer_hashes", []):
            return "correct"
        decoys = set(r.get("rookie_decoy_hashes") or [])
        if r.get("rookie_decoy_hash"):
            decoys.add(r["rookie_decoy_hash"])
        return "decoy" if hh in decoys else "wrong"

    def thief(self) -> dict | None:
        th = self.warrant.get("thief_hash")
        for s in self.suspects:
            if th and th in (self.h(s["id"]), self.h(s.get("name", ""))):
                return s
        return None

    def is_thief(self, suspect_id: str) -> bool:
        th = self.warrant.get("thief_hash")
        if not th:
            return False
        for s in self.suspects:
            if s["id"] == suspect_id:
                return th in (self.h(s["id"]), self.h(s.get("name", "")))
        return False

    def evidence_accepted(self, trait: str, value: str, doc_id: str) -> bool:
        """Is `value` the thief's true `trait` AND does exhibit `doc_id` prove it? (Only true pairs have a hash, so one lookup
        answers both; a wrong value and a wrong exhibit are indistinguishable by design.)"""
        return self.h(evidence_key(trait, value, doc_id)) in self._evidence_hashes

    def dossier_values(self, suspect_id: str, trait: str) -> list[str]:
        """The vocabulary values a suspect's own dossier gives for `trait` (public information, recovered from hashes)."""
        have = self._dossier_hashes.get(suspect_id)
        if not have:
            return []
        vocab = (self.warrant.get("trait_vocab") or {}).get(trait, [])
        out: list[str] = []
        for rank in range(len(vocab)):                                # ranks run 0..n-1 in the dossier's own order
            hit = next((v for v in vocab if self.h(dossier_key(suspect_id, trait, v, rank)) in have), None)
            if hit is None:
                break
            out.append(hit)
        return out

    def check_total(self, total: float) -> bool:
        return self.h(amount_str(total)) == self.ledger.get("total_hash")

    def ledger_unlock_round(self) -> int:
        return int(self.ledger.get("unlock_round") or self.n_rounds)

    def warrant_unlock_round(self) -> int:
        return int(self.warrant.get("unlock_round") or self.n_rounds)

    def doc_ids_for_rounds(self, unlocked: set[int]) -> list[str]:
        ids = list(self.always_visible)
        for r in self.rounds:
            if r["round"] in unlocked:
                ids += [d for d in r.get("unlock_doc_ids", []) if d not in ids]
        return ids

    def case_number(self) -> str:
        """'AMS-1013' (museum city + theft month/day) unless the case file names one (case.case_number)."""
        c = self.raw.get("case") or {}
        explicit = c.get("case_number") or (c.get("theft") or {}).get("case_number")
        if explicit:
            return str(explicit).upper()
        city = re.sub(r"[^A-Za-z]", "", unicodedata.normalize("NFD", str((c.get("museum") or {}).get("city") or "CASE")))
        m = re.match(r"(\d{4})-(\d{2})-(\d{2})", str((c.get("theft") or {}).get("date") or ""))
        return f"{city[:3].upper()}-{m.group(2)}{m.group(3)}" if m else city[:3].upper()

    def make_handle(self, rng: random.Random | None = None) -> str:
        rng = rng or random.Random()
        adj = self.handles.get("adjectives") or ["Inspector"]
        noun = self.handles.get("nouns") or ["Magnifier"]
        return f"{rng.choice(adj)} {rng.choice(noun)} {rng.randint(10, 99)}"


class GameFile:
    """Lazy, hot-reloading loader for ${CORPUS_DIR}/game.json (the app may start before the corpus is in place)."""

    def __init__(self, path: Path, data: dict | None = None):
        self.path = Path(path)
        self._data: GameData | None = GameData(data) if data is not None else None
        self._mtime = None
        self._lock = threading.Lock()

    def get(self) -> GameData:
        if self._data is not None and self._mtime is None:     # injected (tests)
            return self._data
        with self._lock:
            try:
                m = self.path.stat().st_mtime
            except FileNotFoundError:
                if self._data is not None:
                    return self._data
                raise ApiError(503, "corpus_not_loaded", "The case file is still being assembled.")
            if self._data is None or m != self._mtime:
                self._data = GameData(json.loads(self.path.read_text(encoding="utf-8")))
                self._mtime = m
                log.info("game.json loaded: %d rounds, %d docs", self._data.n_rounds, len(self._data.docs))
            return self._data

    def loaded(self) -> bool:
        try:
            self.get()
            return True
        except ApiError:
            return False


# ====================================================================================================== state
@dataclass
class State:
    handle: str | None = None
    started_at: datetime | None = None
    score: int = 0
    solved: dict[int, dict] = field(default_factory=dict)         # round -> {"ts", "skipped"}
    round_start: dict[int, datetime] = field(default_factory=dict)
    hints_used: dict[int, int] = field(default_factory=dict)
    filings: dict[int, int] = field(default_factory=dict)
    warrant_attempts: int = 0
    warrant_correct: bool = False
    warrant_skipped: bool = False
    ledger_correct: bool = False
    ledger_skipped: bool = False
    ledger_hints_used: int = 0
    warrant_hints_used: int = 0
    ledger_last_attempt: datetime | None = None
    upload_pages: int = 0
    upload_skipped: bool = False
    upload_awarded: bool = False
    gate: bool = False                                            # GATE_BY_CHALLENGE: the stage can keep things closed
    stage_idx: int = 1                                            # the highest stage event so far (1 = round1, the baseline)
    stage_ts: dict[int, datetime] = field(default_factory=dict)   # stage index -> when it first opened

    @property
    def started(self) -> bool:
        return self.started_at is not None

    @property
    def stage(self) -> str:
        return STAGES[self.stage_idx - 1]

    def stage_reached(self, name: str) -> bool:
        """True when gating is off, or the stage has reached `name`."""
        return not self.gate or self.stage_idx >= STAGE_IDX[name]

    def unlocked_rounds(self) -> set[int]:
        if not self.started:
            return set()
        out = {1}
        for n in self.solved:
            # Round n+1 opens when round n is filed AND (when gated) the stage has reached it. The stage index equals the round
            # number up to the last round; one past it is the warrant, which keeps the old "last stop" bookkeeping intact.
            if not self.gate or self.stage_idx >= n + 1:
                out.add(n + 1)
        return out


def derive(events: list[dict], game: GameData, gate: bool = False) -> State:
    st = State(gate=gate)
    for e in events:
        a = e.get("action")
        ts = parse_ts(e["ts"]) if e.get("ts") else None
        st.score += int(e.get("points") or 0)
        rnd = int(e.get("round") or 0)
        if a == "handle":
            st.handle = e.get("value") or st.handle
        elif a == "start":
            if st.started_at is None:
                st.started_at = ts
                st.round_start[1] = ts
        elif a == "file":
            st.filings[rnd] = st.filings.get(rnd, 0) + 1
            if e.get("correct") and rnd not in st.solved:
                st.solved[rnd] = {"ts": ts, "skipped": False}
                st.round_start[rnd + 1] = ts
        elif a == "hint":
            v = str(e.get("value") or "")
            if v.startswith("w"):                         # round 0, value "w2": tier 2 of the warrant hints
                st.warrant_hints_used = max(st.warrant_hints_used, int(v[1:] or 0))
            elif rnd == 0:                                # round 0, value "2": tier 2 of the Ledger hints
                st.ledger_hints_used = max(st.ledger_hints_used, int(v or 0))
            else:
                st.hints_used[rnd] = max(st.hints_used.get(rnd, 0), int(v or 0))
        elif a == "warrant":
            st.warrant_attempts += 1
            if e.get("correct"):
                st.warrant_correct = True
        elif a == "ledger_file":
            st.ledger_last_attempt = ts
            if e.get("correct"):
                st.ledger_correct = True
        elif a == "upload_page":
            st.upload_pages += 1
            if int(e.get("points") or 0) > 0:
                st.upload_awarded = True
        elif a == "stage":
            idx = STAGE_IDX.get(str(e.get("value") or ""))
            if idx and idx > st.stage_idx:                 # idempotent, and it never lowers
                for k in range(st.stage_idx + 1, idx + 1):
                    st.stage_ts[k] = ts
                st.stage_idx = idx
        elif a == "solve":
            step = e.get("value") or ""
            if step.startswith("round") and step[5:].isdigit():
                n = int(step[5:])
                if n not in st.solved:
                    st.solved[n] = {"ts": ts, "skipped": True}
                    st.round_start[n + 1] = ts
                if st.started_at is None:
                    st.started_at = ts
                    st.round_start[1] = ts
            elif step == "warrant":
                st.warrant_skipped = True
            elif step == "ledger":
                st.ledger_skipped = True
            elif step == "upload":
                st.upload_skipped = True
    if gate:
        # The clock for round n+1 starts when round n is filed AND its stage has opened, whichever is later, so the time a player
        # spends clicking Check in the Instruqt panel never costs time-bonus points. Before the stage opens there is no clock.
        for n, info in st.solved.items():
            opened = st.stage_ts.get(n + 1)
            if opened is None:
                st.round_start.pop(n + 1, None)
            elif info.get("ts") is not None:
                st.round_start[n + 1] = max(info["ts"], opened)
    return st


# ====================================================================================================== engine
class Engine:
    def __init__(self, game: GameFile, store: EventStore, clock: Callable[[], datetime] = utcnow,
                 rng: random.Random | None = None, llm_model: Callable[[], str | None] = lambda: None,
                 gate: bool = False):
        self.gate = gate                    # GATE_BY_CHALLENGE: parts of the game open with their Instruqt challenge (see STAGES)
        self.game_file = game
        self.store = store
        self.clock = clock
        self.rng = rng or random.Random()
        self.lock = threading.RLock()
        self.llm_model = llm_model

    # ---------------------------------------------------------------- helpers
    @property
    def game(self) -> GameData:
        return self.game_file.get()

    def state(self) -> State:
        self.store.ensure_loaded()
        return derive(self.store.snapshot(), self.game, self.gate)

    def _ensure_handle(self, st: State) -> State:
        if st.handle:
            return st
        h = self.game.make_handle(self.rng)
        self.store.append("handle", 0, h, points=0, handle=h, score_after=st.score)
        st.handle = h
        return st

    def _emit(self, st: State, action: str, round: int = 0, value: str = "", correct: bool | None = None,
              points: int = 0, ocr_secs: float | None = None) -> dict:
        ev = self.store.append(action, round, value, correct, points, handle=st.handle or "",
                               score_after=st.score + points, ocr_secs=ocr_secs, ts=self.clock())
        st.score += points
        return ev

    def _session_state(self) -> State:
        st = self.state()
        return self._ensure_handle(st)

    def current_round(self, st: State) -> int:
        """First unsolved round (the last round once everything is solved); 1 before the case is opened."""
        n_rounds = max(1, self.game.n_rounds)
        if not st.started:
            return 1
        for n in range(1, n_rounds + 1):
            if n not in st.solved:
                return n
        return n_rounds

    def _require_round_open(self, st: State, n: int) -> None:
        self.game.round(n)
        if n not in st.unlocked_rounds():
            if st.gate and (n - 1) in st.solved and st.stage_idx < n:      # filed the previous city, waiting on the challenge
                raise self._stage_locked(n, f"round{n}")
            raise ApiError(403, "round_locked", "That round is not open yet.")

    # ---------------------------------------------------------------- gating (GATE_BY_CHALLENGE)
    @staticmethod
    def _stage_locked(challenge: int, stage: str) -> ApiError:
        return ApiError(403, "stage_locked", f"Opens in Challenge {challenge}.", challenge=challenge, stage=stage)

    def require_stage(self, name: str, st: State | None = None) -> State:
        """403 `stage_locked` unless gating is off or the stage has reached `name`. Returns the state."""
        st = st or self.state()
        if not st.stage_reached(name):
            raise self._stage_locked(STAGE_IDX[name], name)
        return st

    def _warrant_done(self, st: State) -> bool:
        return (st.warrant_correct or st.warrant_skipped
                or self.game.scoring["warrant_max_attempts"] - st.warrant_attempts <= 0)

    def waiting_for(self, st: State) -> dict | None:
        """What the player has earned but the Instruqt challenge has not opened yet (None when gating is off or nothing waits):
        {"kind": "round"|"warrant"|"upload", "challenge": N, "round": N (rounds only)}."""
        if not st.gate or not st.started:
            return None
        g = self.game
        for n in sorted(st.solved):
            if n < g.n_rounds and (n + 1) not in st.solved and st.stage_idx < n + 1:
                return {"kind": "round", "round": n + 1, "challenge": n + 1}
        if g.n_rounds and all(k in st.solved for k in range(1, g.n_rounds + 1)):
            if not self._warrant_done(st):
                if not st.stage_reached("warrant"):
                    return {"kind": "warrant", "challenge": STAGE_IDX["warrant"]}
            elif not st.stage_reached("upload") and st.upload_pages == 0 and not st.upload_skipped:
                return {"kind": "upload", "challenge": STAGE_IDX["upload"]}
        return None

    def gate_info(self, st: State) -> dict:
        """The `gate` block of GET /api/session. `locks` maps each late part of the game to the challenge that opens it
        (None = open). With gating off nothing is locked and nothing waits (the stage is still reported)."""
        lock = lambda name: None if st.stage_reached(name) else STAGE_IDX[name]  # noqa: E731
        return {"enabled": st.gate, "stage": st.stage, "challenge": st.stage_idx, "waiting_for": self.waiting_for(st),
                "locks": {"warrant": lock("warrant"), "upload": lock("upload"), "ledger": lock("bonus")}}

    def _require_warrant_open(self, st: State) -> None:
        g = self.game
        if st.gate:
            self.require_stage("warrant", st)
            if g.n_rounds and g.n_rounds not in st.solved:
                raise ApiError(403, "warrant_locked", "Find the last stop before you ask for a warrant.")
        elif g.n_rounds and g.warrant_unlock_round() not in st.unlocked_rounds():
            raise ApiError(403, "warrant_locked", "Find the last stop before you ask for a warrant.")

    def ledger_is_open(self, st: State) -> bool:
        if st.gate:
            return st.stage_reached("bonus")
        return self.game.ledger_unlock_round() in st.unlocked_rounds()

    def raise_stage(self, stage: str) -> dict:
        """POST /api/admin/stage. Idempotent; never lowers. Written as a `stage` event (local only, never forwarded to HQ), so the
        stage survives a restart."""
        stage = (stage or "").strip().lower()
        if stage not in STAGE_IDX:
            raise ApiError(400, "bad_stage", f"stage must be one of {', '.join(STAGES)}")
        with self.lock:
            st = self._session_state()
            if STAGE_IDX[stage] <= st.stage_idx:
                return {"ok": True, "stage": st.stage, "changed": False}
            self._emit(st, "stage", 0, stage, None, 0)
            return {"ok": True, "stage": stage, "changed": True}

    # ---------------------------------------------------------------- session
    def session(self) -> dict:
        with self.lock:
            st = self._session_state()
            g = self.game
            cur = self.current_round(st)
            attempts_left = max(0, g.scoring["warrant_max_attempts"] - st.warrant_attempts)
            w_done = st.warrant_correct or st.warrant_skipped or attempts_left == 0
            return {
                "handle": st.handle,
                "score": st.score,
                "current_round": cur,
                "rounds_total": g.n_rounds,
                "round_started_at": iso(st.round_start[cur]) if cur in st.round_start else None,
                "solved": sorted(st.solved),
                "hints_used": {str(k): v for k, v in sorted(st.hints_used.items())},
                "warrant": {"done": w_done, "correct": st.warrant_correct, "attempts_left": attempts_left},
                "ledger": {"done": st.ledger_correct or st.ledger_skipped, "correct": st.ledger_correct},
                "ledger_hints_used": st.ledger_hints_used,
                "warrant_hints_used": st.warrant_hints_used,
                "upload": {"pages_done": st.upload_pages},
                "started": st.started,
                "llm_model": self.llm_model(),
                # ---- additive: Instruqt gating (GATE_BY_CHALLENGE). `stage` is the challenge reached; `gate` says what waits on it.
                "stage": st.stage,
                "gate": self.gate_info(st),
            }

    def start(self) -> dict:
        with self.lock:
            st = self._session_state()
            if not st.started:
                self._emit(st, "start", 1, "start")
                st = self.state()
            return {"current_round": 1, "round_started_at": iso(st.round_start[1])}

    def ensure_started(self) -> State:
        with self.lock:
            st = self._session_state()
            if not st.started:
                self._emit(st, "start", 1, "start")
                st = self.state()
            return st

    def reroll_handle(self) -> dict:
        with self.lock:
            st = self._session_state()
            if st.filings.get(1) or st.solved:
                raise ApiError(409, "handle_locked", "Your handle is fixed once you file your first city.")
            h = self.game.make_handle(self.rng)
            for _ in range(5):
                if h != st.handle:
                    break
                h = self.game.make_handle(self.rng)
            st.handle = h
            self.store.append("handle", 0, h, handle=h, score_after=st.score, ts=self.clock())
            return {"handle": h}

    # ---------------------------------------------------------------- case
    def case(self) -> dict:
        with self.lock:
            st = self._session_state()
            g = self.game
            unlocked = st.unlocked_rounds()
            rounds = []
            for r in g.rounds:
                n = r["round"]
                if n in unlocked:
                    used = st.hints_used.get(n, 0)
                    rounds.append({"round": n, "from": r.get("from"), "brief": r.get("brief"),
                                   "question": r.get("question"), "unlocked": True, "solved": n in st.solved,
                                   "hints": r.get("hints", [])[:used]})
                else:   # no brief, no origin city (it is the previous round's answer)
                    rounds.append({"round": n, "from": None, "brief": None, "question": None, "unlocked": False,
                                   "solved": False, "hints": []})
            return {"case": g.raw.get("case", {}), "rounds": rounds, "current_round": self.current_round(st),
                    # ---- additive (not in CONTRACT 6); the desk needs them ----
                    "case_number": g.case_number(),
                    # suspects carry no traits (players read the dossiers); main.py adds portrait_url
                    "suspects": [{k: s.get(k) for k in ("id", "name", "role", "dossier_doc_id")} for s in g.suspects],
                    "warrant": {"trait_vocab": g.warrant.get("trait_vocab", {}),
                                "trait_labels": g.warrant.get("trait_labels", {}),
                                "attempts": g.scoring["warrant_max_attempts"],
                                "hints_total": len(g.warrant.get("hints") or [])},
                    "ledger": {"question": g.ledger.get("question"), "unlock_round": g.ledger_unlock_round(),
                               "hints_total": len(g.ledger.get("hints") or []),
                               # which pages the Ledger counts (they can be corrected); only once the round is open
                               "receipt_doc_ids": (list(g.ledger.get("receipt_doc_ids") or [])
                                                   if self.ledger_is_open(st) else [])},
                    "scoring": {"hint_costs": g.scoring["hint_costs"], "time_bonus_max": g.scoring["time_bonus_max"],
                                "ledger_retry_seconds": g.scoring["ledger_cooldown_secs"],
                                "ledger_correct": g.scoring["ledger_correct"],
                                "ledger_correct_with_hint": g.scoring["ledger_correct_with_hint"]}}

    def hints(self) -> dict:
        """Every hint the player has already taken (the text is never re-charged): {"rounds": {"1": [...]}, "ledger": [...]}."""
        with self.lock:
            st = self._session_state()
            g = self.game
            out = {}
            for r in g.rounds:
                n = r["round"]
                if n in st.unlocked_rounds():
                    out[str(n)] = list(r.get("hints", []))[:st.hints_used.get(n, 0)]
            return {"rounds": out, "ledger": list(g.ledger.get("hints") or [])[:st.ledger_hints_used],
                    "warrant": list(g.warrant.get("hints") or [])[:st.warrant_hints_used]}

    def visible_doc_ids(self, st: State | None = None) -> list[str]:
        st = st or self.state()
        return self.game.doc_ids_for_rounds(st.unlocked_rounds())

    def unlocked_round_numbers(self, st: State | None = None) -> list[int]:
        """Round numbers whose docs may appear in search: 0 (always visible) plus every unlocked round."""
        st = st or self.state()
        return [0] + sorted(st.unlocked_rounds())

    # ---------------------------------------------------------------- game actions
    def file(self, n: int, city: str) -> dict:
        city = (city or "").strip()
        if not city or len(city) > 80:
            raise ApiError(400, "bad_city", "Type a city name.")
        with self.lock:
            st = self.ensure_started()
            self._require_round_open(st, n)
            g = self.game
            if n in st.solved:
                return {"correct": True, "points": 0, "score": st.score, "unlocked_round": n + 1 if n < g.n_rounds else None,
                        "message": "Already filed."}
            verdict = g.check_city(n, city)
            if verdict == "correct":
                secs = max(0.0, (self.clock() - st.round_start[n]).total_seconds())
                bonus = max(0, g.scoring["time_bonus_max"] - int(secs))
                pts = g.scoring["round_correct"] + bonus
                self._emit(st, "file", n, "correct", True, pts)
                last = n >= g.n_rounds
                wf = self.waiting_for(self.state()) if self.gate else None
                if wf:     # filed, but the next part opens with its Instruqt challenge
                    msg = (f"Round {n} is closed. The warrant is in Challenge {wf['challenge']}." if last
                           else f"Round {n} is closed. Your next lead is in Challenge {wf['challenge']}.")
                    return {"correct": True, "points": pts, "score": st.score, "unlocked_round": None,
                            "waiting_for": wf, "message": msg}
                return {"correct": True, "points": pts, "score": st.score,
                        "unlocked_round": None if last else n + 1,
                        "message": "That is the last stop. Time to name the thief." if last
                        else f"Confirmed. Round {n + 1} is open."}
            pts = -g.scoring["wrong_city_penalty"]
            self._emit(st, "file", n, verdict, False, pts)
            return {"correct": False, "points": pts, "score": st.score, "unlocked_round": None,
                    "message": "No match. The trail is still open."}

    def hint(self, n: int) -> dict:
        with self.lock:
            st = self.ensure_started()
            self._require_round_open(st, n)
            g = self.game
            if n in st.solved:
                raise ApiError(409, "round_solved", "That round is already solved.")
            hints = g.round(n).get("hints", [])
            costs = g.scoring["hint_costs"]
            used = st.hints_used.get(n, 0)
            if used >= len(hints):          # all revealed: re-show the last one for free
                if not hints:
                    raise ApiError(404, "no_hints", "No hints for this round.")
                return {"tier": len(hints), "text": hints[-1], "cost": 0, "score": st.score}
            tier = used + 1
            cost = costs[min(tier, len(costs)) - 1] if costs else 0
            self._emit(st, "hint", n, str(tier), None, -cost)
            return {"tier": tier, "text": hints[tier - 1], "cost": cost, "score": st.score}

    def _claim(self, traits, evidence) -> dict[str, tuple[str, str]]:
        """{trait: (value, doc_id)} for all three traits, or a 400 that costs nothing (no event, no attempt)."""
        g = self.game
        incomplete = ApiError(400, "incomplete_warrant", "Name all three traits and pick an exhibit that proves each one.")
        if not isinstance(traits, dict) or not isinstance(evidence, dict):
            raise incomplete
        claim: dict[str, tuple[str, str]] = {}
        for key in TRAIT_KEYS:
            v, doc = traits.get(key), evidence.get(key)
            if isinstance(v, (list, tuple)):               # an older client sent languages as a one-item list
                v = v[0] if len(v) == 1 else None
            if not isinstance(v, str) or not isinstance(doc, str) or not v.strip() or not doc.strip():
                raise incomplete
            v, doc = v.strip(), doc.strip()
            if len(v) > 40 or len(doc) > 80:
                raise incomplete
            if doc not in g.docs:
                raise ApiError(400, "unknown_exhibit", "Pick an exhibit from the evidence locker.")
            claim[key] = (v, doc)
        return claim

    def warrant(self, suspect_id: str, traits: dict | None = None, evidence: dict | None = None) -> dict:
        """Option B, "present your evidence". Accepted only if (a) every claimed trait is the thief's true trait, (b) each
        trait cites an exhibit that proves it, and (c) the named suspect is the thief. The ruling never says WHICH of (a)
        and (b) failed for an item; `dossier_conflicts` only compares the claim with the NAMED suspect's own dossier."""
        with self.lock:
            st = self.ensure_started()
            g = self.game
            self._require_warrant_open(st)
            if not any(s["id"] == suspect_id for s in g.suspects):
                raise ApiError(400, "unknown_suspect", "Pick one of the suspects.")
            max_attempts = g.scoring["warrant_max_attempts"]
            attempts_left = max_attempts - st.warrant_attempts
            if st.warrant_correct or st.warrant_skipped:
                raise ApiError(409, "warrant_done", "The warrant is already issued.")
            if attempts_left <= 0:
                raise ApiError(409, "warrant_closed", "No attempts left.")
            claim = self._claim(traits, evidence)
            items = [{"trait": k, "value": v, "exhibit": doc, "accepted": g.evidence_accepted(k, v, doc)}
                     for k, (v, doc) in claim.items()]
            all_accepted = all(i["accepted"] for i in items)
            named_is_thief = g.is_thief(suspect_id)
            conflicts = []
            for k, (v, _doc) in claim.items():
                have = g.dossier_values(suspect_id, k)
                if have and v not in have:
                    conflicts.append({"trait": k, "claimed": v, "dossier": have})
            correct = all_accepted and named_is_thief
            ruling = {"items": items,
                      # tri-state on purpose: only once all three items hold up is the suspect's fit decided, so a refusal with
                      # a bad item can never be used to probe "is this the thief?"
                      "suspect_fits": (named_is_thief if all_accepted else None),
                      "dossier_conflicts": conflicts}
            thief = g.thief()
            reveal = ({"suspect_id": thief["id"], "name": thief.get("name"), "role": thief.get("role")}
                      if thief else None)
            if correct:
                pts = g.scoring["warrant_correct"]
                self._emit(st, "warrant", 0, suspect_id, True, pts)
                out = {"correct": True, "points": pts, "score": st.score, "attempts_left": attempts_left - 1,
                       "ruling": ruling, "reveal": reveal}
                wf = self.waiting_for(self.state()) if self.gate else None
                if wf:
                    out["waiting_for"] = wf
                return out
            pts = -g.scoring["warrant_wrong_penalty"]
            self._emit(st, "warrant", 0, suspect_id, False, pts)
            left = attempts_left - 1
            out = {"correct": False, "points": pts, "score": st.score, "attempts_left": left, "ruling": ruling}
            if left <= 0:
                out["reveal"] = reveal
            return out

    def warrant_hint(self) -> dict:
        """Warrant hints (game.json warrant.hints): same tiers and costs as the round hints (hint_costs). Event: a `hint`
        with round 0 and value "w<tier>" (round-0 plain tiers belong to the Ledger)."""
        with self.lock:
            st = self.ensure_started()
            g = self.game
            self._require_warrant_open(st)
            if st.warrant_correct or st.warrant_skipped or st.warrant_attempts >= g.scoring["warrant_max_attempts"]:
                raise ApiError(409, "warrant_done", "The warrant is already settled.")
            hints = g.warrant.get("hints") or []
            if not hints:
                raise ApiError(404, "no_hints", "No hints for the warrant.")
            costs = g.scoring["hint_costs"]
            used = st.warrant_hints_used
            if used >= len(hints):          # all revealed: re-show the last one for free
                return {"tier": len(hints), "text": hints[-1], "cost": 0, "score": st.score}
            tier = used + 1
            cost = costs[min(tier, len(costs)) - 1] if costs else 0
            self._emit(st, "hint", 0, f"w{tier}", None, -cost)
            return {"tier": tier, "text": hints[tier - 1], "cost": cost, "score": st.score}

    # ---------------------------------------------------------------- ledger
    def ledger_open(self) -> State:
        """Raises unless the Ledger round has opened. Returns the state."""
        with self.lock:
            st = self.ensure_started()
            g = self.game
            if st.gate:
                return self.require_stage("bonus", st)         # the Ledger is the bonus challenge's
            if g.ledger_unlock_round() not in st.unlocked_rounds():
                raise ApiError(403, "ledger_locked", f"The Ledger opens in Round {g.ledger_unlock_round()}.")
            return st

    def ledger_hint(self) -> dict:
        """Ledger hints (game.json ledger.hints) cost nothing now; using any lowers the Ledger award to
        ledger_correct_with_hint (plan 2.7: +500, or +250 with a hint)."""
        with self.lock:
            st = self.ledger_open()
            g = self.game
            hints = g.ledger.get("hints") or []
            if st.ledger_correct:
                raise ApiError(409, "ledger_done", "The Ledger is already filed.")
            if not hints:
                raise ApiError(404, "no_hints", "No hints for the Ledger.")
            reduction = g.scoring["ledger_correct"] - g.scoring["ledger_correct_with_hint"]
            used = st.ledger_hints_used
            if used >= len(hints):
                return {"tier": len(hints), "text": hints[-1], "cost": 0, "score": st.score,
                        "ledger_bonus_reduced_by": reduction}
            self._emit(st, "hint", 0, str(used + 1), None, 0)
            return {"tier": used + 1, "text": hints[used], "cost": 0, "score": st.score,
                    "ledger_bonus_reduced_by": reduction}

    def ledger_file(self, total: float) -> dict:
        with self.lock:
            st = self.ledger_open()
            g = self.game
            if st.ledger_correct:
                return {"correct": True, "points": 0, "score": st.score, "message": "Already filed."}
            cd = g.scoring["ledger_cooldown_secs"]
            if st.ledger_last_attempt is not None and cd:
                wait = cd - (self.clock() - st.ledger_last_attempt).total_seconds()
                if wait > 0:
                    return {"correct": False, "points": 0, "score": st.score, "cooldown_secs": int(wait) + 1,
                            "message": f"The accountant needs a minute. Try again in {int(wait) + 1} s."}
            if g.check_total(total):
                pts = g.scoring["ledger_correct_with_hint" if st.ledger_hints_used else "ledger_correct"]
                self._emit(st, "ledger_file", g.ledger_unlock_round(), "correct", True, pts)
                return {"correct": True, "points": pts, "score": st.score, "message": "The books balance."}
            self._emit(st, "ledger_file", g.ledger_unlock_round(), "wrong", False, 0)
            return {"correct": False, "points": 0, "score": st.score, "cooldown_secs": cd,
                    "message": "That does not match the accountant's total. A receipt can be misread or "
                               "missing: compare each page image with its text."}

    def ledger_receipt_ids(self) -> list[str]:
        return list(self.game.ledger.get("receipt_doc_ids", []))

    def record_ledger_correction(self, doc_id: str) -> None:
        with self.lock:
            st = self._session_state()
            self._emit(st, "ledger_correct", self.game.ledger_unlock_round(), doc_id, None, 0)

    # ---------------------------------------------------------------- uploads, asks
    def record_ask(self, scope: str) -> None:
        with self.lock:
            st = self._session_state()
            self._emit(st, "ask", self.current_round(st) if scope == "case" else 99, scope)

    def record_upload_page(self, job_id: str, ocr_secs: float | None, award: bool = True, ok: bool = True) -> int:
        """One OCR'd page of a player upload. The first page ever earns the 'worst PDF' bonus. Returns points."""
        with self.lock:
            st = self._session_state()
            pts = 0
            if award and ok and not st.upload_awarded:
                pts = self.game.scoring["upload_first_page"]
            self._emit(st, "upload_page", 99, job_id, ok, pts, ocr_secs=ocr_secs)
            return pts

    # ---------------------------------------------------------------- admin / progress
    def solve(self, step: str) -> dict:
        step = (step or "").strip().lower()
        if step not in STEPS and not (step.startswith("round") and step[5:].isdigit()):
            raise ApiError(400, "bad_step", f"step must be one of {', '.join(STEPS)}")
        with self.lock:
            st = self._session_state()
            if step.startswith("round") and not (1 <= int(step[5:]) <= self.game.n_rounds):
                raise ApiError(400, "bad_step", "No such round.")
            self._emit(st, "solve", int(step[5:]) if step.startswith("round") else 0, step, True, 0)
            return {"ok": True, "step": step, "skipped": True}

    def progress(self, step: str) -> dict:
        step = (step or "").strip().lower()
        if step not in STEPS:
            raise ApiError(400, "bad_step", f"step must be one of {', '.join(STEPS)}")
        with self.lock:
            st = self.state()
            g = self.game
            if step.startswith("round"):
                n = int(step[5:])
                info = st.solved.get(n)
                return {"step": step, "done": info is not None, "correct": bool(info and not info["skipped"]),
                        "skipped": bool(info and info["skipped"])}
            if step == "warrant":
                done = st.warrant_correct or st.warrant_skipped or st.warrant_attempts >= g.scoring["warrant_max_attempts"]
                return {"step": step, "done": done, "correct": st.warrant_correct,
                        "skipped": st.warrant_skipped and not st.warrant_correct}
            if step == "ledger":
                return {"step": step, "done": st.ledger_correct or st.ledger_skipped, "correct": st.ledger_correct,
                        "skipped": st.ledger_skipped and not st.ledger_correct}
            done = st.upload_pages > 0 or st.upload_skipped      # upload
            return {"step": step, "done": done, "correct": st.upload_pages > 0,
                    "skipped": st.upload_skipped and st.upload_pages == 0}
