"""The "Sample PDF" page for the bonus challenge: what `pipeline.py` reads, shown where a player can see it.

The Instruqt code editor cannot display a PDF, and Chrome blocks its PDF viewer inside the sandboxed iframes that Instruqt
service tabs use. So `GET /sample-pdf` is a plain HTML page with every page of ${CORPUS_DIR}/sample-worst.pdf as an image,
rendered with pymupdf at ~110 dpi and cached in the app data dir. `GET /sample-pdf/raw` is the file itself, inline, for anyone
who wants it (opened in a new tab, never as the main view).

Challenge 06's setup copies the very same file to /root/pipeline/sample.pdf, so this page shows what the script reads.
"""
from __future__ import annotations

import html
import io
import logging
import re
import threading
from pathlib import Path

from detective_core.render import rasterize_pdf

log = logging.getLogger("detective.samplepdf")

DPI = 110
JPEG_QUALITY = 82
TITLE = "sample.pdf: the file pipeline.py reads"

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title>
<style>
@font-face{{font-family:'Special Elite';font-weight:400;font-style:normal;font-display:swap;src:url('/fonts/special-elite-latin-400-normal.woff2') format('woff2')}}
@font-face{{font-family:'Inter';font-weight:500;font-style:normal;font-display:swap;src:url('/fonts/inter-latin-500-normal.woff2') format('woff2')}}
:root{{--desk:#0B1220;--panel:#121D33;--line:#26365A;--text:#D9E0EE;--dim:#98A8C3;--teal:#48EFCF;--blue:#4D93F0}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--desk);color:var(--text);font:15px/1.5 'Inter',system-ui,-apple-system,'Segoe UI',Arial,sans-serif}}
main{{max-width:980px;margin:0 auto;padding:22px 20px 56px}}
h1{{font:400 24px/1.25 'Special Elite','Courier New',Courier,monospace;margin:0 0 6px;color:#fff}}
.rule{{display:block;width:44px;height:4px;background:var(--teal);border-radius:2px;margin-bottom:10px}}
p.lead{{margin:0 0 14px;color:var(--dim)}}
a.raw{{display:inline-block;color:var(--desk);background:var(--teal);font-weight:500;text-decoration:none;padding:7px 14px;border-radius:8px}}
a.raw:hover{{background:#7af3dc}}
figure{{margin:22px 0 0;background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:12px}}
figcaption{{font:12px/1 'Space Mono',ui-monospace,Menlo,monospace;letter-spacing:.06em;text-transform:uppercase;color:var(--dim);margin-bottom:10px}}
img{{display:block;width:100%;height:auto;background:#fff;border-radius:6px;box-shadow:0 6px 22px rgba(0,0,0,.45)}}
</style></head><body><main>
<span class="rule"></span>
<h1>{title}</h1>
<p class="lead">{lead}</p>
<a class="raw" href="/sample-pdf/raw" target="_blank" rel="noopener">Open the raw PDF</a>
{figures}
</main></body></html>"""

MISSING = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>{title}</title>
<style>body{{font-family:Georgia,serif;background:#0B1220;color:#D9E0EE;display:flex;align-items:center;justify-content:center;
height:100vh;margin:0}}main{{text-align:center;max-width:32em}}</style></head><body><main><h1>The sample PDF is not here yet</h1>
<p>The evidence locker is still loading, or this sandbox has no sample-worst.pdf. Try again in a moment.</p></main></body></html>"""


class SamplePdf:
    def __init__(self, cfg):
        self.cfg = cfg
        self._lock = threading.Lock()

    @property
    def pdf_path(self) -> Path:
        return Path(self.cfg.corpus_dir) / "sample-worst.pdf"

    @property
    def cache_dir(self) -> Path:
        return Path(self.cfg.app_data_dir) / "sample-pdf"

    def _key(self) -> str:
        st = self.pdf_path.stat()
        return f"{st.st_size}-{int(st.st_mtime)}-{DPI}"

    def _file(self, n: int) -> Path:
        return self.cache_dir / f"{self._key()}-p{n}.jpg"

    def pages(self) -> int:
        """Render (once) and cache every page. Returns the page count; raises FileNotFoundError without the PDF."""
        with self._lock:
            key = self._key()
            marker = self.cache_dir / f"{key}.count"
            if marker.is_file():
                try:
                    n = int(marker.read_text())
                    if all(self._file(i).is_file() for i in range(1, n + 1)):
                        return n
                except (OSError, ValueError):
                    pass
            imgs = rasterize_pdf(self.pdf_path.read_bytes(), dpi=DPI)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            for i, img in enumerate(imgs, 1):
                buf = io.BytesIO()
                img.convert("RGB").save(buf, "JPEG", quality=JPEG_QUALITY, optimize=True)
                tmp = self._file(i).with_suffix(".tmp")
                tmp.write_bytes(buf.getvalue())
                tmp.replace(self._file(i))
            marker.write_text(str(len(imgs)))
            for old in self.cache_dir.glob("*"):            # a replaced sample PDF leaves stale renders behind
                if not old.name.startswith(key):
                    old.unlink(missing_ok=True)
            return len(imgs)

    def page_file(self, n: int) -> Path | None:
        if not self.pdf_path.is_file():
            return None
        try:
            count = self.pages()
        except Exception as exc:  # noqa: BLE001
            log.warning("sample pdf render failed: %s", exc)
            return None
        return self._file(n) if 1 <= n <= count else None

    def html(self) -> tuple[str, int]:
        """(page html, http status)."""
        if not self.pdf_path.is_file():
            return MISSING.format(title=html.escape(TITLE)), 404
        try:
            count = self.pages()
        except Exception as exc:  # noqa: BLE001
            log.warning("sample pdf render failed: %s", exc)
            return MISSING.format(title=html.escape(TITLE)), 500
        figures = "\n".join(
            f'<figure><figcaption>Page {i} of {count}</figcaption>'
            f'<img src="/sample-pdf/page/{i}.jpg" alt="sample.pdf, page {i} of {count}" loading="lazy"></figure>'
            for i in range(1, count + 1))
        lead = ("This is the document <code>pipeline.py</code> turns into searchable markdown. "
                "Run it in the Terminal tab and compare what it writes with these pages.")
        return PAGE.format(title=html.escape(TITLE), lead=lead, figures=figures), 200


PAGE_RE = re.compile(r"^(\d{1,3})\.jpg$")
