"""POST /api/docs/{doc_id}/pages/{n}/translate: "Translate to English" for the page viewer.

* The source text is the page's `ocr_md` (what the Detective's OCR read). Never the image, never the Rookie's `rookie_raw`.
* The same resolved chat LLM as the partners (LLMHolder), with a timeout that keeps the call under the 20 s contract.
* Cached per (doc_id, page, sha1(ocr_md)): in memory and in one small JSON file in the app data dir. A per-key lock means
  two clicks (or two tabs) make one LLM call. Re-OCRing a page changes the hash, so a stale translation is never served.
* The model starts its reply with `Source language: <name>`. That line is parsed off (never shown to players) and returned
  as `source_lang` (None when the model left it out or it is unusable). A cache entry with no `source_lang` key predates
  this and counts as a miss.
* Writes no game event: the HQ leaderboard must not change.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import threading
import time
from pathlib import Path

from detective_core.prompts import TRANSLATE_SYSTEM_PROMPT

from game import ApiError

log = logging.getLogger("detective.translate")

LLM_TIMEOUT = 17.0           # seconds; the contract says every call finishes in under 20 s
MAX_CHARS = 12_000           # a page of OCR text is ~1-2k characters; refuse a page that cannot finish in time
MAX_ENTRIES = 2000           # cache cap (oldest dropped first)
CACHE_FILE = "translations.json"


# The first non-empty line of the model's reply: `Source language: Italian` (any case, optional Markdown decoration).
_SOURCE_LINE_RE = re.compile(r"^[\s>*_`#\-]*source\s+language\s*[:\uff1a=\-\u2013\u2014]\s*(?P<v>.*?)\s*$", re.IGNORECASE)
_NO_LANGUAGE = {"", "unknown", "unclear", "unspecified", "none", "n/a", "na", "null", "undetermined", "not applicable"}


def clean_language(value: str) -> str | None:
    """A language name the UI can show, or None: strips Markdown decoration and a trailing period, caps the length."""
    v = re.sub(r"[*_`\"\u201c\u201d]+", "", value or "").strip().rstrip(".").strip()
    if v.lower() in _NO_LANGUAGE or len(v) > 40 or not re.fullmatch(r"[^\W\d_][\w \-',/()]*", v):
        return None
    return v[0].upper() + v[1:]


def split_source_lang(raw: str) -> tuple[str | None, str]:
    """`(source_lang | None, translation)` from the model's raw reply.

    Looks at the FIRST non-empty line only, case-insensitively. If it is the `Source language:` line it is always removed
    (even when its value is unusable, so the raw line never reaches a player) and the blank lines after it are dropped.
    A reply without that line comes back unchanged with `source_lang` None."""
    text = (raw or "").strip()
    if not text:
        return None, ""
    first, _, rest = text.partition("\n")
    m = _SOURCE_LINE_RE.match(first)
    if not m:
        return None, text
    return clean_language(m.group("v")), rest.strip()


def cache_key(doc_id: str, page: int, ocr_md: str) -> str:
    return f"{doc_id}|{int(page)}|{hashlib.sha1(ocr_md.encode('utf-8')).hexdigest()}"


class TranslateService:
    def __init__(self, cfg, llm):
        self.llm = llm                                      # LLMHolder
        self.path = Path(cfg.app_data_dir) / CACHE_FILE
        self._mem: dict[str, dict] = {}
        self._loaded = False
        self._lock = threading.Lock()                       # guards _mem, _key_locks, the file
        self._key_locks: dict[str, threading.Lock] = {}

    # ------------------------------------------------------------------ cache
    def _load(self) -> None:
        """Lazy, once. A missing or corrupt file just means an empty cache."""
        if self._loaded:
            return
        self._loaded = True
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                for k, v in data.items():
                    if (isinstance(v, dict) and isinstance(v.get("text_md"), str) and v.get("model")
                            and "source_lang" in v):             # older entries (no source_lang key) are misses
                        self._mem.setdefault(k, v)
        except FileNotFoundError:
            pass
        except (OSError, ValueError) as exc:
            log.warning("translation cache unreadable (%s); starting empty", exc)

    def _get(self, key: str) -> dict | None:
        with self._lock:
            self._load()
            return self._mem.get(key)

    def _put(self, key: str, entry: dict, persist: bool) -> None:
        with self._lock:
            self._load()
            self._mem[key] = entry
            while len(self._mem) > MAX_ENTRIES:
                self._mem.pop(next(iter(self._mem)))
            if persist:
                self._write()

    def _write(self) -> None:
        """Atomic replace; mock translations are never in `_mem` for the file (they are filtered here)."""
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_name(f"{self.path.name}.{os.getpid()}.tmp")
            keep = {k: v for k, v in self._mem.items() if not v.get("mock")}
            tmp.write_text(json.dumps(keep, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError as exc:
            log.warning("could not persist the translation cache: %s", exc)

    def _key_lock(self, key: str) -> threading.Lock:
        with self._lock:
            return self._key_locks.setdefault(key, threading.Lock())

    @staticmethod
    def _out(doc_id: str, page: int, entry: dict, cached: bool, ms: int) -> dict:
        return {"doc_id": doc_id, "page": page, "text_md": entry["text_md"], "model": entry["model"],
                "source_lang": entry.get("source_lang"), "ms": ms, "cached": cached}

    # ------------------------------------------------------------------ public
    def translate(self, doc_id: str, page: int, ocr_md: str) -> dict:
        t0 = time.monotonic()
        if len(ocr_md) > MAX_CHARS:
            raise ApiError(422, "too_long", "This page has too much text to translate in one go.")
        key = cache_key(doc_id, page, ocr_md)
        hit = self._get(key)
        if hit:
            return self._out(doc_id, page, hit, True, int((time.monotonic() - t0) * 1000))
        with self._key_lock(key):
            hit = self._get(key)                            # a concurrent request may have finished while we waited
            if hit:
                return self._out(doc_id, page, hit, True, int((time.monotonic() - t0) * 1000))
            try:
                llm = self.llm.get()
                text = llm.chat(TRANSLATE_SYSTEM_PROMPT, ocr_md, timeout=LLM_TIMEOUT, retries=0)
            except Exception as exc:  # noqa: BLE001
                log.warning("translate failed for %s p%s: %s", doc_id, page, exc)
                s = str(exc).lower()
                if "timed out" in s or "timeout" in s or isinstance(exc, TimeoutError):
                    raise ApiError(504, "translate_timeout", "The translation took too long. Try again.") from exc
                raise ApiError(502, "translate_failed", "Could not translate this page right now. Try again.") from exc
            source_lang, text = split_source_lang(text)
            if not text:
                raise ApiError(502, "translate_empty", "The model returned nothing. Try again.")
            ms = int((time.monotonic() - t0) * 1000)
            mock = bool(getattr(llm, "is_mock", False))
            entry = {"text_md": text, "model": llm.model_id, "source_lang": source_lang, "ms": ms, "doc_id": doc_id,
                     "page": int(page)}
            if mock:
                entry["mock"] = True
            self._put(key, entry, persist=not mock)
            return self._out(doc_id, page, entry, False, ms)
