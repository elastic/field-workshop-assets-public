"""Backend wrapper around detective_core.retrieval (the queries the validator runs).

It reuses L2's request bodies unchanged and adds exactly one thing: a filter on `round`, so a player never gets hits
(or excerpts) from rounds that have not unlocked yet. With rounds=None the bodies are identical to the validator's.
"""
from __future__ import annotations

import copy
import dataclasses
import html
import re

from detective_core import retrieval as core
from detective_core.embed import omni_text
from detective_core.index import index_name
from detective_core.retrieval import Hit

MAX_EXCERPT_CHARS = 6000        # safety cap per excerpt; identical for the Rookie and the Detective

_CITE_RE = re.compile(r"\b([A-Za-z]{1,6}-\d{1,4})\s*,?\s*p\.?\s*(\d+)")


def round_filter(rounds: list[int] | None) -> dict | None:
    return {"terms": {"round": sorted(set(rounds))}} if rounds is not None else None


def rookie_body(question: str, rounds: list[int] | None = None, size: int = core.ROOKIE_SIZE) -> dict:
    body = core.rookie_body(question, size)
    f = round_filter(rounds)
    if f:
        body["query"] = {"bool": {"must": [body["query"]], "filter": [f]}}
    return body


def photolab_body(vector: list[float], rounds: list[int] | None = None, k: int = core.PHOTOLAB_K,
                  exclude: tuple[str, int] | None = None) -> dict:
    body = core.photolab_body(vector, k)
    f = round_filter(rounds)
    filters = [f] if f else []
    if exclude:
        filters.append({"bool": {"must_not": [{"bool": {"must": [{"term": {"doc_id": exclude[0]}},
                                                                    {"term": {"page": exclude[1]}}]}}]}})
    if filters:
        body["knn"]["filter"] = filters[0] if len(filters) == 1 else {"bool": {"filter": filters}}
    return body


def detective_body(question: str, rounds: list[int] | None = None, size: int = core.DETECTIVE_SIZE) -> dict:
    body = core.detective_body(question, size)
    f = round_filter(rounds)
    if f:
        for r in body["retriever"]["rrf"]["retrievers"]:
            # keep the core's own filter (NOT_SKIPPED_FILTER: photos skip OCR and are never retrieved) and add the round filter
            r["standard"]["filter"] = [*(r["standard"].get("filter") or []), copy.deepcopy(f)]
    return body


# ----------------------------------------------------------------------------------------------- searches
def search_rookie(es, prefix: str, question: str, rounds: list[int] | None, timeout: float = 10) -> list[Hit]:
    r = es.post(f"{index_name(prefix, 'evidence-rookie')}/_search", json=rookie_body(question, rounds),
                timeout=timeout, retries=1)
    return core._hits(r, "rookie_raw")


def search_detective(es, prefix: str, question: str, rounds: list[int] | None, scope: str = "case",
                     timeout: float = 10) -> list[Hit]:
    base = "evidence-mine" if scope == "mine" else "evidence-detective"
    body = detective_body(question, None if scope == "mine" else rounds)
    r = es.post(f"{index_name(prefix, base)}/_search", json=body, timeout=timeout, retries=1)
    return core._hits(r, "ocr_text")


def embed_question(es, question: str, timeout: float = 10) -> list[float]:
    return omni_text(question, es=es, timeout=timeout, retries=1)


def knn_photolab(es, prefix: str, vector: list[float], rounds: list[int] | None, k: int = core.PHOTOLAB_K,
                 exclude: tuple[str, int] | None = None, timeout: float = 10) -> list[Hit]:
    r = es.post(f"{index_name(prefix, 'evidence-photolab')}/_search",
                json=photolab_body(vector, rounds, k, exclude), timeout=timeout, retries=1)
    return core._hits(r, None)


def search_photolab(es, prefix: str, question: str, rounds: list[int] | None, timeout: float = 10) -> list[Hit]:
    return knn_photolab(es, prefix, embed_question(es, question, timeout), rounds, timeout=timeout)


def page_vector(es, prefix: str, doc_id: str, page: int, timeout: float = 10) -> list[float] | None:
    """The stored image vector of one page (for image->image 'find similar'). Vectors are not in _source by default.

    The Photo Lab index may also hold *figure* docs (images extracted from inside the page, same doc_id and page);
    those are skipped here, the vector wanted is the whole page's."""
    r = es.post(f"{index_name(prefix, 'evidence-photolab')}/_search", timeout=timeout, retries=1, json={
        "size": 10, "_source": ["kind"], "fields": ["image_vector"],
        "query": {"bool": {"filter": [{"term": {"doc_id": doc_id}}, {"term": {"page": page}}]}}})
    for h in r.get("hits", {}).get("hits", []):
        if (h.get("_source") or {}).get("kind") == "figure":
            continue
        vec = (h.get("fields") or {}).get("image_vector")
        if vec and isinstance(vec[0], list):
            vec = vec[0]
        if vec:
            return vec
    return None


# ----------------------------------------------------------------------------------------------- excerpts / answers
def excerpts(hits: list[Hit]) -> list[str]:
    """Same `[EX-07 p1 · <title>] <text>` blocks for both partners (detective_core.prompts.format_excerpt), capped for safety."""
    capped = []
    for h in hits:
        if h.text and h.text.strip():
            capped.append(dataclasses.replace(h, text=h.text[:MAX_EXCERPT_CHARS]))      # keeps the title for the header
    return core.excerpts(capped)


def cited_hits(answer: str, hits: list[Hit]) -> list[Hit]:
    """Hits whose [EX-07 p1] tag appears in the answer, in order of first citation."""
    by_tag = {(h.exhibit.lower(), h.page): h for h in hits}
    out, seen = [], set()
    for m in _CITE_RE.finditer(answer or ""):
        key = (m.group(1).lower(), int(m.group(2)))
        if key in by_tag and key not in seen:
            seen.add(key)
            out.append(by_tag[key])
    return out


def plain_snippet(text: str, n: int = 240) -> str:
    return re.sub(r"\s+", " ", text or "").strip()[:n]


def safe_snippet_html(h: Hit) -> str:
    return h.snippet_html or (html.escape(plain_snippet(h.text, 220)) if h.text else "")
