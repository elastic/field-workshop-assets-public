#!/usr/bin/env bash
# Document Detective backend: nohup-friendly restart loop.
#   CORPUS_DIR=/path/to/assets/case/out ES_URL=... ES_API_KEY=... ./run.sh
#   nohup ./run.sh > /var/log/detective.log 2>&1 &
# Env (all optional except ES_URL / ES_API_KEY / CORPUS_DIR for real use):
#   INDEX_PREFIX, LLM_PREFERENCE, EVENT_ID, SANDBOX_ID, DETECTIVE_HQ_URL, DETECTIVE_HQ_KEY, ADMIN_TOKEN_FILE,
#   PORT (5001), MOCK_LLM (0), UPLOAD_DIR, DATA_DIR, FRONTEND_DIST, DOTENV_PATH, PYTHON (interpreter to use)
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"          # the directory that contains app/ and detective_core/
cd "$HERE"
export PORT="${PORT:-5001}"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
if [ -n "${PYTHON:-}" ]; then PY="$PYTHON"
elif [ -x "$ROOT/.venv/bin/python" ]; then PY="$ROOT/.venv/bin/python"
else PY="python3"; fi

CHILD=""
trap 'if [ -n "$CHILD" ]; then kill "$CHILD" 2>/dev/null; fi; exit 0' TERM INT
while true; do
  "$PY" -m uvicorn main:app --host 0.0.0.0 --port "$PORT" --workers 1 --log-level info &
  CHILD=$!
  wait "$CHILD"
  echo "[run.sh] uvicorn exited ($?); restarting in 2 s" >&2
  sleep 2
done
