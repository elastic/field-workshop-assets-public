"""The Ledger console: a read-only ES|QL pass-through locked to ONE index.

Allowed shape:  FROM <that index> [METADATA _id, ...] | <command> ... | <command> ...
The index may be written with or without the INDEX_PREFIX; it is rewritten to the prefixed name.
Everything else is rejected before it reaches Elasticsearch: other indices, wildcards, cross-cluster, subqueries,
LOOKUP JOIN / ENRICH / FORK / COMPLETION / RERANK, and any command outside a small allow-list.
"""
from __future__ import annotations

import re

INDEX_BASES = {"detective": "evidence-detective", "rookie": "evidence-rookie", "photolab": "evidence-photolab"}
ALLOWED_COMMANDS = {"where", "stats", "eval", "sort", "limit", "keep", "drop", "rename", "dissect", "grok",
                    "mv_expand", "inlinestats", "sample"}
MAX_QUERY_CHARS = 2000
MAX_ROWS = 200


class QueryRejected(ValueError):
    pass


def _scrub(q: str) -> tuple[str, str]:
    """Return (query without comments, same query with string literal contents blanked).

    Comments (// and /* */) are removed only outside string literals; the first value is what we send.
    """
    out, blank = [], []
    i, n = 0, len(q)
    while i < n:
        c = q[i]
        if q.startswith('"""', i):
            j = q.find('"""', i + 3)
            if j < 0:
                raise QueryRejected("Unterminated string literal.")
            out.append(q[i:j + 3]); blank.append('"""' + " " * (j - i - 3) + '"""')
            i = j + 3
        elif c == '"':
            j = i + 1
            while j < n and q[j] != '"':
                j += 2 if q[j] == "\\" else 1
            if j >= n:
                raise QueryRejected("Unterminated string literal.")
            out.append(q[i:j + 1]); blank.append('"' + " " * (j - i - 1) + '"')
            i = j + 1
        elif q.startswith("//", i):
            j = q.find("\n", i)
            i = n if j < 0 else j
        elif q.startswith("/*", i):
            j = q.find("*/", i + 2)
            if j < 0:
                raise QueryRejected("Unterminated comment.")
            out.append(" "); blank.append(" ")
            i = j + 2
        else:
            out.append(c); blank.append(c)
            i += 1
    return "".join(out), "".join(blank)


_HEAD_RE = re.compile(r"^from\s+([A-Za-z0-9_.\-]+)\s*(metadata\s+[A-Za-z0-9_,\s]+)?$", re.I)


def validate(query: str, which: str, prefix: str) -> str:
    """Return the query to run (index rewritten to the prefixed name) or raise QueryRejected with a player-facing reason."""
    base = INDEX_BASES.get(which)
    if not base:
        raise QueryRejected("Pick one of: detective, rookie, photolab.")
    if not query or not query.strip():
        raise QueryRejected("Type an ES|QL query.")
    if len(query) > MAX_QUERY_CHARS:
        raise QueryRejected("That query is too long.")
    clean, blank = _scrub(query.strip())
    # split into pipe segments on the string-blanked text; map back by offsets
    segs, start = [], 0
    for m in re.finditer(r"\|", blank):
        segs.append((start, m.start()))
        start = m.end()
    segs.append((start, len(blank)))
    allowed = {base, f"{prefix}{base}"}
    head_blank = blank[segs[0][0]:segs[0][1]].strip()
    m = _HEAD_RE.match(head_blank)
    if not m:
        raise QueryRejected(f"Start with FROM {base} (one index only).")
    if m.group(1) not in allowed:
        raise QueryRejected(f"Only FROM {base} is allowed on this tab.")
    meta = (m.group(2) or "").strip()
    rest = []
    for a, b in segs[1:]:
        text = clean[a:b].strip()
        cmd_m = re.match(r"([A-Za-z_]+)", blank[a:b].strip())
        if not cmd_m:
            raise QueryRejected("Empty command after |.")
        word = cmd_m.group(1).lower()
        if word == "inline":                       # INLINE STATS
            word = "inlinestats"
        if word not in ALLOWED_COMMANDS:
            raise QueryRejected(f"The {cmd_m.group(1).upper()} command is not available in the Ledger console.")
        rest.append(text)
    head = f"FROM {prefix}{base}" + (f" {meta}" if meta else "")
    return " | ".join([head] + rest)


def clean_error(msg: str, prefix: str = "") -> str:
    """Trim Elasticsearch's multi-line verification error to something a player can read.

    The players typed `FROM evidence-photolab`; ES answers about `<prefix>evidence-photolab`, so drop the prefix again.
    """
    msg = (msg or "").strip()
    if prefix:
        msg = msg.replace(prefix + "evidence-", "evidence-")
    lines = [ln.strip() for ln in msg.splitlines() if ln.strip() and not ln.lower().startswith("found ")]
    return (" ".join(lines) or msg)[:400]
