"""Runtime configuration for the Document Detective backend (environment variables only; optional DOTENV_PATH)."""
from __future__ import annotations

import os
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent
TRACK_ROOT = BACKEND_DIR.parent.parent

# detective_core lives at the track root (or next to app/ on the VM). Make `import detective_core` work from anywhere.
for _p in (str(TRACK_ROOT), os.environ.get("DETECTIVE_ROOT", "")):
    if _p and _p not in sys.path:
        sys.path.insert(0, _p)

from detective_core.config import DEFAULT_LLM_PREFERENCE, parse_dotenv  # noqa: E402


def _flag(v: str | None) -> bool:
    return (v or "").strip().lower() in ("1", "true", "yes", "on")


def _split(s: str) -> list[str]:
    return [x.strip() for x in s.split(",") if x.strip()]


@dataclass
class Cfg:
    es_url: str = ""
    es_api_key: str = field(default="", repr=False)
    prefix: str = ""
    corpus_dir: Path = Path("/opt/detective/corpus")
    llm_preference: list[str] = field(default_factory=lambda: _split(DEFAULT_LLM_PREFERENCE))
    event_id: str = ""
    sandbox_id: str = ""
    hq_url: str = ""
    hq_key: str = field(default="", repr=False)
    admin_token_file: str = ""
    port: int = 5001
    mock_llm: bool = False
    upload_dir: Path = Path(tempfile.gettempdir()) / "detective-uploads"
    frontend_dist: Path = BACKEND_DIR.parent / "frontend" / "dist"
    ask_deadline: float = 18.0          # seconds: /api/ask returns what is ready by then (contract: < 20 s)
    hq_interval: float = 5.0

    @property
    def hq_enabled(self) -> bool:
        return bool(self.hq_url and self.hq_key)

    def index(self, base: str) -> str:
        return f"{self.prefix}{base}"

    @classmethod
    def from_env(cls, environ: dict | None = None) -> "Cfg":
        env: dict[str, str] = {}
        dotenv = (environ or os.environ).get("DOTENV_PATH")
        if dotenv and Path(dotenv).is_file():
            env.update(parse_dotenv(Path(dotenv)))
        env.update(os.environ if environ is None else environ)
        cfg = cls(
            es_url=env.get("ES_URL", "").rstrip("/"),
            es_api_key=env.get("ES_API_KEY", ""),
            prefix=env.get("INDEX_PREFIX", ""),
            corpus_dir=Path(env.get("CORPUS_DIR") or cls.corpus_dir),
            llm_preference=_split(env.get("LLM_PREFERENCE") or DEFAULT_LLM_PREFERENCE),
            event_id=env.get("EVENT_ID", ""),
            sandbox_id=env.get("SANDBOX_ID", ""),
            hq_url=env.get("DETECTIVE_HQ_URL", "").rstrip("/"),
            hq_key=env.get("DETECTIVE_HQ_KEY", ""),
            admin_token_file=env.get("ADMIN_TOKEN_FILE", ""),
            port=int(env.get("PORT") or 5001),
            mock_llm=_flag(env.get("MOCK_LLM")),
        )
        if env.get("UPLOAD_DIR"):
            cfg.upload_dir = Path(env["UPLOAD_DIR"])
        if env.get("FRONTEND_DIST"):
            cfg.frontend_dist = Path(env["FRONTEND_DIST"])
        if env.get("ASK_DEADLINE"):
            cfg.ask_deadline = float(env["ASK_DEADLINE"])
        return cfg
