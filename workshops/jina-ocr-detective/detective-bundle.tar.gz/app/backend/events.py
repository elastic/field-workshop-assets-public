"""The `case-events` store: Elasticsearch is the source of truth, an in-memory list is the cache.

Every scoring action is one event. State (handle, score, solved rounds, ...) is derived from the event list by
game.derive(), so the app can restart at any time and pick up where the player left off.

Privacy: `value` never holds player question text or document content (see CONTRACT section 4).
"""
from __future__ import annotations

import logging
import re
import threading
import time
from datetime import datetime, timezone
from typing import Callable

log = logging.getLogger("detective.events")

EVENT_FIELDS = ("ts", "event_id", "sandbox_id", "handle", "action", "round", "value", "correct", "points",
                "score_after", "ocr_secs", "forwarded")
# Fields that may leave the sandbox for the HQ leaderboard (never anything else).
HQ_FIELDS = ("ts", "event_id", "sandbox_id", "handle", "action", "round", "value", "correct", "points",
             "score_after", "ocr_secs")


class StoreUnavailable(RuntimeError):
    """Events could not be loaded from Elasticsearch yet (state is unknown, so game actions must wait)."""


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


_FRAC_RE = re.compile(r"\.(\d+)")


def parse_ts(s: str) -> datetime:
    """ISO-8601 -> aware datetime. Python 3.10's fromisoformat() accepts neither a trailing Z nor fractional
    seconds that are not exactly 3 or 6 digits, so normalise both (Elasticsearch may echo either)."""
    s = s.strip().replace("Z", "+00:00")
    s = _FRAC_RE.sub(lambda m: "." + (m.group(1) + "000000")[:6], s, count=1)
    dt = datetime.fromisoformat(s)
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


class EventStore:
    def __init__(self, es, index: str, sandbox_id: str = "", event_id: str = "",
                 clock: Callable[[], datetime] = utcnow):
        self.es = es                      # detective_core.es.ES, or None for the in-memory mode (frontend lane, tests)
        self.index = index
        self.sandbox_id = sandbox_id
        self.event_id = event_id
        self.clock = clock
        self.lock = threading.RLock()
        self._events: list[dict] = []
        self._pending: list[dict] = []     # written to memory but not yet persisted (ES hiccup); retried by flush()
        self._seq = 0
        self.loaded = es is None

    # ------------------------------------------------------------------ load
    def load(self) -> int:
        """(Re)load this sandbox's events from Elasticsearch (sorted by ts). Safe to call repeatedly."""
        if self.es is None:
            self.loaded = True
            return len(self._events)
        query: dict = {"match_all": {}}
        if self.sandbox_id:
            query = {"term": {"sandbox_id": self.sandbox_id}}
        r = self.es.post(f"{self.index}/_search", json={"size": 10000, "sort": [{"ts": "asc"}], "query": query},
                         timeout=20)
        loaded = []
        for h in r.get("hits", {}).get("hits", []):
            ev = dict(h["_source"])
            ev["_id"] = h["_id"]
            loaded.append(ev)
        with self.lock:
            persisted_ids = {e["_id"] for e in loaded}
            # keep anything we hold that is not in ES yet (pending writes)
            extra = [e for e in self._events if e.get("_id") not in persisted_ids and e in self._pending]
            self._events = sorted(loaded + extra, key=lambda e: e.get("ts", ""))
            self.loaded = True
        log.info("loaded %d events from %s", len(loaded), self.index)
        return len(loaded)

    def ensure_loaded(self) -> None:
        if self.loaded:
            return
        try:
            self.load()
        except Exception as exc:  # noqa: BLE001
            raise StoreUnavailable(f"case-events not readable yet: {exc}") from exc

    # ------------------------------------------------------------------ read
    def snapshot(self) -> list[dict]:
        with self.lock:
            return list(self._events)

    def unforwarded(self, limit: int = 100) -> list[dict]:
        with self.lock:
            return [e for e in self._events if not e.get("forwarded") and e.get("_id") and e not in self._pending][:limit]

    # ------------------------------------------------------------------ write
    def append(self, action: str, round: int = 0, value: str = "", correct: bool | None = None, points: int = 0,
               handle: str = "", score_after: int = 0, ocr_secs: float | None = None, ts: datetime | None = None,
               ) -> dict:
        doc = {"ts": iso(ts or self.clock()), "event_id": self.event_id, "sandbox_id": self.sandbox_id,
               "handle": handle, "action": action, "round": int(round), "value": (value or "")[:128],
               "points": int(points), "score_after": int(score_after), "forwarded": False}
        if correct is not None:
            doc["correct"] = bool(correct)
        if ocr_secs is not None:
            doc["ocr_secs"] = round_(ocr_secs)
        with self.lock:
            self._events.append(doc)
            if self.es is None:
                self._seq += 1
                doc["_id"] = f"mem-{self._seq}"
                return doc
            self._persist(doc)
        return doc

    def _persist(self, doc: dict) -> bool:
        """Index one event with refresh=true (0.3 s on Serverless) so a restart right after sees it."""
        body = {k: v for k, v in doc.items() if not k.startswith("_")}
        try:
            r = self.es.post(f"{self.index}/_doc", json=body, params={"refresh": "true"}, timeout=6, retries=1)
            doc["_id"] = r["_id"]
            if doc in self._pending:
                self._pending.remove(doc)
            return True
        except Exception as exc:  # noqa: BLE001
            log.warning("event write failed (%s); queued for retry", exc)
            if doc not in self._pending:
                self._pending.append(doc)
            return False

    def flush(self) -> int:
        """Retry queued writes. Returns how many are still pending."""
        with self.lock:
            for doc in list(self._pending):
                self._persist(doc)
            return len(self._pending)

    def mark_forwarded(self, ids: list[str]) -> None:
        """Set forwarded=true locally and in ES (one _bulk)."""
        if not ids:
            return
        with self.lock:
            for e in self._events:
                if e.get("_id") in ids:
                    e["forwarded"] = True
        if self.es is None:
            return
        lines = []
        for i in ids:
            lines.append('{"update":{"_index":"%s","_id":"%s","retry_on_conflict":3}}' % (self.index, i))
            lines.append('{"doc":{"forwarded":true}}')
        try:
            self.es.bulk("\n".join(lines) + "\n", refresh=True)
        except Exception as exc:  # noqa: BLE001
            log.warning("could not persist forwarded flags (%s); they will be re-sent (HQ dedupes by id)", exc)


def round_(x, n=2):
    return round(float(x), n)


class PendingFlusher(threading.Thread):
    """Background loop that retries queued event writes."""

    def __init__(self, store: EventStore, interval: float = 5.0):
        super().__init__(name="events-flusher", daemon=True)
        self.store, self.interval = store, interval
        self._halt = threading.Event()

    def run(self):
        while not self._halt.wait(self.interval):
            try:
                if not self.store.loaded:
                    self.store.ensure_loaded()
                self.store.flush()
            except Exception as exc:  # noqa: BLE001
                log.debug("flusher: %s", exc)

    def stop(self):
        self._halt.set()
