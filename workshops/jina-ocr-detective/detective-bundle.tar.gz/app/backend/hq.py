"""HQ forwarder: copies metadata-only case events to the shared leaderboard project.

* Disabled (never started) when DETECTIVE_HQ_URL / DETECTIVE_HQ_KEY are unset.
* Each local event is sent once, with retry and exponential backoff; local `forwarded` flags mark what is done.
* Only HQ_FIELDS leave the sandbox. Question text and document content never exist in events (events.py), and the
  allow-list below would drop them anyway.
* Idempotent: the HQ document id is derived from event_id + sandbox_id + the local event id and written with
  `_create`, so a retry after a timeout cannot double-count points on the leaderboard (409 = already there).
  If the key is not allowed to use `_create/<id>` (403), it falls back once to `POST /_doc`.
"""
from __future__ import annotations

import logging
import re
import threading
import time

import requests

from events import HQ_FIELDS, LOCAL_ONLY_ACTIONS, EventStore

log = logging.getLogger("detective.hq")

INDEX = "detective-events"
BATCH = 50
MAX_PARK_ATTEMPTS = 5


def hq_doc(event: dict) -> dict:
    d = {k: event[k] for k in HQ_FIELDS if k in event and event[k] is not None}
    if isinstance(d.get("value"), str):
        d["value"] = d["value"][:64]
    return d


def hq_id(event: dict) -> str:
    raw = f"{event.get('event_id') or 'evt'}-{event.get('sandbox_id') or 'sbx'}-{event.get('_id')}"
    return re.sub(r"[^A-Za-z0-9_.\-]", "_", raw)[:160]


class HQForwarder(threading.Thread):
    def __init__(self, cfg, store: EventStore, session: requests.Session | None = None):
        super().__init__(name="hq-forwarder", daemon=True)
        self.cfg, self.store = cfg, store
        self.http = session or requests.Session()
        self.http.headers.update({"Authorization": f"ApiKey {cfg.hq_key}", "Content-Type": "application/json"})
        self._halt = threading.Event()
        self._fails = 0
        self._use_doc_api = False
        self._attempts: dict[str, int] = {}
        self.sent = 0

    def stop(self) -> None:
        self._halt.set()

    # one event -> "ok" | "retry" (HQ down/throttled: stop the batch) | "skip" (refused: try again later, keep going)
    def _send(self, ev: dict) -> str:
        base = self.cfg.hq_url
        try:
            if self._use_doc_api:
                r = self.http.post(f"{base}/{INDEX}/_doc", json=hq_doc(ev), timeout=10)
            else:
                r = self.http.put(f"{base}/{INDEX}/_create/{hq_id(ev)}", json=hq_doc(ev), timeout=10)
        except requests.RequestException as exc:
            log.warning("HQ unreachable: %s", exc)
            return "retry"
        if r.status_code in (200, 201, 409):
            return "ok"
        if r.status_code == 403 and not self._use_doc_api:
            log.warning("HQ rejected _create/<id> (403); falling back to POST _doc")
            self._use_doc_api = True
            return "retry"
        if r.status_code == 429 or r.status_code >= 500:
            return "retry"
        log.warning("HQ refused event %s: HTTP %s %s", ev.get("_id"), r.status_code, r.text[:200])
        return "skip"                # a 4xx the HQ will keep refusing: do not block the events behind it

    def pump(self) -> tuple[int, bool]:
        """Send one batch. Returns (sent, had_failure)."""
        batch = [e for e in self.store.unforwarded(BATCH)
                 if e.get("action") not in LOCAL_ONLY_ACTIONS and self._attempts.get(e["_id"], 0) < MAX_PARK_ATTEMPTS]
        done: list[str] = []
        failed = False
        for ev in batch:
            res = self._send(ev)
            if res == "ok":
                done.append(ev["_id"])
            else:
                self._attempts[ev["_id"]] = self._attempts.get(ev["_id"], 0) + 1
                failed = True
                if res == "retry":
                    break            # HQ is down or throttling: stop this batch, back off
        self.store.mark_forwarded(done)
        self.sent += len(done)
        return len(done), failed

    def run(self) -> None:
        log.info("HQ forwarder started -> %s/%s", self.cfg.hq_url, INDEX)
        while not self._halt.is_set():
            try:
                sent, failed = self.pump()
            except Exception as exc:  # noqa: BLE001
                log.warning("HQ pump error: %s", exc)
                sent, failed = 0, True
            if failed:
                self._fails += 1
                delay = min(60.0, self.cfg.hq_interval * 2 ** min(self._fails, 5))
            else:
                self._fails = 0
                delay = 0.2 if sent >= BATCH else self.cfg.hq_interval
            self._halt.wait(delay)
