"""The Interrogation history: every completed POST /api/ask is appended to a JSON-lines file in the app data dir, and
GET /api/asks returns the last 100, oldest first, so a page refresh restores the room exactly as it was.

* GET /api/asks?scope=case|mine returns one thread (the last 100 of it); without `scope` it returns both interleaved.
* One line per ask: {id, question, scope, ts, response}. `response` is the body POST /api/ask returned.
* One player per sandbox, so one file. It is scoped by SANDBOX_ID (when set) so a reused data dir never shows another game's chat.
* Append + flush + fsync under a lock: a crash can at worst leave one torn last line. Readers skip any line that is not a
  valid entry, and the next append starts on a fresh line if the file ended without a newline.
* No game event and no HQ traffic: this file is the desk's own memory, not game state.
"""
from __future__ import annotations

import json
import logging
import os
import re
import threading
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger("detective.asks")

CAP = 100


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _valid(e) -> bool:
    return (isinstance(e, dict) and isinstance(e.get("id"), int) and not isinstance(e.get("id"), bool)
            and isinstance(e.get("question"), str) and e.get("scope") in ("case", "mine")
            and isinstance(e.get("ts"), str) and isinstance(e.get("response"), dict))


class AskHistory:
    def __init__(self, cfg):
        sandbox = re.sub(r"[^\w.-]", "_", cfg.sandbox_id or "")[:64]
        self.path = Path(cfg.app_data_dir) / (f"asks-{sandbox}.jsonl" if sandbox else "asks.jsonl")
        self._lock = threading.Lock()
        self._ready = False
        self._next_id = 1
        self._needs_newline = False

    # ------------------------------------------------------------------ read
    def read(self, limit: int = CAP, scope: str | None = None) -> list[dict]:
        """The last `limit` valid entries, oldest first. Bad lines (torn write, garbage) are skipped.
        `scope` ("case" | "mine") keeps only that thread's entries, so `limit` counts per thread: the Interrogation has two
        separate chat threads (case evidence, my uploads) and a long case thread must never push the uploads thread out."""
        try:
            data = self.path.read_bytes()
        except FileNotFoundError:
            return []
        except OSError as exc:
            log.warning("could not read the ask history: %s", exc)
            return []
        out: list[dict] = []
        for raw in data.split(b"\n"):                         # bytes split: only \n ends a line
            raw = raw.strip()
            if not raw:
                continue
            try:
                e = json.loads(raw)
            except ValueError:                                # includes bad UTF-8
                continue
            if _valid(e) and (scope is None or e["scope"] == scope):
                out.append(e)
        return out[-limit:] if limit else out

    # ------------------------------------------------------------------ write
    def _prepare(self) -> None:
        """Once: continue the id sequence, and note whether a crash left the file without a final newline."""
        if self._ready:
            return
        entries = self.read(limit=0)
        self._next_id = max((e["id"] for e in entries), default=0) + 1
        try:
            with open(self.path, "rb") as f:
                f.seek(0, os.SEEK_END)
                if f.tell() > 0:
                    f.seek(-1, os.SEEK_END)
                    self._needs_newline = f.read(1) != b"\n"
        except OSError:
            pass
        self._ready = True

    def append(self, question: str, scope: str, response: dict) -> dict | None:
        """Add one completed ask. Never raises: the answer has already been computed, losing the history line is not worth a 500."""
        with self._lock:
            try:
                self._prepare()
                entry = {"id": self._next_id, "question": question, "scope": scope, "ts": _now_iso(), "response": response}
                line = json.dumps(entry, separators=(",", ":")).encode("utf-8") + b"\n"     # ASCII-escaped: no stray separators
                self.path.parent.mkdir(parents=True, exist_ok=True)
                with open(self.path, "ab") as f:
                    if self._needs_newline:
                        f.write(b"\n")
                    f.write(line)
                    f.flush()
                    os.fsync(f.fileno())
                self._needs_newline = False
                self._next_id += 1
                return entry
            except (OSError, TypeError, ValueError) as exc:
                log.warning("could not append to the ask history: %s", exc)
                return None
