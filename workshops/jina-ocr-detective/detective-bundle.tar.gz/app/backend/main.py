"""Document Detective backend (FastAPI). API contract: CONTRACT.md section 6.

Run:  CORPUS_DIR=... ES_URL=... ES_API_KEY=... ./run.sh        (or: uvicorn main:app --port 5001)
"""
from __future__ import annotations

import hmac
import json
import logging
import math
import re
import threading
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path

from fastapi import FastAPI, File, Header, Query, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from config import Cfg
from detective_core.es import ES, ESError
from detective_core.index import create_indices, index_name
from ask import AskService, LLMHolder
from asks import AskHistory
from events import EventStore, PendingFlusher, StoreUnavailable
from game import ApiError, Engine, GameFile
from hq import HQForwarder
import ledger as ledger_mod
from samplepdf import PAGE_RE, SamplePdf
from translate import TranslateService
from upload import MAX_BYTES, UploadManager

log = logging.getLogger("detective")

PLACEHOLDER_HTML = """<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="refresh" content="5">
<title>Document Detective</title><style>body{font-family:Georgia,serif;background:#f4efe6;color:#222;display:flex;
align-items:center;justify-content:center;height:100vh;margin:0}main{text-align:center;max-width:32em}
h1{font-size:1.6em}</style></head><body><main><h1>The case file is being assembled</h1>
<p>The evidence locker is still loading. This page refreshes on its own.</p></main></body></html>"""


# ============================================================================================ request models
class AskBody(BaseModel):
    question: str
    scope: str = "case"


class SimilarBody(BaseModel):
    doc_id: str
    page: int = 1


class FileBody(BaseModel):
    round: int
    city: str


class HintBody(BaseModel):
    round: int = 0
    kind: str | None = None          # "ledger" (or round 0) asks for a Ledger hint; "warrant" for a warrant hint


class WarrantBody(BaseModel):
    suspect_id: str
    traits: dict | None = None        # {languages, hobby, tell}: one value each
    evidence: dict | None = None      # {languages, hobby, tell}: the doc id of the exhibit that proves each trait


class EsqlBody(BaseModel):
    index: str
    query: str


class CorrectBody(BaseModel):
    doc_id: str
    page: int = 1
    amount_eur: float


class LedgerFileBody(BaseModel):
    total_eur: float


class SolveBody(BaseModel):
    step: str


class StageBody(BaseModel):
    stage: str


class HandleBody(BaseModel):
    reroll: bool = False


# ============================================================================================ services
@dataclass
class Services:
    cfg: Cfg
    es: ES | None
    store: EventStore
    game: GameFile
    engine: Engine
    llm: LLMHolder
    ask: AskService
    uploads: UploadManager
    translator: TranslateService
    history: AskHistory
    sample: SamplePdf
    hq: HQForwarder | None
    flusher: PendingFlusher | None
    health_cache: dict


def build_services(cfg: Cfg, game_data: dict | None = None, es: ES | None = None, clock=None) -> Services:
    if es is None and cfg.es_url:
        es = ES(cfg.es_url, cfg.es_api_key, timeout=30)
    store_kw = {"clock": clock} if clock else {}
    store = EventStore(es, cfg.index("case-events"), cfg.sandbox_id, cfg.event_id, **store_kw)
    game = GameFile(Path(cfg.corpus_dir) / "game.json", game_data)
    llm = LLMHolder(es, cfg.llm_preference, cfg.mock_llm)
    eng_kw = {"clock": clock} if clock else {}
    engine = Engine(game, store, llm_model=lambda: llm.model_id, gate=cfg.gate_by_challenge, **eng_kw)
    uploads = UploadManager(cfg, es, engine)
    hq = HQForwarder(cfg, store) if cfg.hq_enabled else None
    flusher = PendingFlusher(store) if es is not None else None
    translator = TranslateService(cfg, llm)
    return Services(cfg, es, store, game, engine, llm, AskService(cfg, es, engine, llm), uploads, translator,
                    AskHistory(cfg), SamplePdf(cfg), hq, flusher, {})


def bootstrap(svc: Services, stop: threading.Event) -> None:
    """Everything that talks to Elasticsearch at startup; retried until it works (the VM may boot before ES is reachable)."""
    cfg = svc.cfg
    while not stop.is_set():
        try:
            if svc.es is not None:
                create_indices(svc.es, cfg.prefix, ["case-events", "evidence-mine"])
                svc.store.load()
            break
        except Exception as exc:  # noqa: BLE001
            log.warning("startup: Elasticsearch not ready (%s); retrying", exc)
            stop.wait(3)
    if svc.flusher:
        svc.flusher.start()
    if svc.hq:
        svc.hq.start()
    try:
        svc.llm.get()
    except Exception as exc:  # noqa: BLE001
        log.warning("startup: LLM not resolved yet (%s); will retry on first question", exc)


# ============================================================================================ page loading
def load_page(svc: Services, doc_id: str, n: int, with_rookie: bool = True) -> dict:
    """One page of a case document or an upload, as GET /api/docs/{doc_id}/pages/{n} returns it. Raises ApiError(404)."""
    cfg, engine, uploads, game_file = svc.cfg, svc.engine, svc.uploads, svc.game
    if doc_id.startswith("mine-"):
        found = uploads.page(doc_id, n)
        if not found:
            raise ApiError(404, "no_such_page", "That page is not in your locker.")
        job, p = found
        return {"doc_id": doc_id, "exhibit": job.exhibit, "page": n, "image_url": p.image_url, "ocr_md": p.ocr_md,
                "ocr_model": p.ocr_model, "ocr_at": p.ocr_at, "rookie_raw": p.rookie_raw,
                "pdf_kind": job.pdf_kind, "why_rookie": None, "amount_eur": None, "amount_eur_verified": None,
                "ocr_secs": p.ocr_secs}
    g = game_file.get()
    meta = g.docs.get(doc_id)
    if not meta or doc_id not in engine.visible_doc_ids():
        raise ApiError(404, "no_such_doc", "That page is not in your locker.")
    if not 1 <= n <= int(meta.get("pages", 1)):
        raise ApiError(404, "no_such_page", "That page does not exist.")
    out = {"doc_id": doc_id, "exhibit": meta.get("exhibit"), "page": n, "image_url": f"/pages/{doc_id}-p{n}.jpg",
           "ocr_md": "", "ocr_model": None, "ocr_at": None, "rookie_raw": "", "pdf_kind": meta.get("pdf_kind"),
           "why_rookie": meta.get("why_rookie"), "amount_eur": None, "amount_eur_verified": None}
    if svc.es is None:
        out["ocr_md"] = "(mock) OCR markdown appears here."
        return out
    q = {"size": 1, "query": {"bool": {"filter": [{"term": {"doc_id": doc_id}}, {"term": {"page": n}}]}},
         "_source": {"excludes": ["ocr_semantic", "rookie_text"]}}
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(2) as ex:
        fd = ex.submit(svc.es.post, f"{index_name(cfg.prefix, 'evidence-detective')}/_search", json=q, timeout=8, retries=1)
        fr = ex.submit(svc.es.post, f"{index_name(cfg.prefix, 'evidence-rookie')}/_search", json=q, timeout=8, retries=1) \
            if with_rookie else None
        det = fd.result()
        rook = fr.result() if fr else {}
    dh = det.get("hits", {}).get("hits", [])
    if not dh:
        raise ApiError(404, "no_such_page", "That page is not in your locker.")
    s = dh[0]["_source"]
    out.update(ocr_md=s.get("ocr_md", ""), ocr_model=s.get("ocr_model"), ocr_at=s.get("ocr_at"),
               amount_eur=s.get("amount_eur"), amount_eur_verified=s.get("amount_eur_verified"))
    if s.get("ocr_skipped"):
        # A page that skipped OCR (a photo: jina-ocr-v1 reads documents, photos go only to Photo Lab). Optional field; the
        # record has an empty ocr_md and no OCR model/date. Uploads never carry it (they are documents by premise).
        out["ocr_skipped"] = s["ocr_skipped"]
    rh = rook.get("hits", {}).get("hits", [])
    if rh:
        out["rookie_raw"] = rh[0]["_source"].get("rookie_raw", "")
    return out


# ============================================================================================ app
def create_app(cfg: Cfg | None = None, services: Services | None = None, start_background: bool = True) -> FastAPI:
    cfg = cfg or Cfg.from_env()
    svc = services or build_services(cfg)
    stop = threading.Event()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if start_background:
            threading.Thread(target=bootstrap, args=(svc, stop), name="bootstrap", daemon=True).start()
        yield
        stop.set()
        for t in (svc.hq, svc.flusher):
            if t:
                t.stop()

    app = FastAPI(title="Document Detective", version="1.0", lifespan=lifespan, docs_url=None, redoc_url=None)
    app.state.svc = svc
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
    engine, ask_svc, uploads, game_file = svc.engine, svc.ask, svc.uploads, svc.game

    @app.middleware("http")
    async def no_store(request: Request, call_next):
        resp = await call_next(request)
        if request.url.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    # ---------------------------------------------------------------------------------- errors
    @app.exception_handler(ApiError)
    async def _api_error(_: Request, exc: ApiError):
        return JSONResponse({"error": exc.code, "message": exc.message, **exc.extra}, status_code=exc.status)

    @app.exception_handler(StoreUnavailable)
    async def _store_unavailable(_: Request, exc: StoreUnavailable):
        return JSONResponse({"error": "starting", "message": "The case file is still loading. Try again in a moment."},
                            status_code=503)

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError):
        return JSONResponse({"error": "bad_request", "message": "That request was not understood."}, status_code=422)

    # ---------------------------------------------------------------------------------- status
    @app.get("/api/health")
    def health():
        c = svc.health_cache
        if c and time.time() - c["t"] < 5:
            data = dict(c["data"])
        else:
            es_ok, counts = False, {}
            if svc.es is not None:
                try:
                    svc.es.get("/", timeout=3, retries=0)
                    es_ok = True
                    try:
                        counts["evidence-detective"] = svc.es.post(
                            f"{index_name(cfg.prefix, 'evidence-detective')}/_count", timeout=3, retries=0).get("count", 0)
                    except ESError:
                        counts["evidence-detective"] = 0
                except Exception:  # noqa: BLE001
                    es_ok = False
            corpus = {"docs": 0, "pages": 0, "built_at": None, "ocr_model": None,
                      "sample": uploads.sample_path().is_file()}
            loaded = game_file.loaded()
            if loaded:
                g = game_file.get()
                corpus.update(docs=len(g.docs), pages=sum(int(d.get("pages", 1)) for d in g.docs.values()),
                              built_at=g.built_at)
                try:
                    m = json.loads((Path(cfg.corpus_dir) / "manifest.json").read_text(encoding="utf-8"))
                    corpus.update({k: m[k] for k in ("docs", "pages", "built_at", "ocr_model") if k in m})
                except (OSError, ValueError):
                    pass
            indexed = counts.get("evidence-detective", 0) > 0
            ok = loaded and ((es_ok and indexed and svc.store.loaded) if svc.es is not None else True)
            data = {"ok": bool(ok), "es": es_ok if svc.es is not None else False, "corpus": corpus,
                    "hq": cfg.hq_enabled, "indexed": counts, "gate": cfg.gate_by_challenge}
            svc.health_cache.clear()
            svc.health_cache.update({"t": time.time(), "data": data})
        if svc.llm.model_id is None and svc.es is not None:       # bootstrap may not have resolved it yet
            try:
                svc.llm.get()
            except Exception:  # noqa: BLE001
                pass
        data["llm_model"] = svc.llm.model_id
        data["mock"] = cfg.mock_llm
        return data

    @app.get("/api/session")
    def session():
        return engine.session()

    @app.post("/api/session/handle")
    def session_handle(body: HandleBody | None = None):
        if body and body.reroll:
            return engine.reroll_handle()
        return {"handle": engine.session()["handle"]}

    @app.post("/api/session/start")
    def session_start():
        return engine.start()

    @app.get("/api/case")
    def case():
        out = engine.case()
        pdir = Path(cfg.corpus_dir) / "portraits"
        for s in out.get("suspects", []):          # served from ${CORPUS_DIR}/portraits/portrait_<suspect id>.jpg
            if re.fullmatch(r"[\w-]+", s.get("id") or "") and (pdir / f"portrait_{s['id']}.jpg").is_file():
                s["portrait_url"] = f"/portraits/portrait_{s['id']}.jpg"
        return out

    @app.get("/api/hints")
    def hints():
        """Convenience (not in CONTRACT 6): the hints this player has already revealed, so the desk keeps no copy."""
        return engine.hints()

    # ---------------------------------------------------------------------------------- evidence
    @app.get("/api/docs")
    def docs(scope: str = Query("case")):
        if scope == "mine":
            return uploads.list_docs()
        if scope != "case":
            raise ApiError(400, "bad_scope", "scope must be 'case' or 'mine'.")
        g = game_file.get()
        ids = engine.visible_doc_ids()
        out = []
        for d in ids:
            m = g.docs.get(d)
            if not m:
                continue
            out.append({"doc_id": d, "exhibit": m.get("exhibit"), "title": m.get("title"), "doc_type": m.get("doc_type"),
                        "round": m.get("round", 0), "lang": m.get("lang"), "pages": m.get("pages", 1),
                        "thumb_url": f"/thumbs/{d}-p1.jpg", "pdf_kind": m.get("pdf_kind")})
        out.sort(key=lambda x: (x["round"], x["exhibit"] or ""))
        return out

    @app.get("/api/docs/{doc_id}/pages/{n}")
    def doc_page(doc_id: str, n: int):
        return load_page(svc, doc_id, n)

    @app.post("/api/docs/{doc_id}/pages/{n}/translate")
    def translate_page(doc_id: str, n: int):
        """Convenience (not in CONTRACT 6): the page's OCR markdown translated to English (never the image or the Rookie text).
        Works for case documents and the player's uploads. Cached per (doc, page, sha1(ocr_md)). Writes no game event."""
        page = load_page(svc, doc_id, n, with_rookie=False)
        ocr_md = page.get("ocr_md") or ""
        if not ocr_md.strip():
            raise ApiError(404, "no_ocr_text", "This page has no OCR text to translate.")
        return svc.translator.translate(doc_id, n, ocr_md)

    @app.post("/api/ask")
    def ask(body: AskBody):
        engine.session()          # state must be readable (and the handle exists) before we answer
        out = ask_svc.ask(body.question, body.scope)
        if not (out.get("detective") or {}).get("error"):     # a failed ask (no Detective answer) is not kept
            svc.history.append(out["question"], out["scope"], out)
        return out

    @app.get("/api/asks")
    def asks():
        """Convenience (not in CONTRACT 6): the Interrogation history (last 100 completed asks, oldest first), so a refresh restores the room."""
        return svc.history.read()

    @app.post("/api/similar")
    def similar(body: SimilarBody):
        return ask_svc.similar(body.doc_id, body.page)

    # ---------------------------------------------------------------------------------- game actions
    @app.post("/api/file")
    def file_city(body: FileBody):
        return engine.file(body.round, body.city)

    @app.post("/api/hint")
    def hint(body: HintBody):
        if body.kind == "warrant":
            return engine.warrant_hint()
        if body.kind == "ledger" or body.round == 0:
            return engine.ledger_hint()
        return engine.hint(body.round)

    @app.post("/api/warrant")
    def warrant(body: WarrantBody):
        return engine.warrant(body.suspect_id, body.traits, body.evidence)

    @app.get("/api/ledger")
    def ledger_info():
        """Convenience (not in the contract): the question, the prefilled queries and any Ledger hints revealed so far.

        The Detective can be wrong in two ways on a stamped receipt: a wrong amount or a missing one. `coverage`
        (docs vs docs with a read amount) shows the second kind.
        """
        g = game_file.get()
        st = engine.state()
        expense = '("receipt", "ticket_stub", "rental_agreement")'
        return {"question": g.ledger.get("question"), "open": engine.ledger_is_open(st),
                "prefilled": {
                    "detective": "FROM evidence-detective | WHERE amount_eur IS NOT NULL OR amount_eur_verified IS NOT NULL"
                                 " | STATS total_eur = SUM(COALESCE(amount_eur_verified, amount_eur)), receipts = COUNT(*)",
                    "rookie": "FROM evidence-rookie | WHERE amount_eur IS NOT NULL"
                              " | STATS total_eur = SUM(amount_eur), receipts = COUNT(*)",
                    "photolab": "FROM evidence-photolab | WHERE amount_eur IS NOT NULL"
                                " | STATS total_eur = SUM(amount_eur), receipts = COUNT(*)"},
                "coverage": {
                    "detective": f"FROM evidence-detective | WHERE doc_type IN {expense}"
                                 " | STATS expense_docs = COUNT(*), read_amounts = COUNT(amount_eur),"
                                 " verified = COUNT(amount_eur_verified)",
                    "rookie": f"FROM evidence-rookie | WHERE doc_type IN {expense}"
                              " | STATS expense_docs = COUNT(*), read_amounts = COUNT(amount_eur)"},
                "hints": (g.ledger.get("hints") or [])[:st.ledger_hints_used],
                "hints_total": len(g.ledger.get("hints") or [])}

    @app.post("/api/ledger/esql")
    def ledger_esql(body: EsqlBody):
        engine.ledger_open()
        try:
            q = ledger_mod.validate(body.query, body.index, cfg.prefix)
        except ledger_mod.QueryRejected as exc:
            return {"columns": [], "values": [], "error": str(exc)}
        if svc.es is None:
            return {"columns": [], "values": [], "error": "ES|QL is not available in mock mode."}
        try:
            r = svc.es.request("POST", "_query", json={"query": q}, timeout=12, retries=0)
        except ESError as exc:
            return {"columns": [], "values": [], "error": ledger_mod.clean_error(exc.reason, cfg.prefix)}
        except Exception:  # noqa: BLE001
            return {"columns": [], "values": [], "error": "The query did not finish. Try a smaller one."}
        vals = r.get("values", [])
        out = {"columns": r.get("columns", []), "values": vals[:ledger_mod.MAX_ROWS], "error": None}
        if len(vals) > ledger_mod.MAX_ROWS:
            out["truncated"] = True
        return out

    @app.post("/api/ledger/correct")
    def ledger_correct(body: CorrectBody):
        st = engine.ledger_open()
        if body.doc_id not in engine.ledger_receipt_ids():
            raise ApiError(400, "not_a_receipt", "Only the receipts in the Ledger can be corrected.")
        if not math.isfinite(body.amount_eur) or not 0 <= body.amount_eur < 10_000_000:
            raise ApiError(400, "bad_amount", "Enter the amount you can read on the page.")
        if svc.es is not None:
            idx = index_name(cfg.prefix, "evidence-detective")
            r = svc.es.post(f"{idx}/_search", timeout=8, retries=1, json={
                "size": 1, "_source": False,
                "query": {"bool": {"filter": [{"term": {"doc_id": body.doc_id}}, {"term": {"page": body.page}}]}}})
            hits = r.get("hits", {}).get("hits", [])
            if not hits:
                raise ApiError(404, "no_such_page", "That page is not in the Ledger.")
            # A multi-page document carries its amount on one page. Correcting another page would count the document twice.
            sib = svc.es.post(f"{idx}/_search", timeout=8, retries=1, json={
                "size": 20, "_source": ["page", "amount_eur", "amount_eur_verified"],
                "query": {"term": {"doc_id": body.doc_id}}}).get("hits", {}).get("hits", [])
            amount_pages = sorted(h["_source"]["page"] for h in sib if h["_source"].get("amount_eur") is not None
                                  or h["_source"].get("amount_eur_verified") is not None)
            if amount_pages and body.page not in amount_pages:
                raise ApiError(400, "not_the_amount_page",
                               f"This document's amount is on page {amount_pages[0]}. Correct it there.")
            svc.es.post(f"{idx}/_update/{hits[0]['_id']}", params={"refresh": "true"}, timeout=10, retries=1,
                        json={"doc": {"amount_eur_verified": round(float(body.amount_eur), 2),
                                      "verified_by": st.handle or "unknown"}})
        engine.record_ledger_correction(body.doc_id)
        return {"ok": True}

    @app.post("/api/ledger/file")
    def ledger_file(body: LedgerFileBody):
        if not math.isfinite(body.total_eur):
            raise ApiError(400, "bad_amount", "Enter a number.")
        return engine.ledger_file(body.total_eur)

    # ---------------------------------------------------------------------------------- uploads
    @app.post("/api/upload")
    def upload(request: Request, file: UploadFile = File(...)):
        engine.require_stage("upload")            # gated: "Bring your worst PDF" opens with Challenge 5
        cl = request.headers.get("content-length")
        if cl and cl.isdigit() and int(cl) > MAX_BYTES + 1_048_576:
            raise ApiError(413, "too_large", "That file is over 20 MB.")
        data = file.file.read(MAX_BYTES + 1)
        job = uploads.submit(file.filename or "upload", data)
        return {"job_id": job.job_id, "pages": len(job.pages)}

    @app.post("/api/upload/sample")
    def upload_sample():
        """Convenience (not in CONTRACT 6): "Try our worst PDF". Same result as POST /api/upload of ${CORPUS_DIR}/sample-worst.pdf."""
        engine.require_stage("upload")
        job = uploads.submit_sample(admin=False)
        return {"job_id": job.job_id, "pages": len(job.pages)}

    @app.get("/api/upload/{job_id}")
    def upload_status(job_id: str):
        return uploads.get(job_id).to_dict()

    # ---------------------------------------------------------------------------------- Instruqt hooks
    @app.get("/api/progress")
    def progress(step: str):
        return engine.progress(step)

    def require_admin(token: str | None) -> None:
        """X-Admin-Token against the token file (written by Instruqt setup 01). 503 if none is configured, 403 if it is wrong."""
        token_file = cfg.admin_token_file
        try:
            expected = Path(token_file).read_text(encoding="utf-8").strip() if token_file else ""
        except OSError:
            expected = ""
        if not expected:
            raise ApiError(503, "admin_disabled", "Admin token is not configured.")
        if not token or not hmac.compare_digest(token.strip(), expected):
            raise ApiError(403, "forbidden", "Bad admin token.")

    @app.post("/api/admin/stage")
    def admin_stage(body: StageBody, x_admin_token: str | None = Header(None, alias="X-Admin-Token")):
        """Raise the Instruqt stage (round1 < round2 < round3 < warrant < upload < bonus). Idempotent; never lowers. Stored as a
        local `stage` event (survives a restart) that is never forwarded to the HQ leaderboard. Works whether or not gating is on."""
        require_admin(x_admin_token)
        return engine.raise_stage(body.stage)

    @app.post("/api/admin/solve")
    def admin_solve(body: SolveBody, x_admin_token: str | None = Header(None, alias="X-Admin-Token")):
        require_admin(x_admin_token)
        out = engine.solve(body.step)
        if out["step"] == "upload":
            try:
                job = uploads.submit_sample()
                uploads.wait(job, 15)
                out["job_id"] = job.job_id
            except ApiError as exc:
                out["sample"] = exc.message
        return out

    # ---------------------------------------------------------------------------------- sample PDF (bonus challenge)
    @app.get("/sample-pdf", include_in_schema=False)
    def sample_pdf_page():
        """HTML page with every page of sample-worst.pdf as an image (the code editor and Chrome's sandboxed iframes cannot show a PDF)."""
        body, status = svc.sample.html()
        return HTMLResponse(body, status_code=status, headers={"Cache-Control": "no-cache"})

    @app.get("/sample-pdf/raw", include_in_schema=False)
    def sample_pdf_raw():
        p = svc.sample.pdf_path
        if not p.is_file():
            return JSONResponse({"error": "no_sample", "message": "The sample PDF is not in the corpus."}, status_code=404)
        return FileResponse(p, media_type="application/pdf", headers={"Content-Disposition": 'inline; filename="sample.pdf"'})

    @app.get("/sample-pdf/page/{name}", include_in_schema=False)
    def sample_pdf_image(name: str):
        m = PAGE_RE.match(name)
        f = svc.sample.page_file(int(m.group(1))) if m else None
        if not f:
            return JSONResponse({"error": "not_found", "message": "No such page."}, status_code=404)
        return FileResponse(f, media_type="image/jpeg", headers={"Cache-Control": "public, max-age=3600"})

    # ---------------------------------------------------------------------------------- static
    class CachedStatic(StaticFiles):
        def file_response(self, *a, **kw):
            resp = super().file_response(*a, **kw)
            resp.headers["Cache-Control"] = "public, max-age=3600"
            return resp

    corpus = Path(cfg.corpus_dir)
    cfg.upload_dir.mkdir(parents=True, exist_ok=True)
    app.mount("/pages", CachedStatic(directory=str(corpus / "pages"), check_dir=False), name="pages")
    app.mount("/thumbs", CachedStatic(directory=str(corpus / "thumbs"), check_dir=False), name="thumbs")
    app.mount("/portraits", CachedStatic(directory=str(corpus / "portraits"), check_dir=False), name="portraits")
    app.mount("/figures", CachedStatic(directory=str(corpus / "figures"), check_dir=False), name="figures")
    app.mount("/uploads", CachedStatic(directory=str(cfg.upload_dir), check_dir=False), name="uploads")

    @app.get("/{full_path:path}", include_in_schema=False)
    def frontend(full_path: str):
        if full_path.startswith("api/"):
            return JSONResponse({"error": "not_found", "message": "No such endpoint."}, status_code=404)
        dist = Path(cfg.frontend_dist)
        index = dist / "index.html"
        if not index.is_file():
            return HTMLResponse(PLACEHOLDER_HTML)
        if full_path:
            target = (dist / full_path).resolve()
            if target.is_file() and dist.resolve() in target.parents:
                headers = {"Cache-Control": "public, max-age=31536000, immutable"} if full_path.startswith("assets/") \
                    else {"Cache-Control": "no-cache"}
                return FileResponse(target, headers=headers)
            if Path(full_path).suffix:             # a missing asset: do not mask it with index.html
                return JSONResponse({"error": "not_found", "message": "No such file."}, status_code=404)
        return FileResponse(index, headers={"Cache-Control": "no-cache"})

    return app


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
app = create_app()
